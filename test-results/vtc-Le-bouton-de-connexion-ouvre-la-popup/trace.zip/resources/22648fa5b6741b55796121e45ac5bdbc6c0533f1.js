import{r as H,y as De,z as Me,G as A,H as X,p as Ce,J,M as ve,t as re,d as N,P as G,N as ke,Q as me,U as se,V as ye,W as Je,X as q,Y as Le,Z as Be,_ as xe,$ as et,a0 as Re,a1 as tt,a2 as ge,a3 as He,i as he,a4 as Ne,a5 as it,m as nt,o as rt,a6 as st,E as Ge,b as oe,e as Ae,h as ee,a7 as ot,a8 as at,a9 as lt,aa as dt,ab as ze,ac as ct,ad as ht,ae as ut,af as _t,ag as ft,ah as pt,ai as mt,aj as ue,ak as We,al as gt,a as bt,T as Ct}from"./chunk-87ea9773e3be9e3c64fcd76ebb6648c631487bd39ff55c0d13bf58e8af292d4b-CAX9wiuo.js";import{i as W}from"./indexhtml-DSrkT9T8.js";import"./commonjsHelpers-Cpj98o6Y.js";H("vaadin-grid",W`
    :host {
      font-family: var(--lumo-font-family);
      font-size: var(--lumo-font-size-m);
      line-height: var(--lumo-line-height-s);
      color: var(--lumo-body-text-color);
      background-color: var(--lumo-base-color);
      box-sizing: border-box;
      -webkit-text-size-adjust: 100%;
      -webkit-tap-highlight-color: transparent;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      --_focus-ring-color: var(--vaadin-focus-ring-color, var(--lumo-primary-color-50pct));
      --_focus-ring-width: var(--vaadin-focus-ring-width, 2px);
      /* For internal use only */
      --_lumo-grid-border-color: var(--lumo-contrast-20pct);
      --_lumo-grid-secondary-border-color: var(--lumo-contrast-10pct);
      --_lumo-grid-border-width: 1px;
      --_lumo-grid-selected-row-color: var(--lumo-primary-color-10pct);
    }

    /* No (outer) border */

    :host(:not([theme~='no-border'])) {
      border: var(--_lumo-grid-border-width) solid var(--_lumo-grid-border-color);
    }

    :host([disabled]) {
      opacity: 0.7;
    }

    /* Cell styles */

    [part~='cell'] {
      min-height: var(--lumo-size-m);
      background-color: var(--vaadin-grid-cell-background, var(--lumo-base-color));
      cursor: default;
      --_cell-padding: var(--vaadin-grid-cell-padding, var(--_cell-default-padding));
      --_cell-default-padding: var(--lumo-space-xs) var(--lumo-space-m);
    }

    [part~='cell'] ::slotted(vaadin-grid-cell-content) {
      cursor: inherit;
      padding: var(--_cell-padding);
    }

    /* Apply row borders by default and introduce the "no-row-borders" variant */
    :host(:not([theme~='no-row-borders'])) [part~='cell']:not([part~='details-cell']) {
      border-top: var(--_lumo-grid-border-width) solid var(--_lumo-grid-secondary-border-color);
    }

    /* Hide first body row top border */
    :host(:not([theme~='no-row-borders'])) [part~='first-row'] [part~='cell']:not([part~='details-cell']) {
      border-top: 0;
      min-height: calc(var(--lumo-size-m) - var(--_lumo-grid-border-width));
    }

    /* Focus-ring */

    [part~='row'] {
      position: relative;
    }

    [part~='row']:focus,
    [part~='focused-cell']:focus {
      outline: none;
    }

    :host([navigating]) [part~='row']:focus::before,
    :host([navigating]) [part~='focused-cell']:focus::before {
      content: '';
      position: absolute;
      inset: 0;
      pointer-events: none;
      box-shadow: inset 0 0 0 var(--_focus-ring-width) var(--_focus-ring-color);
    }

    :host([navigating]) [part~='row']:focus::before {
      transform: translateX(calc(-1 * var(--_grid-horizontal-scroll-position)));
      z-index: 3;
    }

    /* Empty state */
    [part~='empty-state'] {
      padding: var(--lumo-space-m);
      color: var(--lumo-secondary-text-color);
    }

    /* Drag and Drop styles */
    :host([dragover])::after {
      content: '';
      position: absolute;
      z-index: 100;
      inset: 0;
      pointer-events: none;
      box-shadow: inset 0 0 0 var(--_focus-ring-width) var(--_focus-ring-color);
    }

    [part~='row'][dragover] {
      z-index: 100 !important;
    }

    [part~='row'][dragover] [part~='cell'] {
      overflow: visible;
    }

    [part~='row'][dragover] [part~='cell']::after {
      content: '';
      position: absolute;
      inset: 0;
      height: calc(var(--_lumo-grid-border-width) + 2px);
      pointer-events: none;
      background: var(--lumo-primary-color-50pct);
    }

    [part~='row'][dragover] [part~='cell'][last-frozen]::after {
      right: -1px;
    }

    :host([theme~='no-row-borders']) [dragover] [part~='cell']::after {
      height: 2px;
    }

    [part~='row'][dragover='below'] [part~='cell']::after {
      top: 100%;
      bottom: auto;
      margin-top: -1px;
    }

    :host([all-rows-visible]) [part~='last-row'][dragover='below'] [part~='cell']::after {
      height: 1px;
    }

    [part~='row'][dragover='above'] [part~='cell']::after {
      top: auto;
      bottom: 100%;
      margin-bottom: -1px;
    }

    [part~='row'][details-opened][dragover='below'] [part~='cell']:not([part~='details-cell'])::after,
    [part~='row'][details-opened][dragover='above'] [part~='details-cell']::after {
      display: none;
    }

    [part~='row'][dragover][dragover='on-top'] [part~='cell']::after {
      height: 100%;
      opacity: 0.5;
    }

    [part~='row'][dragstart] [part~='cell'] {
      border: none !important;
      box-shadow: none !important;
    }

    [part~='row'][dragstart] [part~='cell'][last-column] {
      border-radius: 0 var(--lumo-border-radius-s) var(--lumo-border-radius-s) 0;
    }

    [part~='row'][dragstart] [part~='cell'][first-column] {
      border-radius: var(--lumo-border-radius-s) 0 0 var(--lumo-border-radius-s);
    }

    #scroller [part~='row'][dragstart]:not([dragstart=''])::after {
      display: block;
      position: absolute;
      left: var(--_grid-drag-start-x);
      top: var(--_grid-drag-start-y);
      z-index: 100;
      content: attr(dragstart);
      align-items: center;
      justify-content: center;
      box-sizing: border-box;
      padding: calc(var(--lumo-space-xs) * 0.8);
      color: var(--lumo-error-contrast-color);
      background-color: var(--lumo-error-color);
      border-radius: var(--lumo-border-radius-m);
      font-family: var(--lumo-font-family);
      font-size: var(--lumo-font-size-xxs);
      line-height: 1;
      font-weight: 500;
      text-transform: initial;
      letter-spacing: initial;
      min-width: calc(var(--lumo-size-s) * 0.7);
      text-align: center;
    }

    /* Headers and footers */

    [part~='header-cell'],
    [part~='footer-cell'],
    [part~='reorder-ghost'] {
      font-size: var(--lumo-font-size-s);
      font-weight: 500;
    }

    [part~='footer-cell'] {
      font-weight: 400;
    }

    [part~='row']:only-child [part~='header-cell'] {
      min-height: var(--lumo-size-xl);
    }

    /* Header borders */

    /* Hide first header row top border */
    :host(:not([theme~='no-row-borders'])) [part~='row']:first-child [part~='header-cell'] {
      border-top: 0;
    }

    /* Hide header row top border if previous row is hidden */
    [part~='row'][hidden] + [part~='row'] [part~='header-cell'] {
      border-top: 0;
    }

    [part~='row']:last-child [part~='header-cell'] {
      border-bottom: var(--_lumo-grid-border-width) solid transparent;
    }

    :host(:not([theme~='no-row-borders'])) [part~='row']:last-child [part~='header-cell'] {
      border-bottom-color: var(--_lumo-grid-secondary-border-color);
    }

    /* Overflow uses a stronger border color */
    :host([overflow~='top']) [part~='row']:last-child [part~='header-cell'] {
      border-bottom-color: var(--_lumo-grid-border-color);
    }

    /* Footer borders */

    [part~='row']:first-child [part~='footer-cell'] {
      border-top: var(--_lumo-grid-border-width) solid transparent;
    }

    :host(:not([theme~='no-row-borders'])) [part~='row']:first-child [part~='footer-cell'] {
      border-top-color: var(--_lumo-grid-secondary-border-color);
    }

    /* Overflow uses a stronger border color */
    :host([overflow~='bottom']) [part~='row']:first-child [part~='footer-cell'] {
      border-top-color: var(--_lumo-grid-border-color);
    }

    /* Column reordering */

    :host([reordering]) [part~='cell'] {
      background: linear-gradient(var(--lumo-shade-20pct), var(--lumo-shade-20pct)) var(--lumo-base-color);
    }

    :host([reordering]) [part~='cell'][reorder-status='allowed'] {
      background: var(--lumo-base-color);
    }

    :host([reordering]) [part~='cell'][reorder-status='dragging'] {
      background: linear-gradient(var(--lumo-contrast-5pct), var(--lumo-contrast-5pct)) var(--lumo-base-color);
    }

    [part~='reorder-ghost'] {
      opacity: 0.85;
      box-shadow: var(--lumo-box-shadow-s);
      /* TODO Use the same styles as for the cell element (reorder-ghost copies styles from the cell element) */
      padding: var(--lumo-space-s) var(--lumo-space-m) !important;
    }

    /* Column resizing */

    [part='resize-handle'] {
      --_resize-handle-width: 3px;
      width: var(--_resize-handle-width);
      background-color: var(--lumo-primary-color-50pct);
      opacity: 0;
      transition: opacity 0.2s;
    }

    [part='resize-handle']::before {
      transform: translateX(calc(-50% + var(--_resize-handle-width) / 2));
      width: var(--lumo-size-s);
    }

    :host(:not([reordering])) *:not([column-resizing]) [part~='cell']:hover [part='resize-handle'],
    [part='resize-handle']:active {
      opacity: 1;
      transition-delay: 0.15s;
    }

    /* Column borders */

    :host([theme~='column-borders']) [part~='cell']:not([last-column]):not([part~='details-cell']) {
      border-right: var(--_lumo-grid-border-width) solid var(--_lumo-grid-secondary-border-color);
    }

    /* Frozen columns */

    [last-frozen] {
      border-right: var(--_lumo-grid-border-width) solid transparent;
      overflow: hidden;
    }

    :host([overflow~='start']) [part~='cell'][last-frozen]:not([part~='details-cell']) {
      border-right-color: var(--_lumo-grid-border-color);
    }

    [first-frozen-to-end] {
      border-left: var(--_lumo-grid-border-width) solid transparent;
    }

    :host([overflow~='end']) [part~='cell'][first-frozen-to-end]:not([part~='details-cell']) {
      border-left-color: var(--_lumo-grid-border-color);
    }

    /* Row stripes */

    :host([theme~='row-stripes']) [part~='even-row'] [part~='body-cell'],
    :host([theme~='row-stripes']) [part~='even-row'] [part~='details-cell'] {
      background-image: linear-gradient(var(--lumo-contrast-5pct), var(--lumo-contrast-5pct));
      background-repeat: repeat-x;
    }

    /* Selected row */

    /* Raise the selected rows above unselected rows (so that box-shadow can cover unselected rows) */
    :host(:not([reordering])) [part~='row'][selected] {
      z-index: 1;
    }

    :host(:not([reordering])) [part~='row'][selected] [part~='body-cell']:not([part~='details-cell']) {
      background-image: linear-gradient(var(--_lumo-grid-selected-row-color), var(--_lumo-grid-selected-row-color));
      background-repeat: repeat;
    }

    /* Cover the border of an unselected row */
    :host(:not([theme~='no-row-borders'])) [part~='row'][selected] [part~='cell']:not([part~='details-cell']) {
      box-shadow: 0 var(--_lumo-grid-border-width) 0 0 var(--_lumo-grid-selected-row-color);
    }

    /* Compact */

    :host([theme~='compact']) [part~='row']:only-child [part~='header-cell'] {
      min-height: var(--lumo-size-m);
    }

    :host([theme~='compact']) [part~='cell'] {
      min-height: var(--lumo-size-s);
      --_cell-default-padding: var(--lumo-space-xs) var(--lumo-space-s);
    }

    :host([theme~='compact']) [part~='first-row'] [part~='cell']:not([part~='details-cell']) {
      min-height: calc(var(--lumo-size-s) - var(--_lumo-grid-border-width));
    }

    :host([theme~='compact']) [part~='empty-state'] {
      padding: var(--lumo-space-s);
    }

    /* Wrap cell contents */

    :host([theme~='wrap-cell-content']) [part~='cell'] ::slotted(vaadin-grid-cell-content) {
      white-space: normal;
    }

    /* RTL specific styles */

    :host([dir='rtl']) [part~='row'][dragstart] [part~='cell'][last-column] {
      border-radius: var(--lumo-border-radius-s) 0 0 var(--lumo-border-radius-s);
    }

    :host([dir='rtl']) [part~='row'][dragstart] [part~='cell'][first-column] {
      border-radius: 0 var(--lumo-border-radius-s) var(--lumo-border-radius-s) 0;
    }

    :host([dir='rtl'][theme~='column-borders']) [part~='cell']:not([last-column]):not([part~='details-cell']) {
      border-right: none;
      border-left: var(--_lumo-grid-border-width) solid var(--_lumo-grid-secondary-border-color);
    }

    :host([dir='rtl']) [last-frozen] {
      border-right: none;
      border-left: var(--_lumo-grid-border-width) solid transparent;
    }

    :host([dir='rtl']) [first-frozen-to-end] {
      border-left: none;
      border-right: var(--_lumo-grid-border-width) solid transparent;
    }

    :host([dir='rtl'][overflow~='start']) [part~='cell'][last-frozen]:not([part~='details-cell']) {
      border-left-color: var(--_lumo-grid-border-color);
    }

    :host([dir='rtl'][overflow~='end']) [part~='cell'][first-frozen-to-end]:not([part~='details-cell']) {
      border-right-color: var(--_lumo-grid-border-color);
    }
  `,{moduleId:"lumo-grid"});/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */function K(n){return n.__cells||Array.from(n.querySelectorAll('[part~="cell"]:not([part~="details-cell"])'))}function R(n,r){[...n.children].forEach(r)}function Z(n,r){K(n).forEach(r),n.__detailsCell&&r(n.__detailsCell)}function Ve(n,r,e){let t=1;n.forEach(i=>{t%10===0&&(t+=1),i._order=e+t*r,t+=1})}function fe(n,r,e){switch(typeof e){case"boolean":n.toggleAttribute(r,e);break;case"string":n.setAttribute(r,e);break;default:n.removeAttribute(r);break}}function B(n,r,e){r||r===""?De(n,"part",e):Me(n,"part",e)}function k(n,r,e){n.forEach(t=>{B(t,e,r)})}function j(n,r){const e=K(n);Object.entries(r).forEach(([t,i])=>{fe(n,t,i);const s=`${t}-row`;B(n,i,s),k(e,`${s}-cell`,i)})}function Fe(n,r){const e=K(n);Object.entries(r).forEach(([t,i])=>{const s=n.getAttribute(t);if(fe(n,t,i),s){const o=`${t}-${s}-row`;B(n,!1,o),k(e,`${o}-cell`,!1)}if(i){const o=`${t}-${i}-row`;B(n,i,o),k(e,`${o}-cell`,i)}})}function U(n,r,e,t,i){fe(n,r,e),i&&B(n,!1,i),B(n,e,t||`${r}-cell`)}function vt(n){return K(n).find(r=>r._content.querySelector("vaadin-grid-tree-toggle"))}class L{constructor(r,e){this.__host=r,this.__callback=e,this.__currentSlots=[],this.__onMutation=this.__onMutation.bind(this),this.__observer=new MutationObserver(this.__onMutation),this.__observer.observe(r,{childList:!0}),this.__initialCallDebouncer=A.debounce(this.__initialCallDebouncer,X,()=>this.__onMutation())}disconnect(){this.__observer.disconnect(),this.__initialCallDebouncer.cancel(),this.__toggleSlotChangeListeners(!1)}flush(){this.__onMutation()}__toggleSlotChangeListeners(r){this.__currentSlots.forEach(e=>{r?e.addEventListener("slotchange",this.__onMutation):e.removeEventListener("slotchange",this.__onMutation)})}__onMutation(){const r=!this.__currentColumns;this.__currentColumns=this.__currentColumns||[];const e=L.getColumns(this.__host),t=e.filter(l=>!this.__currentColumns.includes(l)),i=this.__currentColumns.filter(l=>!e.includes(l)),s=this.__currentColumns.some((l,u)=>l!==e[u]);this.__currentColumns=e,this.__toggleSlotChangeListeners(!1),this.__currentSlots=[...this.__host.children].filter(l=>l instanceof HTMLSlotElement),this.__toggleSlotChangeListeners(!0),(r||t.length||i.length||s)&&this.__callback(t,i)}static __isColumnElement(r){return r.nodeType===Node.ELEMENT_NODE&&/\bcolumn\b/u.test(r.localName)}static getColumns(r){const e=[],t=r._isColumnElement||L.__isColumnElement;return[...r.children].forEach(i=>{t(i)?e.push(i):i instanceof HTMLSlotElement&&[...i.assignedElements({flatten:!0})].filter(s=>t(s)).forEach(s=>e.push(s))}),e}}/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const Ue=n=>class extends n{static get properties(){return{resizable:{type:Boolean,sync:!0,value(){if(this.localName==="vaadin-grid-column-group")return;const e=this.parentNode;return e&&e.localName==="vaadin-grid-column-group"&&e.resizable||!1}},frozen:{type:Boolean,value:!1,sync:!0},frozenToEnd:{type:Boolean,value:!1,sync:!0},rowHeader:{type:Boolean,value:!1,sync:!0},hidden:{type:Boolean,value:!1,sync:!0},header:{type:String,sync:!0},textAlign:{type:String,sync:!0},headerPartName:{type:String,sync:!0},footerPartName:{type:String,sync:!0},_lastFrozen:{type:Boolean,value:!1,sync:!0},_bodyContentHidden:{type:Boolean,value:!1,sync:!0},_firstFrozenToEnd:{type:Boolean,value:!1,sync:!0},_order:{type:Number,sync:!0},_reorderStatus:{type:Boolean,sync:!0},_emptyCells:Array,_headerCell:{type:Object,sync:!0},_footerCell:{type:Object,sync:!0},_grid:Object,__initialized:{type:Boolean,value:!0},headerRenderer:{type:Function,sync:!0},_headerRenderer:{type:Function,computed:"_computeHeaderRenderer(headerRenderer, header, __initialized)"},footerRenderer:{type:Function,sync:!0},_footerRenderer:{type:Function,computed:"_computeFooterRenderer(footerRenderer, __initialized)"},__gridColumnElement:{type:Boolean,value:!0}}}static get observers(){return["_widthChanged(width, _headerCell, _footerCell, _cells)","_frozenChanged(frozen, _headerCell, _footerCell, _cells)","_frozenToEndChanged(frozenToEnd, _headerCell, _footerCell, _cells)","_flexGrowChanged(flexGrow, _headerCell, _footerCell, _cells)","_textAlignChanged(textAlign, _cells, _headerCell, _footerCell)","_orderChanged(_order, _headerCell, _footerCell, _cells)","_lastFrozenChanged(_lastFrozen)","_firstFrozenToEndChanged(_firstFrozenToEnd)","_onRendererOrBindingChanged(_renderer, _cells, _bodyContentHidden, path)","_onHeaderRendererOrBindingChanged(_headerRenderer, _headerCell, path, header)","_onFooterRendererOrBindingChanged(_footerRenderer, _footerCell)","_resizableChanged(resizable, _headerCell)","_reorderStatusChanged(_reorderStatus, _headerCell, _footerCell, _cells)","_hiddenChanged(hidden, _headerCell, _footerCell, _cells)","_rowHeaderChanged(rowHeader, _cells)","__headerFooterPartNameChanged(_headerCell, _footerCell, headerPartName, footerPartName)"]}get _grid(){return this._gridValue||(this._gridValue=this._findHostGrid()),this._gridValue}get _allCells(){return[].concat(this._cells||[]).concat(this._emptyCells||[]).concat(this._headerCell).concat(this._footerCell).filter(e=>e)}connectedCallback(){super.connectedCallback(),requestAnimationFrame(()=>{this._grid&&this._allCells.forEach(e=>{e._content.parentNode||this._grid.appendChild(e._content)})})}disconnectedCallback(){super.disconnectedCallback(),requestAnimationFrame(()=>{this._grid||this._allCells.forEach(e=>{e._content.parentNode&&e._content.parentNode.removeChild(e._content)})}),this._gridValue=void 0}ready(){super.ready(),Ce(this)}_findHostGrid(){let e=this;for(;e&&!/^vaadin.*grid(-pro)?$/u.test(e.localName);)e=e.assignedSlot?e.assignedSlot.parentNode:e.parentNode;return e||void 0}_renderHeaderAndFooter(){this._renderHeaderCellContent(this._headerRenderer,this._headerCell),this._renderFooterCellContent(this._footerRenderer,this._footerCell)}_flexGrowChanged(e){this.parentElement&&this.parentElement._columnPropChanged&&this.parentElement._columnPropChanged("flexGrow"),this._allCells.forEach(t=>{t.style.flexGrow=e})}_orderChanged(e){this._allCells.forEach(t=>{t.style.order=e})}_widthChanged(e){this.parentElement&&this.parentElement._columnPropChanged&&this.parentElement._columnPropChanged("width"),this._allCells.forEach(t=>{t.style.width=e})}_frozenChanged(e){this.parentElement&&this.parentElement._columnPropChanged&&this.parentElement._columnPropChanged("frozen",e),this._allCells.forEach(t=>{U(t,"frozen",e)}),this._grid&&this._grid._frozenCellsChanged&&this._grid._frozenCellsChanged()}_frozenToEndChanged(e){this.parentElement&&this.parentElement._columnPropChanged&&this.parentElement._columnPropChanged("frozenToEnd",e),this._allCells.forEach(t=>{this._grid&&t.parentElement===this._grid.$.sizer||U(t,"frozen-to-end",e)}),this._grid&&this._grid._frozenCellsChanged&&this._grid._frozenCellsChanged()}_lastFrozenChanged(e){this._allCells.forEach(t=>{U(t,"last-frozen",e)}),this.parentElement&&this.parentElement._columnPropChanged&&(this.parentElement._lastFrozen=e)}_firstFrozenToEndChanged(e){this._allCells.forEach(t=>{this._grid&&t.parentElement===this._grid.$.sizer||U(t,"first-frozen-to-end",e)}),this.parentElement&&this.parentElement._columnPropChanged&&(this.parentElement._firstFrozenToEnd=e)}_rowHeaderChanged(e,t){t&&t.forEach(i=>{i.setAttribute("role",e?"rowheader":"gridcell")})}_generateHeader(e){return e.substr(e.lastIndexOf(".")+1).replace(/([A-Z])/gu,"-$1").toLowerCase().replace(/-/gu," ").replace(/^./u,t=>t.toUpperCase())}_reorderStatusChanged(e){const t=this.__previousReorderStatus,i=t?`reorder-${t}-cell`:"",s=`reorder-${e}-cell`;this._allCells.forEach(o=>{U(o,"reorder-status",e,s,i)}),this.__previousReorderStatus=e}_resizableChanged(e,t){e===void 0||t===void 0||t&&[t].concat(this._emptyCells).forEach(i=>{if(i){const s=i.querySelector('[part~="resize-handle"]');if(s&&i.removeChild(s),e){const o=document.createElement("div");o.setAttribute("part","resize-handle"),i.appendChild(o)}}})}_textAlignChanged(e){if(e===void 0||this._grid===void 0)return;if(["start","end","center"].indexOf(e)===-1){console.warn('textAlign can only be set as "start", "end" or "center"');return}let t;getComputedStyle(this._grid).direction==="ltr"?e==="start"?t="left":e==="end"&&(t="right"):e==="start"?t="right":e==="end"&&(t="left"),this._allCells.forEach(i=>{i._content.style.textAlign=e,getComputedStyle(i._content).textAlign!==e&&(i._content.style.textAlign=t)})}_hiddenChanged(e){this.parentElement&&this.parentElement._columnPropChanged&&this.parentElement._columnPropChanged("hidden",e),!!e!=!!this._previousHidden&&this._grid&&(e===!0&&this._allCells.forEach(t=>{t._content.parentNode&&t._content.parentNode.removeChild(t._content)}),this._grid._debouncerHiddenChanged=A.debounce(this._grid._debouncerHiddenChanged,J,()=>{this._grid&&this._grid._renderColumnTree&&this._grid._renderColumnTree(this._grid._columnTree)}),this._grid._debounceUpdateFrozenColumn&&this._grid._debounceUpdateFrozenColumn(),this._grid._resetKeyboardNavigation&&this._grid._resetKeyboardNavigation()),this._previousHidden=e}_runRenderer(e,t,i){const s=i&&i.item&&!t.parentElement.hidden;if(!(s||e===this._headerRenderer||e===this._footerRenderer))return;const l=[t._content,this];s&&l.push(i),e.apply(this,l)}__renderCellsContent(e,t){this.hidden||!this._grid||t.forEach(i=>{if(!i.parentElement)return;const s=this._grid.__getRowModel(i.parentElement);e&&(i._renderer!==e&&this._clearCellContent(i),i._renderer=e,this._runRenderer(e,i,s))})}_clearCellContent(e){e._content.innerHTML="",delete e._content._$litPart$}_renderHeaderCellContent(e,t){!t||!e||(this.__renderCellsContent(e,[t]),this._grid&&t.parentElement&&this._grid.__debounceUpdateHeaderFooterRowVisibility(t.parentElement))}_onHeaderRendererOrBindingChanged(e,t,...i){this._renderHeaderCellContent(e,t)}__headerFooterPartNameChanged(e,t,i,s){[{cell:e,partName:i},{cell:t,partName:s}].forEach(({cell:o,partName:l})=>{if(o){const u=o.__customParts||[];o.part.remove(...u),o.__customParts=l?l.trim().split(" "):[],o.part.add(...o.__customParts)}})}_renderBodyCellsContent(e,t){!t||!e||this.__renderCellsContent(e,t)}_onRendererOrBindingChanged(e,t,...i){this._renderBodyCellsContent(e,t)}_renderFooterCellContent(e,t){!t||!e||(this.__renderCellsContent(e,[t]),this._grid&&t.parentElement&&this._grid.__debounceUpdateHeaderFooterRowVisibility(t.parentElement))}_onFooterRendererOrBindingChanged(e,t){this._renderFooterCellContent(e,t)}__setTextContent(e,t){e.textContent!==t&&(e.textContent=t)}__textHeaderRenderer(){this.__setTextContent(this._headerCell._content,this.header)}_defaultHeaderRenderer(){this.path&&this.__setTextContent(this._headerCell._content,this._generateHeader(this.path))}_defaultRenderer(e,t,{item:i}){this.path&&this.__setTextContent(e,ve(this.path,i))}_defaultFooterRenderer(){}_computeHeaderRenderer(e,t){return e||(t!=null?this.__textHeaderRenderer:this._defaultHeaderRenderer)}_computeRenderer(e){return e||this._defaultRenderer}_computeFooterRenderer(e){return e||this._defaultFooterRenderer}},yt=n=>class extends Ue(re(n)){static get properties(){return{width:{type:String,value:"100px",sync:!0},flexGrow:{type:Number,value:1,sync:!0},renderer:{type:Function,sync:!0},_renderer:{type:Function,computed:"_computeRenderer(renderer, __initialized)"},path:{type:String,sync:!0},autoWidth:{type:Boolean,value:!1},_focusButtonMode:{type:Boolean,value:!1},_cells:{type:Array,sync:!0}}}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */class qe extends yt(G){static get is(){return"vaadin-grid-column"}}N(qe);/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const xt=n=>class extends n{static get properties(){return{accessibleName:{type:String}}}static get observers(){return["_a11yUpdateGridSize(size, _columnTree, __emptyState)"]}_a11yGetHeaderRowCount(e){return e.filter(t=>t.some(i=>i.headerRenderer||i.path&&i.header!==null||i.header)).length}_a11yGetFooterRowCount(e){return e.filter(t=>t.some(i=>i.footerRenderer)).length}_a11yUpdateGridSize(e,t,i){if(e===void 0||t===void 0)return;const s=this._a11yGetHeaderRowCount(t),o=this._a11yGetFooterRowCount(t),u=(i?1:e)+s+o;this.$.table.setAttribute("aria-rowcount",u);const p=t[t.length-1],_=i?1:u&&p&&p.length||0;this.$.table.setAttribute("aria-colcount",_),this._a11yUpdateHeaderRows(),this._a11yUpdateFooterRows()}_a11yUpdateHeaderRows(){R(this.$.header,(e,t)=>{e.setAttribute("aria-rowindex",t+1)})}_a11yUpdateFooterRows(){R(this.$.footer,(e,t)=>{e.setAttribute("aria-rowindex",this._a11yGetHeaderRowCount(this._columnTree)+this.size+t+1)})}_a11yUpdateRowRowindex(e,t){e.setAttribute("aria-rowindex",t+this._a11yGetHeaderRowCount(this._columnTree)+1)}_a11yUpdateRowSelected(e,t){e.setAttribute("aria-selected",!!t),Z(e,i=>{i.setAttribute("aria-selected",!!t)})}_a11yUpdateRowExpanded(e){const t=vt(e);this.__isRowExpandable(e)?(e.setAttribute("aria-expanded","false"),t&&t.setAttribute("aria-expanded","false")):this.__isRowCollapsible(e)?(e.setAttribute("aria-expanded","true"),t&&t.setAttribute("aria-expanded","true")):(e.removeAttribute("aria-expanded"),t&&t.removeAttribute("aria-expanded"))}_a11yUpdateRowLevel(e,t){t>0||this.__isRowCollapsible(e)||this.__isRowExpandable(e)?e.setAttribute("aria-level",t+1):e.removeAttribute("aria-level")}_a11ySetRowDetailsCell(e,t){Z(e,i=>{i!==t&&i.setAttribute("aria-controls",t.id)})}_a11yUpdateCellColspan(e,t){e.setAttribute("aria-colspan",Number(t))}_a11yUpdateSorters(){Array.from(this.querySelectorAll("vaadin-grid-sorter")).forEach(e=>{let t=e.parentNode;for(;t&&t.localName!=="vaadin-grid-cell-content";)t=t.parentNode;t&&t.assignedSlot&&t.assignedSlot.parentNode.setAttribute("aria-sort",{asc:"ascending",desc:"descending"}[String(e.direction)]||"none")})}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const Ke=n=>n.offsetParent&&!n.part.contains("body-cell")&&ke(n)&&getComputedStyle(n).visibility!=="hidden",At=n=>class extends n{static get properties(){return{activeItem:{type:Object,notify:!0,value:null,sync:!0}}}ready(){super.ready(),this.$.scroller.addEventListener("click",this._onClick.bind(this)),this.addEventListener("cell-activate",this._activateItem.bind(this)),this.addEventListener("row-activate",this._activateItem.bind(this))}_activateItem(e){const t=e.detail.model,i=t?t.item:null;i&&(this.activeItem=this._itemsEqual(this.activeItem,i)?null:i)}_shouldPreventCellActivationOnClick(e){const{cell:t}=this._getGridEventLocation(e);return e.defaultPrevented||!t||t.getAttribute("part").includes("details-cell")||t===this.$.emptystatecell||t._content.contains(this.getRootNode().activeElement)||this._isFocusable(e.target)||e.target instanceof HTMLLabelElement}_onClick(e){if(this._shouldPreventCellActivationOnClick(e))return;const{cell:t}=this._getGridEventLocation(e);t&&this.dispatchEvent(new CustomEvent("cell-activate",{detail:{model:this.__getRowModel(t.parentElement)}}))}_isFocusable(e){return Ke(e)}};function Q(n,r){return n.split(".").reduce((e,t)=>e[t],r)}function Te(n,r,e){if(e.length===0)return!1;let t=!0;return n.forEach(({path:i})=>{if(!i||i.indexOf(".")===-1)return;const s=i.replace(/\.[^.]*$/u,"");Q(s,e[0])===void 0&&(console.warn(`Path "${i}" used for ${r} does not exist in all of the items, ${r} is disabled.`),t=!1)}),t}function _e(n){return[void 0,null].indexOf(n)>=0?"":isNaN(n)?n.toString():n}function Oe(n,r){return n=_e(n),r=_e(r),n<r?-1:n>r?1:0}function wt(n,r){return n.sort((e,t)=>r.map(i=>i.direction==="asc"?Oe(Q(i.path,e),Q(i.path,t)):i.direction==="desc"?Oe(Q(i.path,t),Q(i.path,e)):0).reduce((i,s)=>i!==0?i:s,0))}function Et(n,r){return n.filter(e=>r.every(t=>{const i=_e(Q(t.path,e)),s=_e(t.value).toString().toLowerCase();return i.toString().toLowerCase().includes(s)}))}const It=n=>(r,e)=>{let t=n?[...n]:[];r.filters&&Te(r.filters,"filtering",t)&&(t=Et(t,r.filters)),Array.isArray(r.sortOrders)&&r.sortOrders.length&&Te(r.sortOrders,"sorting",t)&&(t=wt(t,r.sortOrders));const i=Math.min(t.length,r.pageSize),s=r.page*i,o=s+i,l=t.slice(s,o);e(l,t.length)};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const St=n=>class extends n{static get properties(){return{items:{type:Array,sync:!0}}}static get observers(){return["__dataProviderOrItemsChanged(dataProvider, items, isAttached, items.*)"]}__setArrayDataProvider(e){const t=It(this.items);t.__items=e,this._arrayDataProvider=t,this.size=e.length,this.dataProvider=t}_onDataProviderPageReceived(){super._onDataProviderPageReceived(),this._arrayDataProvider&&(this.size=this._flatSize)}__dataProviderOrItemsChanged(e,t,i){i&&(this._arrayDataProvider?e!==this._arrayDataProvider?(this._arrayDataProvider=void 0,this.items=void 0):t?this._arrayDataProvider.__items===t?this.clearCache():this.__setArrayDataProvider(t):(this._arrayDataProvider=void 0,this.dataProvider=void 0,this.size=0,this.clearCache()):t&&this.__setArrayDataProvider(t))}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const Rt=n=>class extends n{static get properties(){return{__pendingRecalculateColumnWidths:{type:Boolean,value:!0}}}static get observers(){return["__dataProviderChangedAutoWidth(dataProvider)","__columnTreeChangedAutoWidth(_columnTree)","__flatSizeChangedAutoWidth(_flatSize)"]}constructor(){super(),this.addEventListener("animationend",this.__onAnimationEndAutoWidth)}__onAnimationEndAutoWidth(r){r.animationName.indexOf("vaadin-grid-appear")===0&&this.__tryToRecalculateColumnWidthsIfPending()}__dataProviderChangedAutoWidth(r){this.__hasHadRenderedRowsForColumnWidthCalculation||this.recalculateColumnWidths()}__columnTreeChangedAutoWidth(r){queueMicrotask(()=>this.recalculateColumnWidths())}__flatSizeChangedAutoWidth(r){requestAnimationFrame(()=>{r&&!this.__hasHadRenderedRowsForColumnWidthCalculation?this.recalculateColumnWidths():this.__tryToRecalculateColumnWidthsIfPending()})}_onDataProviderPageLoaded(){super._onDataProviderPageLoaded(),this.__tryToRecalculateColumnWidthsIfPending()}_updateFrozenColumn(){super._updateFrozenColumn(),this.__tryToRecalculateColumnWidthsIfPending()}__getIntrinsicWidth(r){return this.__intrinsicWidthCache.has(r)||this.__calculateAndCacheIntrinsicWidths([r]),this.__intrinsicWidthCache.get(r)}__getDistributedWidth(r,e){if(r==null||r===this)return 0;const t=Math.max(this.__getIntrinsicWidth(r),this.__getDistributedWidth(this.__getParentColumnGroup(r),r));if(!e)return t;const i=r,s=t,o=i._visibleChildColumns.map(_=>this.__getIntrinsicWidth(_)).reduce((_,g)=>_+g,0),l=Math.max(0,s-o),p=this.__getIntrinsicWidth(e)/o*l;return this.__getIntrinsicWidth(e)+p}_recalculateColumnWidths(){this.__virtualizer.flush(),[...this.$.header.children,...this.$.footer.children].forEach(s=>{s.__debounceUpdateHeaderFooterRowVisibility&&s.__debounceUpdateHeaderFooterRowVisibility.flush()}),this.__hasHadRenderedRowsForColumnWidthCalculation=this.__hasHadRenderedRowsForColumnWidthCalculation||this._getRenderedRows().length>0,this.__intrinsicWidthCache=new Map;const r=this._firstVisibleIndex,e=this._lastVisibleIndex;this.__viewportRowsCache=this._getRenderedRows().filter(s=>s.index>=r&&s.index<=e);const t=this.__getAutoWidthColumns(),i=new Set;for(const s of t){let o=this.__getParentColumnGroup(s);for(;o&&!i.has(o);)i.add(o),o=this.__getParentColumnGroup(o)}this.__calculateAndCacheIntrinsicWidths([...t,...i]),t.forEach(s=>{s.width=`${this.__getDistributedWidth(s)}px`}),this.__intrinsicWidthCache.clear()}__getParentColumnGroup(r){const e=(r.assignedSlot||r).parentElement;return e&&e!==this?e:null}__setVisibleCellContentAutoWidth(r,e){r._allCells.filter(t=>this.$.items.contains(t)?this.__viewportRowsCache.includes(t.parentElement):!0).forEach(t=>{t.__measuringAutoWidth=e,t.__measuringAutoWidth?(t.__originalWidth=t.style.width,t.style.width="auto",t.style.position="absolute"):(t.style.width=t.__originalWidth,delete t.__originalWidth,t.style.position="")}),e?this.$.scroller.setAttribute("measuring-auto-width",""):this.$.scroller.removeAttribute("measuring-auto-width")}__getAutoWidthCellsMaxWidth(r){return r._allCells.reduce((e,t)=>t.__measuringAutoWidth?Math.max(e,t.offsetWidth+1):e,0)}__calculateAndCacheIntrinsicWidths(r){r.forEach(e=>this.__setVisibleCellContentAutoWidth(e,!0)),r.forEach(e=>{const t=this.__getAutoWidthCellsMaxWidth(e);this.__intrinsicWidthCache.set(e,t)}),r.forEach(e=>this.__setVisibleCellContentAutoWidth(e,!1))}recalculateColumnWidths(){if(!this.__isReadyForColumnWidthCalculation()){this.__pendingRecalculateColumnWidths=!0;return}this._recalculateColumnWidths()}__tryToRecalculateColumnWidthsIfPending(){this.__pendingRecalculateColumnWidths&&(this.__pendingRecalculateColumnWidths=!1,this.recalculateColumnWidths())}__getAutoWidthColumns(){return this._getColumns().filter(r=>!r.hidden&&r.autoWidth)}__isReadyForColumnWidthCalculation(){if(!this._columnTree)return!1;const r=this.__getAutoWidthColumns().filter(o=>!customElements.get(o.localName));if(r.length)return Promise.all(r.map(o=>customElements.whenDefined(o.localName))).then(()=>{this.__tryToRecalculateColumnWidthsIfPending()}),!1;const e=[...this.$.items.children].some(o=>o.index===void 0),t=this._debouncerHiddenChanged&&this._debouncerHiddenChanged.isActive(),i=this.__debounceUpdateFrozenColumn&&this.__debounceUpdateFrozenColumn.isActive(),s=this.clientHeight>0;return!this._dataProviderController.isLoading()&&!e&&!me(this)&&!t&&!i&&s}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const zt=n=>class extends n{static get properties(){return{columnReorderingAllowed:{type:Boolean,value:!1},_orderBaseScope:{type:Number,value:1e7}}}static get observers(){return["_updateOrders(_columnTree)"]}ready(){super.ready(),se(this,"track",this._onTrackEvent),this._reorderGhost=this.shadowRoot.querySelector('[part="reorder-ghost"]'),this.addEventListener("touchstart",this._onTouchStart.bind(this)),this.addEventListener("touchmove",this._onTouchMove.bind(this)),this.addEventListener("touchend",this._onTouchEnd.bind(this)),this.addEventListener("contextmenu",this._onContextMenu.bind(this))}_onContextMenu(e){this.hasAttribute("reordering")&&(e.preventDefault(),ye||this._onTrackEnd())}_onTouchStart(e){this._startTouchReorderTimeout=setTimeout(()=>{this._onTrackStart({detail:{x:e.touches[0].clientX,y:e.touches[0].clientY}})},100)}_onTouchMove(e){this._draggedColumn&&e.preventDefault(),clearTimeout(this._startTouchReorderTimeout)}_onTouchEnd(){clearTimeout(this._startTouchReorderTimeout),this._onTrackEnd()}_onTrackEvent(e){if(e.detail.state==="start"){const t=e.composedPath(),i=t[t.indexOf(this.$.header)-2];if(!i||!i._content||i._content.contains(this.getRootNode().activeElement)||this.$.scroller.hasAttribute("column-resizing"))return;this._touchDevice||this._onTrackStart(e)}else e.detail.state==="track"?this._onTrack(e):e.detail.state==="end"&&this._onTrackEnd(e)}_onTrackStart(e){if(!this.columnReorderingAllowed)return;const t=e.composedPath&&e.composedPath();if(t&&t.slice(0,Math.max(0,t.indexOf(this))).some(s=>s.draggable))return;const i=this._cellFromPoint(e.detail.x,e.detail.y);if(!(!i||!i.getAttribute("part").includes("header-cell"))){for(this.toggleAttribute("reordering",!0),this._draggedColumn=i._column;this._draggedColumn.parentElement.childElementCount===1;)this._draggedColumn=this._draggedColumn.parentElement;this._setSiblingsReorderStatus(this._draggedColumn,"allowed"),this._draggedColumn._reorderStatus="dragging",this._updateGhost(i),this._reorderGhost.style.visibility="visible",this._updateGhostPosition(e.detail.x,this._touchDevice?e.detail.y-50:e.detail.y),this._autoScroller()}}_onTrack(e){if(!this._draggedColumn)return;const t=this._cellFromPoint(e.detail.x,e.detail.y);if(!t)return;const i=this._getTargetColumn(t,this._draggedColumn);if(this._isSwapAllowed(this._draggedColumn,i)&&this._isSwappableByPosition(i,e.detail.x)){const s=this._columnTree.findIndex(_=>_.includes(i)),o=this._getColumnsInOrder(s),l=o.indexOf(this._draggedColumn),u=o.indexOf(i),p=l<u?1:-1;for(let _=l;_!==u;_+=p)this._swapColumnOrders(this._draggedColumn,o[_+p])}this._updateGhostPosition(e.detail.x,this._touchDevice?e.detail.y-50:e.detail.y),this._lastDragClientX=e.detail.x}_onTrackEnd(){this._draggedColumn&&(this.toggleAttribute("reordering",!1),this._draggedColumn._reorderStatus="",this._setSiblingsReorderStatus(this._draggedColumn,""),this._draggedColumn=null,this._lastDragClientX=null,this._reorderGhost.style.visibility="hidden",this.dispatchEvent(new CustomEvent("column-reorder",{detail:{columns:this._getColumnsInOrder()}})))}_getColumnsInOrder(e=this._columnTree.length-1){return this._columnTree[e].filter(t=>!t.hidden).sort((t,i)=>t._order-i._order)}_cellFromPoint(e=0,t=0){this._draggedColumn||this.$.scroller.toggleAttribute("no-content-pointer-events",!0);const i=this.shadowRoot.elementFromPoint(e,t);return this.$.scroller.toggleAttribute("no-content-pointer-events",!1),this._getCellFromElement(i)}_getCellFromElement(e){if(e){if(e._column)return e;const{parentElement:t}=e;if(t&&t._focusButton===e)return t}return null}_updateGhostPosition(e,t){const i=this._reorderGhost.getBoundingClientRect(),s=e-i.width/2,o=t-i.height/2,l=parseInt(this._reorderGhost._left||0),u=parseInt(this._reorderGhost._top||0);this._reorderGhost._left=l-(i.left-s),this._reorderGhost._top=u-(i.top-o),this._reorderGhost.style.transform=`translate(${this._reorderGhost._left}px, ${this._reorderGhost._top}px)`}_updateGhost(e){const t=this._reorderGhost;t.textContent=e._content.innerText;const i=window.getComputedStyle(e);return["boxSizing","display","width","height","background","alignItems","padding","border","flex-direction","overflow"].forEach(s=>{t.style[s]=i[s]}),t}_updateOrders(e){e!==void 0&&(e[0].forEach(t=>{t._order=0}),Ve(e[0],this._orderBaseScope,0))}_setSiblingsReorderStatus(e,t){R(e.parentNode,i=>{/column/u.test(i.localName)&&this._isSwapAllowed(i,e)&&(i._reorderStatus=t)})}_autoScroller(){if(this._lastDragClientX){const e=this._lastDragClientX-this.getBoundingClientRect().right+50,t=this.getBoundingClientRect().left-this._lastDragClientX+50;e>0?this.$.table.scrollLeft+=e/10:t>0&&(this.$.table.scrollLeft-=t/10)}this._draggedColumn&&setTimeout(()=>this._autoScroller(),10)}_isSwapAllowed(e,t){if(e&&t){const i=e!==t,s=e.parentElement===t.parentElement,o=e.frozen&&t.frozen||e.frozenToEnd&&t.frozenToEnd||!e.frozen&&!e.frozenToEnd&&!t.frozen&&!t.frozenToEnd;return i&&s&&o}}_isSwappableByPosition(e,t){const i=Array.from(this.$.header.querySelectorAll('tr:not([hidden]) [part~="cell"]')).find(l=>e.contains(l._column)),s=this.$.header.querySelector("tr:not([hidden]) [reorder-status=dragging]").getBoundingClientRect(),o=i.getBoundingClientRect();return o.left>s.left?t>o.right-s.width:t<o.left+s.width}_swapColumnOrders(e,t){[e._order,t._order]=[t._order,e._order],this._debounceUpdateFrozenColumn(),this._updateFirstAndLastColumn()}_getTargetColumn(e,t){if(e&&t){let i=e._column;for(;i.parentElement!==t.parentElement&&i!==this;)i=i.parentElement;return i.parentElement===t.parentElement?i:e._column}}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const Ft=n=>class extends n{ready(){super.ready();const e=this.$.scroller;se(e,"track",this._onHeaderTrack.bind(this)),e.addEventListener("touchmove",t=>e.hasAttribute("column-resizing")&&t.preventDefault()),e.addEventListener("contextmenu",t=>t.target.getAttribute("part")==="resize-handle"&&t.preventDefault()),e.addEventListener("mousedown",t=>t.target.getAttribute("part")==="resize-handle"&&t.preventDefault())}_onHeaderTrack(e){const t=e.target;if(t.getAttribute("part")==="resize-handle"){let s=t.parentElement._column;for(this.$.scroller.toggleAttribute("column-resizing",!0);s.localName==="vaadin-grid-column-group";)s=s._childColumns.slice(0).sort((g,f)=>g._order-f._order).filter(g=>!g.hidden).pop();const o=this.__isRTL,l=e.detail.x,u=Array.from(this.$.header.querySelectorAll('[part~="row"]:last-child [part~="cell"]')),p=u.find(g=>g._column===s);if(p.offsetWidth){const g=getComputedStyle(p._content),f=10+parseInt(g.paddingLeft)+parseInt(g.paddingRight)+parseInt(g.borderLeftWidth)+parseInt(g.borderRightWidth)+parseInt(g.marginLeft)+parseInt(g.marginRight);let x;const S=p.offsetWidth,z=p.getBoundingClientRect();p.hasAttribute("frozen-to-end")?x=S+(o?l-z.right:z.left-l):x=S+(o?z.left-l:l-z.right),s.width=`${Math.max(f,x)}px`,s.flexGrow=0}u.sort((g,f)=>g._column._order-f._column._order).forEach((g,f,x)=>{f<x.indexOf(p)&&(g._column.width=`${g.offsetWidth}px`,g._column.flexGrow=0)});const _=this._frozenToEndCells[0];if(_&&this.$.table.scrollWidth>this.$.table.offsetWidth){const g=_.getBoundingClientRect(),f=l-(o?g.right:g.left);(o&&f<=0||!o&&f>=0)&&(this.$.table.scrollLeft+=f)}e.detail.state==="end"&&(this.$.scroller.toggleAttribute("column-resizing",!1),this.dispatchEvent(new CustomEvent("column-resize",{detail:{resizedColumn:s}}))),this._resizeHandler()}}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const Tt=n=>class extends n{static get properties(){return{size:{type:Number,notify:!0,sync:!0},_flatSize:{type:Number,sync:!0},pageSize:{type:Number,value:50,observer:"_pageSizeChanged",sync:!0},dataProvider:{type:Object,notify:!0,observer:"_dataProviderChanged",sync:!0},loading:{type:Boolean,notify:!0,readOnly:!0,reflectToAttribute:!0},_hasData:{type:Boolean,value:!1,sync:!0},itemHasChildrenPath:{type:String,value:"children",observer:"__itemHasChildrenPathChanged",sync:!0},itemIdPath:{type:String,value:null,sync:!0},expandedItems:{type:Object,notify:!0,value:()=>[],sync:!0},__expandedKeys:{type:Object,computed:"__computeExpandedKeys(itemIdPath, expandedItems)"}}}static get observers(){return["_sizeChanged(size)","_expandedItemsChanged(expandedItems)"]}constructor(){super(),this._dataProviderController=new Je(this,{size:this.size||0,pageSize:this.pageSize,getItemId:this.getItemId.bind(this),isExpanded:this._isExpanded.bind(this),dataProvider:this.dataProvider?this.dataProvider.bind(this):null,dataProviderParams:()=>({sortOrders:this._mapSorters(),filters:this._mapFilters()})}),this._dataProviderController.addEventListener("page-requested",this._onDataProviderPageRequested.bind(this)),this._dataProviderController.addEventListener("page-received",this._onDataProviderPageReceived.bind(this)),this._dataProviderController.addEventListener("page-loaded",this._onDataProviderPageLoaded.bind(this))}get _cache(){return console.warn("<vaadin-grid> The `_cache` property is deprecated and will be removed in Vaadin 25."),this._dataProviderController.rootCache}get _effectiveSize(){return console.warn("<vaadin-grid> The `_effectiveSize` property is deprecated and will be removed in Vaadin 25."),this._flatSize}_sizeChanged(e){this._dataProviderController.rootCache.size=e,this._dataProviderController.recalculateFlatSize(),this._flatSize=this._dataProviderController.flatSize}__itemHasChildrenPathChanged(e,t){!t&&e==="children"||this.requestContentUpdate()}_getItem(e,t){t.index=e;const{item:i}=this._dataProviderController.getFlatIndexContext(e);i?(this.__updateLoading(t,!1),this._updateItem(t,i),this._isExpanded(i)&&this._dataProviderController.ensureFlatIndexHierarchy(e)):(this.__updateLoading(t,!0),this._dataProviderController.ensureFlatIndexLoaded(e))}__updateLoading(e,t){const i=K(e);fe(e,"loading",t),k(i,"loading-row-cell",t),t&&(this._generateCellClassNames(e),this._generateCellPartNames(e))}getItemId(e){return this.itemIdPath?ve(this.itemIdPath,e):e}_isExpanded(e){return this.__expandedKeys&&this.__expandedKeys.has(this.getItemId(e))}_expandedItemsChanged(){this._dataProviderController.recalculateFlatSize(),this._flatSize=this._dataProviderController.flatSize,this.__updateVisibleRows()}__computeExpandedKeys(e,t){const i=t||[],s=new Set;return i.forEach(o=>{s.add(this.getItemId(o))}),s}expandItem(e){this._isExpanded(e)||(this.expandedItems=[...this.expandedItems,e])}collapseItem(e){this._isExpanded(e)&&(this.expandedItems=this.expandedItems.filter(t=>!this._itemsEqual(t,e)))}_getIndexLevel(e=0){const{level:t}=this._dataProviderController.getFlatIndexContext(e);return t}_loadPage(e,t){console.warn("<vaadin-grid> The `_loadPage` method is deprecated and will be removed in Vaadin 25."),this._dataProviderController.__loadCachePage(t,e)}_onDataProviderPageRequested(){this._setLoading(!0)}_onDataProviderPageReceived(){this._flatSize!==this._dataProviderController.flatSize&&(this._shouldUpdateAllRenderedRowsAfterPageLoad=!0,this._flatSize=this._dataProviderController.flatSize),this._getRenderedRows().forEach(e=>{this._dataProviderController.ensureFlatIndexHierarchy(e.index)}),this._hasData=!0}_onDataProviderPageLoaded(){this._debouncerApplyCachedData=A.debounce(this._debouncerApplyCachedData,q.after(0),()=>{this._setLoading(!1);const e=this._shouldUpdateAllRenderedRowsAfterPageLoad;this._shouldUpdateAllRenderedRowsAfterPageLoad=!1,this._getRenderedRows().forEach(t=>{const{item:i}=this._dataProviderController.getFlatIndexContext(t.index);(i||e)&&this._getItem(t.index,t)}),this.__scrollToPendingIndexes(),this.__dispatchPendingBodyCellFocus()}),this._dataProviderController.isLoading()||this._debouncerApplyCachedData.flush()}__debounceClearCache(){this.__clearCacheDebouncer=A.debounce(this.__clearCacheDebouncer,X,()=>this.clearCache())}clearCache(){this._dataProviderController.clearCache(),this._dataProviderController.rootCache.size=this.size||0,this._dataProviderController.recalculateFlatSize(),this._hasData=!1,this.__updateVisibleRows(),(!this.__virtualizer||!this.__virtualizer.size)&&this._dataProviderController.loadFirstPage()}_pageSizeChanged(e,t){this._dataProviderController.setPageSize(e),t!==void 0&&e!==t&&this.clearCache()}_checkSize(){this.size===void 0&&this._flatSize===0&&console.warn("The <vaadin-grid> needs the total number of items in order to display rows, which you can specify either by setting the `size` property, or by providing it to the second argument of the `dataProvider` function `callback` call.")}_dataProviderChanged(e,t){this._dataProviderController.setDataProvider(e?e.bind(this):null),t!==void 0&&this.clearCache(),this._ensureFirstPageLoaded(),this._debouncerCheckSize=A.debounce(this._debouncerCheckSize,q.after(2e3),this._checkSize.bind(this))}_ensureFirstPageLoaded(){this._hasData||this._dataProviderController.loadFirstPage()}_itemsEqual(e,t){return this.getItemId(e)===this.getItemId(t)}_getItemIndexInArray(e,t){let i=-1;return t.forEach((s,o)=>{this._itemsEqual(s,e)&&(i=o)}),i}scrollToIndex(...e){if(!this.__virtualizer||!this.clientHeight||!this._columnTree){this.__pendingScrollToIndexes=e;return}let t;for(;t!==(t=this._dataProviderController.getFlatIndexByPath(e));)this._scrollToFlatIndex(t);this._dataProviderController.isLoading()&&(this.__pendingScrollToIndexes=e)}__scrollToPendingIndexes(){if(this.__pendingScrollToIndexes&&this.$.items.children.length){const e=this.__pendingScrollToIndexes;delete this.__pendingScrollToIndexes,this.scrollToIndex(...e)}}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const ie={BETWEEN:"between",ON_TOP_OR_BETWEEN:"on-top-or-between",ON_GRID:"on-grid"},M={ON_TOP:"on-top",ABOVE:"above",BELOW:"below",EMPTY:"empty"},Ot=n=>class extends n{static get properties(){return{dropMode:{type:String,sync:!0},rowsDraggable:{type:Boolean,sync:!0},dragFilter:{type:Function,sync:!0},dropFilter:{type:Function,sync:!0},__dndAutoScrollThreshold:{value:50},__draggedItems:{value:()=>[]}}}static get observers(){return["_dragDropAccessChanged(rowsDraggable, dropMode, dragFilter, dropFilter, loading)"]}constructor(){super(),this.__onDocumentDragStart=this.__onDocumentDragStart.bind(this)}ready(){super.ready(),this.$.table.addEventListener("dragstart",this._onDragStart.bind(this)),this.$.table.addEventListener("dragend",this._onDragEnd.bind(this)),this.$.table.addEventListener("dragover",this._onDragOver.bind(this)),this.$.table.addEventListener("dragleave",this._onDragLeave.bind(this)),this.$.table.addEventListener("drop",this._onDrop.bind(this)),this.$.table.addEventListener("dragenter",e=>{this.dropMode&&(e.preventDefault(),e.stopPropagation())})}connectedCallback(){super.connectedCallback(),document.addEventListener("dragstart",this.__onDocumentDragStart,{capture:!0})}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("dragstart",this.__onDocumentDragStart,{capture:!0})}_onDragStart(e){if(this.rowsDraggable){let t=e.target;if(t.localName==="vaadin-grid-cell-content"&&(t=t.assignedSlot.parentNode.parentNode),t.parentNode!==this.$.items)return;if(e.stopPropagation(),this.toggleAttribute("dragging-rows",!0),this._safari){const l=t.style.transform;t.style.top=/translateY\((.*)\)/u.exec(l)[1],t.style.transform="none",requestAnimationFrame(()=>{t.style.top="",t.style.transform=l})}const i=t.getBoundingClientRect();e.dataTransfer.setDragImage(t,e.clientX-i.left,e.clientY-i.top);let s=[t];this._isSelected(t._item)&&(s=this.__getViewportRows().filter(l=>this._isSelected(l._item)).filter(l=>!this.dragFilter||this.dragFilter(this.__getRowModel(l)))),this.__draggedItems=s.map(l=>l._item),e.dataTransfer.setData("text",this.__formatDefaultTransferData(s)),j(t,{dragstart:s.length>1?`${s.length}`:""}),this.style.setProperty("--_grid-drag-start-x",`${e.clientX-i.left+20}px`),this.style.setProperty("--_grid-drag-start-y",`${e.clientY-i.top+10}px`),requestAnimationFrame(()=>{j(t,{dragstart:!1}),this.style.setProperty("--_grid-drag-start-x",""),this.style.setProperty("--_grid-drag-start-y",""),this.requestContentUpdate()});const o=new CustomEvent("grid-dragstart",{detail:{draggedItems:[...this.__draggedItems],setDragData:(l,u)=>e.dataTransfer.setData(l,u),setDraggedItemsCount:l=>t.setAttribute("dragstart",l)}});o.originalEvent=e,this.dispatchEvent(o)}}_onDragEnd(e){this.toggleAttribute("dragging-rows",!1),e.stopPropagation();const t=new CustomEvent("grid-dragend");t.originalEvent=e,this.dispatchEvent(t),this.__draggedItems=[],this.requestContentUpdate()}_onDragLeave(e){this.dropMode&&(e.stopPropagation(),this._clearDragStyles())}_onDragOver(e){if(this.dropMode){if(this._dropLocation=void 0,this._dragOverItem=void 0,this.__dndAutoScroll(e.clientY)){this._clearDragStyles();return}let t=e.composedPath().find(i=>i.localName==="tr");if(!this._flatSize||this.dropMode===ie.ON_GRID)this._dropLocation=M.EMPTY;else if(!t||t.parentNode!==this.$.items){if(t)return;if(this.dropMode===ie.BETWEEN||this.dropMode===ie.ON_TOP_OR_BETWEEN)t=Array.from(this.$.items.children).filter(i=>!i.hidden).pop(),this._dropLocation=M.BELOW;else return}else{const i=t.getBoundingClientRect();if(this._dropLocation=M.ON_TOP,this.dropMode===ie.BETWEEN){const s=e.clientY-i.top<i.bottom-e.clientY;this._dropLocation=s?M.ABOVE:M.BELOW}else this.dropMode===ie.ON_TOP_OR_BETWEEN&&(e.clientY-i.top<i.height/3?this._dropLocation=M.ABOVE:e.clientY-i.top>i.height/3*2&&(this._dropLocation=M.BELOW))}if(t&&t.hasAttribute("drop-disabled")){this._dropLocation=void 0;return}e.stopPropagation(),e.preventDefault(),this._dropLocation===M.EMPTY?this.toggleAttribute("dragover",!0):t?(this._dragOverItem=t._item,t.getAttribute("dragover")!==this._dropLocation&&Fe(t,{dragover:this._dropLocation})):this._clearDragStyles()}}__onDocumentDragStart(e){if(e.target.contains(this)){const t=[e.target,this.$.items,this.$.scroller],i=t.map(s=>s.style.cssText);this.$.table.scrollHeight>2e4&&(this.$.scroller.style.display="none"),Le&&(e.target.style.willChange="transform"),Be&&(this.$.items.style.flexShrink=1),requestAnimationFrame(()=>{t.forEach((s,o)=>{s.style.cssText=i[o]})})}}__dndAutoScroll(e){if(this.__dndAutoScrolling)return!0;const t=this.$.header.getBoundingClientRect().bottom,i=this.$.footer.getBoundingClientRect().top,s=t-e+this.__dndAutoScrollThreshold,o=e-i+this.__dndAutoScrollThreshold;let l=0;if(o>0?l=o*2:s>0&&(l=-s*2),l){const u=this.$.table.scrollTop;if(this.$.table.scrollTop+=l,u!==this.$.table.scrollTop)return this.__dndAutoScrolling=!0,setTimeout(()=>{this.__dndAutoScrolling=!1},20),!0}}__getViewportRows(){const e=this.$.header.getBoundingClientRect().bottom,t=this.$.footer.getBoundingClientRect().top;return Array.from(this.$.items.children).filter(i=>{const s=i.getBoundingClientRect();return s.bottom>e&&s.top<t})}_clearDragStyles(){this.removeAttribute("dragover"),R(this.$.items,e=>{Fe(e,{dragover:null})})}__updateDragSourceParts(e,t){j(e,{"drag-source":this.__draggedItems.includes(t.item)})}_onDrop(e){if(this.dropMode&&this._dropLocation){e.stopPropagation(),e.preventDefault();const t=e.dataTransfer.types&&Array.from(e.dataTransfer.types).map(s=>({type:s,data:e.dataTransfer.getData(s)}));this._clearDragStyles();const i=new CustomEvent("grid-drop",{bubbles:e.bubbles,cancelable:e.cancelable,detail:{dropTargetItem:this._dragOverItem,dropLocation:this._dropLocation,dragData:t}});i.originalEvent=e,this.dispatchEvent(i)}}__formatDefaultTransferData(e){return e.map(t=>Array.from(t.children).filter(i=>!i.hidden&&i.getAttribute("part").indexOf("details-cell")===-1).sort((i,s)=>i._column._order>s._column._order?1:-1).map(i=>i._content.textContent.trim()).filter(i=>i).join("	")).join(`
`)}_dragDropAccessChanged(){this.filterDragAndDrop()}filterDragAndDrop(){R(this.$.items,e=>{e.hidden||this._filterDragAndDrop(e,this.__getRowModel(e))})}_filterDragAndDrop(e,t){const i=this.loading||e.hasAttribute("loading"),s=!this.rowsDraggable||i||this.dragFilter&&!this.dragFilter(t),o=!this.dropMode||i||this.dropFilter&&!this.dropFilter(t);Z(e,l=>{s?l._content.removeAttribute("draggable"):l._content.setAttribute("draggable",!0)}),j(e,{"drag-disabled":!!s,"drop-disabled":!!o})}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */function Ye(n,r){if(!n||!r||n.length!==r.length)return!1;for(let e=0,t=n.length;e<t;e++)if(n[e]instanceof Array&&r[e]instanceof Array){if(!Ye(n[e],r[e]))return!1}else if(n[e]!==r[e])return!1;return!0}const Pt=n=>class extends n{static get properties(){return{_columnTree:{type:Object,sync:!0}}}ready(){super.ready(),this._addNodeObserver()}_hasColumnGroups(e){return e.some(t=>t.localName==="vaadin-grid-column-group")}_getChildColumns(e){return L.getColumns(e)}_flattenColumnGroups(e){return e.map(t=>t.localName==="vaadin-grid-column-group"?this._getChildColumns(t):[t]).reduce((t,i)=>t.concat(i),[])}_getColumnTree(){const e=L.getColumns(this),t=[e];let i=e;for(;this._hasColumnGroups(i);)i=this._flattenColumnGroups(i),t.push(i);return t}_debounceUpdateColumnTree(){this.__updateColumnTreeDebouncer=A.debounce(this.__updateColumnTreeDebouncer,X,()=>this._updateColumnTree())}_updateColumnTree(){const e=this._getColumnTree();Ye(e,this._columnTree)||(this._columnTree=e)}_addNodeObserver(){this._observer=new L(this,(e,t)=>{const i=t.flatMap(o=>o._allCells),s=o=>i.filter(l=>l&&l._content.contains(o)).length;this.__removeSorters(this._sorters.filter(s)),this.__removeFilters(this._filters.filter(s)),this._debounceUpdateColumnTree(),this._debouncerCheckImports=A.debounce(this._debouncerCheckImports,q.after(2e3),this._checkImports.bind(this)),this._ensureFirstPageLoaded()})}_checkImports(){["vaadin-grid-column-group","vaadin-grid-filter","vaadin-grid-filter-column","vaadin-grid-tree-toggle","vaadin-grid-selection-column","vaadin-grid-sort-column","vaadin-grid-sorter"].forEach(e=>{this.querySelector(e)&&!customElements.get(e)&&console.warn(`Make sure you have imported the required module for <${e}> element.`)})}_updateFirstAndLastColumn(){Array.from(this.shadowRoot.querySelectorAll("tr")).forEach(e=>this._updateFirstAndLastColumnForRow(e))}_updateFirstAndLastColumnForRow(e){Array.from(e.querySelectorAll('[part~="cell"]:not([part~="details-cell"])')).sort((t,i)=>t._column._order-i._column._order).forEach((t,i,s)=>{U(t,"first-column",i===0),U(t,"last-column",i===s.length-1)})}_isColumnElement(e){return e.nodeType===Node.ELEMENT_NODE&&/\bcolumn\b/u.test(e.localName)}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const $t=n=>class extends n{getEventContext(e){const t={},{cell:i}=this._getGridEventLocation(e);return i&&(t.section=["body","header","footer","details"].find(s=>i.getAttribute("part").indexOf(s)>-1),i._column&&(t.column=i._column),(t.section==="body"||t.section==="details")&&Object.assign(t,this.__getRowModel(i.parentElement))),t}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const Dt=n=>class extends n{static get properties(){return{_filters:{type:Array,value:()=>[]}}}constructor(){super(),this._filterChanged=this._filterChanged.bind(this),this.addEventListener("filter-changed",this._filterChanged)}_filterChanged(e){e.stopPropagation(),this.__addFilter(e.target),this.__applyFilters()}__removeFilters(e){e.length!==0&&(this._filters=this._filters.filter(t=>e.indexOf(t)<0),this.__applyFilters())}__addFilter(e){this._filters.indexOf(e)===-1&&this._filters.push(e)}__applyFilters(){this.dataProvider&&this.isAttached&&this.clearCache()}_mapFilters(){return this._filters.map(e=>({path:e.path,value:e.value}))}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */function de(n){return n instanceof HTMLTableRowElement}function ce(n){return n instanceof HTMLTableCellElement}function V(n){return n.matches('[part~="details-cell"]')}const Mt=n=>class extends n{static get properties(){return{_headerFocusable:{type:Object,observer:"_focusableChanged",sync:!0},_itemsFocusable:{type:Object,observer:"_focusableChanged",sync:!0},_footerFocusable:{type:Object,observer:"_focusableChanged",sync:!0},_navigatingIsHidden:Boolean,_focusedItemIndex:{type:Number,value:0},_focusedColumnOrder:Number,_focusedCell:{type:Object,observer:"_focusedCellChanged",sync:!0},interacting:{type:Boolean,value:!1,reflectToAttribute:!0,readOnly:!0,observer:"_interactingChanged"}}}get __rowFocusMode(){return[this._headerFocusable,this._itemsFocusable,this._footerFocusable].some(de)}set __rowFocusMode(e){["_itemsFocusable","_footerFocusable","_headerFocusable"].forEach(t=>{const i=this[t];if(e){const s=i&&i.parentElement;ce(i)?this[t]=s:ce(s)&&(this[t]=s.parentElement)}else if(!e&&de(i)){const s=i.firstElementChild;this[t]=s._focusButton||s}})}get _visibleItemsCount(){return this._lastVisibleIndex-this._firstVisibleIndex-1}ready(){super.ready(),!(this._ios||this._android)&&(this.addEventListener("keydown",this._onKeyDown),this.addEventListener("keyup",this._onKeyUp),this.addEventListener("focusin",this._onFocusIn),this.addEventListener("focusout",this._onFocusOut),this.$.table.addEventListener("focusin",this._onContentFocusIn.bind(this)),this.addEventListener("mousedown",()=>{this.toggleAttribute("navigating",!1),this._isMousedown=!0,this._focusedColumnOrder=void 0}),this.addEventListener("mouseup",()=>{this._isMousedown=!1}))}_focusableChanged(e,t){t&&t.setAttribute("tabindex","-1"),e&&this._updateGridSectionFocusTarget(e)}_focusedCellChanged(e,t){t&&Me(t,"part","focused-cell"),e&&De(e,"part","focused-cell")}_interactingChanged(){this._updateGridSectionFocusTarget(this._headerFocusable),this._updateGridSectionFocusTarget(this._itemsFocusable),this._updateGridSectionFocusTarget(this._footerFocusable)}__updateItemsFocusable(){if(!this._itemsFocusable)return;const e=this.shadowRoot.activeElement===this._itemsFocusable;this._getRenderedRows().forEach(t=>{if(t.index===this._focusedItemIndex)if(this.__rowFocusMode)this._itemsFocusable=t;else{let i=this._itemsFocusable.parentElement,s=this._itemsFocusable;if(i){ce(i)&&(s=i,i=i.parentElement);const o=[...i.children].indexOf(s);this._itemsFocusable=this.__getFocusable(t,t.children[o])}}}),e&&this._itemsFocusable.focus()}_onKeyDown(e){const t=e.key;let i;switch(t){case"ArrowUp":case"ArrowDown":case"ArrowLeft":case"ArrowRight":case"PageUp":case"PageDown":case"Home":case"End":i="Navigation";break;case"Enter":case"Escape":case"F2":i="Interaction";break;case"Tab":i="Tab";break;case" ":i="Space";break}this._detectInteracting(e),this.interacting&&i!=="Interaction"&&(i=void 0),i&&this[`_on${i}KeyDown`](e,t)}__ensureFlatIndexInViewport(e){const t=[...this.$.items.children].find(i=>i.index===e);t?this.__scrollIntoViewport(t):this._scrollToFlatIndex(e)}__isRowExpandable(e){if(this.itemHasChildrenPath){const t=e._item;return!!(t&&ve(this.itemHasChildrenPath,t)&&!this._isExpanded(t))}}__isRowCollapsible(e){return this._isExpanded(e._item)}_onNavigationKeyDown(e,t){e.preventDefault();const i=this.__isRTL,s=e.composedPath().find(de),o=e.composedPath().find(ce);let l=0,u=0;switch(t){case"ArrowRight":l=i?-1:1;break;case"ArrowLeft":l=i?1:-1;break;case"Home":this.__rowFocusMode||e.ctrlKey?u=-1/0:l=-1/0;break;case"End":this.__rowFocusMode||e.ctrlKey?u=1/0:l=1/0;break;case"ArrowDown":u=1;break;case"ArrowUp":u=-1;break;case"PageDown":if(this.$.items.contains(s)){const g=this.__getIndexInGroup(s,this._focusedItemIndex);this._scrollToFlatIndex(g)}u=this._visibleItemsCount;break;case"PageUp":u=-this._visibleItemsCount;break}if(this.__rowFocusMode&&!s||!this.__rowFocusMode&&!o)return;const p=i?"ArrowLeft":"ArrowRight",_=i?"ArrowRight":"ArrowLeft";if(t===p){if(this.__rowFocusMode){if(this.__isRowExpandable(s)){this.expandItem(s._item);return}this.__rowFocusMode=!1,this._onCellNavigation(s.firstElementChild,0,0);return}}else if(t===_)if(this.__rowFocusMode){if(this.__isRowCollapsible(s)){this.collapseItem(s._item);return}}else{const g=[...s.children].sort((f,x)=>f._order-x._order);if(o===g[0]||V(o)){this.__rowFocusMode=!0,this._onRowNavigation(s,0);return}}this.__rowFocusMode?this._onRowNavigation(s,u):this._onCellNavigation(o,l,u)}_onRowNavigation(e,t){const{dstRow:i}=this.__navigateRows(t,e);i&&i.focus()}__getIndexInGroup(e,t){const i=e.parentNode;return i===this.$.items?t!==void 0?t:e.index:[...i.children].indexOf(e)}__navigateRows(e,t,i){const s=this.__getIndexInGroup(t,this._focusedItemIndex),o=t.parentNode,l=(o===this.$.items?this._flatSize:o.children.length)-1;let u=Math.max(0,Math.min(s+e,l));if(o!==this.$.items){if(u>s)for(;u<l&&o.children[u].hidden;)u+=1;else if(u<s)for(;u>0&&o.children[u].hidden;)u-=1;return this.toggleAttribute("navigating",!0),{dstRow:o.children[u]}}let p=!1;if(i){const _=V(i);if(o===this.$.items){const g=t._item,{item:f}=this._dataProviderController.getFlatIndexContext(u);_?p=e===0:p=e===1&&this._isDetailsOpened(g)||e===-1&&u!==s&&this._isDetailsOpened(f),p!==_&&(e===1&&p||e===-1&&!p)&&(u=s)}}return this.__ensureFlatIndexInViewport(u),this._focusedItemIndex=u,this.toggleAttribute("navigating",!0),{dstRow:[...o.children].find(_=>!_.hidden&&_.index===u),dstIsRowDetails:p}}_onCellNavigation(e,t,i){const s=e.parentNode,{dstRow:o,dstIsRowDetails:l}=this.__navigateRows(i,s,e);if(!o)return;let u=[...s.children].indexOf(e);this.$.items.contains(e)&&(u=[...this.$.sizer.children].findIndex(f=>f._column===e._column));const p=V(e),_=s.parentNode,g=this.__getIndexInGroup(s,this._focusedItemIndex);if(this._focusedColumnOrder===void 0&&(p?this._focusedColumnOrder=0:this._focusedColumnOrder=this._getColumns(_,g).filter(f=>!f.hidden)[u]._order),l)[...o.children].find(V).focus();else{const f=this.__getIndexInGroup(o,this._focusedItemIndex),x=this._getColumns(_,f).filter(w=>!w.hidden),S=x.map(w=>w._order).sort((w,O)=>w-O),z=S.length-1,I=S.indexOf(S.slice(0).sort((w,O)=>Math.abs(w-this._focusedColumnOrder)-Math.abs(O-this._focusedColumnOrder))[0]),F=i===0&&p?I:Math.max(0,Math.min(I+t,z));F!==I&&(this._focusedColumnOrder=void 0);const Y=x.reduce((w,O,ae)=>(w[O._order]=ae,w),{})[S[F]];let D;if(this.$.items.contains(e)){const w=this.$.sizer.children[Y];this._lazyColumns&&(this.__isColumnInViewport(w._column)||w.scrollIntoView(),this.__updateColumnsBodyContentHidden(),this.__updateHorizontalScrollPosition()),D=[...o.children].find(O=>O._column===w._column),this._scrollHorizontallyToCell(D)}else D=o.children[Y],this._scrollHorizontallyToCell(D);D.focus()}}_onInteractionKeyDown(e,t){const i=e.composedPath()[0],s=i.localName==="input"&&!/^(button|checkbox|color|file|image|radio|range|reset|submit)$/iu.test(i.type);let o;switch(t){case"Enter":o=this.interacting?!s:!0;break;case"Escape":o=!1;break;case"F2":o=!this.interacting;break}const{cell:l}=this._getGridEventLocation(e);if(this.interacting!==o&&l!==null)if(o){const u=l._content.querySelector("[focus-target]")||[...l._content.querySelectorAll("*")].find(p=>this._isFocusable(p));u&&(e.preventDefault(),u.focus(),this._setInteracting(!0),this.toggleAttribute("navigating",!1))}else e.preventDefault(),this._focusedColumnOrder=void 0,l.focus(),this._setInteracting(!1),this.toggleAttribute("navigating",!0);t==="Escape"&&this._hideTooltip(!0)}_predictFocusStepTarget(e,t){const i=[this.$.table,this._headerFocusable,this.__emptyState?this.$.emptystatecell:this._itemsFocusable,this._footerFocusable,this.$.focusexit];let s=i.indexOf(e);for(s+=t;s>=0&&s<=i.length-1;){let l=i[s];if(l&&!this.__rowFocusMode&&(l=i[s].parentNode),!l||l.hidden)s+=t;else break}let o=i[s];if(o&&!this.__isHorizontallyInViewport(o)){const l=this._getColumnsInOrder().find(u=>this.__isColumnInViewport(u));if(l)if(o===this._headerFocusable)o=l._headerCell;else if(o===this._itemsFocusable){const u=o._column._cells.indexOf(o);o=l._cells[u]}else o===this._footerFocusable&&(o=l._footerCell)}return o}_onTabKeyDown(e){let t=this._predictFocusStepTarget(e.composedPath()[0],e.shiftKey?-1:1);t&&(e.stopPropagation(),t===this._itemsFocusable&&(this.__ensureFlatIndexInViewport(this._focusedItemIndex),this.__updateItemsFocusable(),t=this._itemsFocusable),t.focus(),t!==this.$.table&&t!==this.$.focusexit&&e.preventDefault(),this.toggleAttribute("navigating",!0))}_onSpaceKeyDown(e){e.preventDefault();const t=e.composedPath()[0],i=de(t);(i||!t._content||!t._content.firstElementChild)&&this.dispatchEvent(new CustomEvent(i?"row-activate":"cell-activate",{detail:{model:this.__getRowModel(i?t:t.parentElement)}}))}_onKeyUp(e){if(!/^( |SpaceBar)$/u.test(e.key)||this.interacting)return;e.preventDefault();const t=e.composedPath()[0];if(t._content&&t._content.firstElementChild){const i=this.hasAttribute("navigating");t._content.firstElementChild.dispatchEvent(new MouseEvent("click",{shiftKey:e.shiftKey,bubbles:!0,composed:!0,cancelable:!0})),this.toggleAttribute("navigating",i)}}_onFocusIn(e){this._isMousedown||this.toggleAttribute("navigating",!0);const t=e.composedPath()[0];t===this.$.table||t===this.$.focusexit?(this._isMousedown||this._predictFocusStepTarget(t,t===this.$.table?1:-1).focus(),this._setInteracting(!1)):this._detectInteracting(e)}_onFocusOut(e){this.toggleAttribute("navigating",!1),this._detectInteracting(e),this._hideTooltip(),this._focusedCell=null}_onContentFocusIn(e){const{section:t,cell:i,row:s}=this._getGridEventLocation(e);if(!(!i&&!this.__rowFocusMode)&&(this._detectInteracting(e),t&&(i||s)))if(this._activeRowGroup=t,t===this.$.header?this._headerFocusable=this.__getFocusable(s,i):t===this.$.items?(this._itemsFocusable=this.__getFocusable(s,i),this._focusedItemIndex=s.index):t===this.$.footer&&(this._footerFocusable=this.__getFocusable(s,i)),i){const o=this.getEventContext(e);this.__pendingBodyCellFocus=this.loading&&o.section==="body",!this.__pendingBodyCellFocus&&i!==this.$.emptystatecell&&i.dispatchEvent(new CustomEvent("cell-focus",{bubbles:!0,composed:!0,detail:{context:o}})),this._focusedCell=i._focusButton||i,xe()&&e.target===i&&this._showTooltip(e)}else this._focusedCell=null}__dispatchPendingBodyCellFocus(){this.__pendingBodyCellFocus&&this.shadowRoot.activeElement===this._itemsFocusable&&this._itemsFocusable.dispatchEvent(new Event("focusin",{bubbles:!0,composed:!0}))}__getFocusable(e,t){return this.__rowFocusMode?e:t._focusButton||t}_detectInteracting(e){const t=e.composedPath().some(i=>i.localName==="slot"&&this.shadowRoot.contains(i));this._setInteracting(t),this.__updateHorizontalScrollPosition()}_updateGridSectionFocusTarget(e){if(!e)return;const t=this._getGridSectionFromFocusTarget(e),i=this.interacting&&t===this._activeRowGroup;e.tabIndex=i?-1:0}_preventScrollerRotatingCellFocus(){this._activeRowGroup===this.$.items&&(this.__preventScrollerRotatingCellFocusDebouncer=A.debounce(this.__preventScrollerRotatingCellFocusDebouncer,J,()=>{const e=this._activeRowGroup===this.$.items;this._getRenderedRows().some(i=>i.index===this._focusedItemIndex)?(this.__updateItemsFocusable(),e&&!this.__rowFocusMode&&(this._focusedCell=this._itemsFocusable),this._navigatingIsHidden&&(this.toggleAttribute("navigating",!0),this._navigatingIsHidden=!1)):e&&(this._focusedCell=null,this.hasAttribute("navigating")&&(this._navigatingIsHidden=!0,this.toggleAttribute("navigating",!1)))}))}_getColumns(e,t){let i=this._columnTree.length-1;return e===this.$.header?i=t:e===this.$.footer&&(i=this._columnTree.length-1-t),this._columnTree[i]}__isValidFocusable(e){return this.$.table.contains(e)&&e.offsetHeight}_resetKeyboardNavigation(){if(["header","footer"].forEach(e=>{if(!this.__isValidFocusable(this[`_${e}Focusable`])){const t=[...this.$[e].children].find(s=>s.offsetHeight),i=t?[...t.children].find(s=>!s.hidden):null;t&&i&&(this[`_${e}Focusable`]=this.__getFocusable(t,i))}}),!this.__isValidFocusable(this._itemsFocusable)&&this.$.items.firstElementChild){const e=this.__getFirstVisibleItem(),t=e?[...e.children].find(i=>!i.hidden):null;t&&e&&(this._focusedColumnOrder=void 0,this._itemsFocusable=this.__getFocusable(e,t))}else this.__updateItemsFocusable()}_scrollHorizontallyToCell(e){if(e.hasAttribute("frozen")||e.hasAttribute("frozen-to-end")||V(e))return;const t=e.getBoundingClientRect(),i=e.parentNode,s=Array.from(i.children).indexOf(e),o=this.$.table.getBoundingClientRect();let l=o.left,u=o.right;for(let p=s-1;p>=0;p--){const _=i.children[p];if(!(_.hasAttribute("hidden")||V(_))&&(_.hasAttribute("frozen")||_.hasAttribute("frozen-to-end"))){l=_.getBoundingClientRect().right;break}}for(let p=s+1;p<i.children.length;p++){const _=i.children[p];if(!(_.hasAttribute("hidden")||V(_))&&(_.hasAttribute("frozen")||_.hasAttribute("frozen-to-end"))){u=_.getBoundingClientRect().left;break}}t.left<l&&(this.$.table.scrollLeft+=Math.round(t.left-l)),t.right>u&&(this.$.table.scrollLeft+=Math.round(t.right-u))}_getGridEventLocation(e){const t=e.__composedPath||e.composedPath(),i=t.indexOf(this.$.table),s=i>=1?t[i-1]:null,o=i>=2?t[i-2]:null,l=i>=3?t[i-3]:null;return{section:s,row:o,cell:l}}_getGridSectionFromFocusTarget(e){return e===this._headerFocusable?this.$.header:e===this._itemsFocusable?this.$.items:e===this._footerFocusable?this.$.footer:null}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const kt=n=>class extends n{static get properties(){return{detailsOpenedItems:{type:Array,value:()=>[],sync:!0},rowDetailsRenderer:{type:Function,sync:!0},_detailsCells:{type:Array}}}static get observers(){return["_detailsOpenedItemsChanged(detailsOpenedItems, rowDetailsRenderer)","_rowDetailsRendererChanged(rowDetailsRenderer)"]}ready(){super.ready(),this._detailsCellResizeObserver=new ResizeObserver(e=>{e.forEach(({target:t})=>{this._updateDetailsCellHeight(t.parentElement)}),this.__virtualizer.__adapter._resizeHandler()})}_rowDetailsRendererChanged(e){e&&this._columnTree&&R(this.$.items,t=>{if(!t.querySelector("[part~=details-cell]")){this._updateRow(t,this._columnTree[this._columnTree.length-1]);const i=this._isDetailsOpened(t._item);this._toggleDetailsCell(t,i)}})}_detailsOpenedItemsChanged(e,t){R(this.$.items,i=>{if(i.hasAttribute("details-opened")){this._updateItem(i,i._item);return}t&&this._isDetailsOpened(i._item)&&this._updateItem(i,i._item)})}_configureDetailsCell(e){e.setAttribute("part","cell details-cell"),e.toggleAttribute("frozen",!0),this._detailsCellResizeObserver.observe(e)}_toggleDetailsCell(e,t){const i=e.querySelector('[part~="details-cell"]');i&&(i.hidden=!t,!i.hidden&&this.rowDetailsRenderer&&(i._renderer=this.rowDetailsRenderer))}_updateDetailsCellHeight(e){const t=e.querySelector('[part~="details-cell"]');t&&(this.__updateDetailsRowPadding(e,t),requestAnimationFrame(()=>this.__updateDetailsRowPadding(e,t)))}__updateDetailsRowPadding(e,t){t.hidden?e.style.removeProperty("padding-bottom"):e.style.setProperty("padding-bottom",`${t.offsetHeight}px`)}_updateDetailsCellHeights(){R(this.$.items,e=>{this._updateDetailsCellHeight(e)})}_isDetailsOpened(e){return this.detailsOpenedItems&&this._getItemIndexInArray(e,this.detailsOpenedItems)!==-1}openItemDetails(e){this._isDetailsOpened(e)||(this.detailsOpenedItems=[...this.detailsOpenedItems,e])}closeItemDetails(e){this._isDetailsOpened(e)&&(this.detailsOpenedItems=this.detailsOpenedItems.filter(t=>!this._itemsEqual(t,e)))}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const Pe={SCROLLING:500,UPDATE_CONTENT_VISIBILITY:100},Lt=n=>class extends et(n){static get properties(){return{columnRendering:{type:String,value:"eager",sync:!0},_frozenCells:{type:Array,value:()=>[]},_frozenToEndCells:{type:Array,value:()=>[]}}}static get observers(){return["__columnRenderingChanged(_columnTree, columnRendering)"]}get _scrollLeft(){return this.$.table.scrollLeft}get _scrollTop(){return this.$.table.scrollTop}set _scrollTop(e){this.$.table.scrollTop=e}get _lazyColumns(){return this.columnRendering==="lazy"}ready(){super.ready(),this.scrollTarget=this.$.table,this.$.items.addEventListener("focusin",e=>{const t=e.composedPath(),i=t[t.indexOf(this.$.items)-1];if(i){if(!this._isMousedown){const s=this.$.table.clientHeight,o=this.$.header.clientHeight,l=this.$.footer.clientHeight,u=s-o-l,_=i.clientHeight>u?e.target:i;this.__scrollIntoViewport(_)}this.$.table.contains(e.relatedTarget)||this.$.table.dispatchEvent(new CustomEvent("virtualizer-element-focused",{detail:{element:i}}))}}),this.$.table.addEventListener("scroll",()=>this._afterScroll())}_onResize(){if(this._updateOverflow(),this.__updateHorizontalScrollPosition(),this._firefox){const e=!me(this);e&&this.__previousVisible===!1&&(this._scrollTop=this.__memorizedScrollTop||0),this.__previousVisible=e}}_scrollToFlatIndex(e){e=Math.min(this._flatSize-1,Math.max(0,e)),this.__virtualizer.scrollToIndex(e);const t=[...this.$.items.children].find(i=>i.index===e);this.__scrollIntoViewport(t)}__scrollIntoViewport(e){if(!e)return;const t=e.getBoundingClientRect(),i=this.$.footer.getBoundingClientRect().top,s=this.$.header.getBoundingClientRect().bottom;t.bottom>i?this.$.table.scrollTop+=t.bottom-i:t.top<s&&(this.$.table.scrollTop-=s-t.top)}_scheduleScrolling(){this._scrollingFrame||(this._scrollingFrame=requestAnimationFrame(()=>this.$.scroller.toggleAttribute("scrolling",!0))),this._debounceScrolling=A.debounce(this._debounceScrolling,q.after(Pe.SCROLLING),()=>{cancelAnimationFrame(this._scrollingFrame),delete this._scrollingFrame,this.$.scroller.toggleAttribute("scrolling",!1)})}_afterScroll(){this.__updateHorizontalScrollPosition(),this.hasAttribute("reordering")||this._scheduleScrolling(),this.hasAttribute("navigating")||this._hideTooltip(!0),this._updateOverflow(),this._debounceColumnContentVisibility=A.debounce(this._debounceColumnContentVisibility,q.after(Pe.UPDATE_CONTENT_VISIBILITY),()=>{this._lazyColumns&&this.__cachedScrollLeft!==this._scrollLeft&&(this.__cachedScrollLeft=this._scrollLeft,this.__updateColumnsBodyContentHidden())}),this._firefox&&!me(this)&&this.__previousVisible!==!1&&(this.__memorizedScrollTop=this._scrollTop)}__updateColumnsBodyContentHidden(){if(!this._columnTree||!this._areSizerCellsAssigned())return;const e=this._getColumnsInOrder();let t=!1;if(e.forEach(i=>{const s=this._lazyColumns&&!this.__isColumnInViewport(i);i._bodyContentHidden!==s&&(t=!0,i._cells.forEach(o=>{if(o!==i._sizerCell){if(s)o.remove();else if(o.__parentRow){const l=[...o.__parentRow.children].find(u=>e.indexOf(u._column)>e.indexOf(i));o.__parentRow.insertBefore(o,l)}}})),i._bodyContentHidden=s}),t&&this._frozenCellsChanged(),this._lazyColumns){const i=[...e].reverse().find(l=>l.frozen),s=this.__getColumnEnd(i),o=e.find(l=>!l.frozen&&!l._bodyContentHidden);this.__lazyColumnsStart=this.__getColumnStart(o)-s,this.$.items.style.setProperty("--_grid-lazy-columns-start",`${this.__lazyColumnsStart}px`),this._resetKeyboardNavigation()}}__getColumnEnd(e){return e?e._sizerCell.offsetLeft+(this.__isRTL?0:e._sizerCell.offsetWidth):this.__isRTL?this.$.table.clientWidth:0}__getColumnStart(e){return e?e._sizerCell.offsetLeft+(this.__isRTL?e._sizerCell.offsetWidth:0):this.__isRTL?this.$.table.clientWidth:0}__isColumnInViewport(e){return e.frozen||e.frozenToEnd?!0:this.__isHorizontallyInViewport(e._sizerCell)}__isHorizontallyInViewport(e){return e.offsetLeft+e.offsetWidth>=this._scrollLeft&&e.offsetLeft<=this._scrollLeft+this.clientWidth}__columnRenderingChanged(e,t){t==="eager"?this.$.scroller.removeAttribute("column-rendering"):this.$.scroller.setAttribute("column-rendering",t),this.__updateColumnsBodyContentHidden()}_updateOverflow(){this._debounceOverflow=A.debounce(this._debounceOverflow,J,()=>{this.__doUpdateOverflow()})}__doUpdateOverflow(){let e="";const t=this.$.table;t.scrollTop<t.scrollHeight-t.clientHeight&&(e+=" bottom"),t.scrollTop>0&&(e+=" top");const i=Re(t,this.getAttribute("dir"));i>0&&(e+=" start"),i<t.scrollWidth-t.clientWidth&&(e+=" end"),this.__isRTL&&(e=e.replace(/start|end/giu,o=>o==="start"?"end":"start")),t.scrollLeft<t.scrollWidth-t.clientWidth&&(e+=" right"),t.scrollLeft>0&&(e+=" left");const s=e.trim();s.length>0&&this.getAttribute("overflow")!==s?this.setAttribute("overflow",s):s.length===0&&this.hasAttribute("overflow")&&this.removeAttribute("overflow")}_frozenCellsChanged(){this._debouncerCacheElements=A.debounce(this._debouncerCacheElements,X,()=>{Array.from(this.shadowRoot.querySelectorAll('[part~="cell"]')).forEach(e=>{e.style.transform=""}),this._frozenCells=Array.prototype.slice.call(this.$.table.querySelectorAll("[frozen]")),this._frozenToEndCells=Array.prototype.slice.call(this.$.table.querySelectorAll("[frozen-to-end]")),this.__updateHorizontalScrollPosition()}),this._debounceUpdateFrozenColumn()}_debounceUpdateFrozenColumn(){this.__debounceUpdateFrozenColumn=A.debounce(this.__debounceUpdateFrozenColumn,X,()=>this._updateFrozenColumn())}_updateFrozenColumn(){if(!this._columnTree)return;const e=this._columnTree[this._columnTree.length-1].slice(0);e.sort((s,o)=>s._order-o._order);let t,i;for(let s=0;s<e.length;s++){const o=e[s];o._lastFrozen=!1,o._firstFrozenToEnd=!1,i===void 0&&o.frozenToEnd&&!o.hidden&&(i=s),o.frozen&&!o.hidden&&(t=s)}t!==void 0&&(e[t]._lastFrozen=!0),i!==void 0&&(e[i]._firstFrozenToEnd=!0),this.__updateColumnsBodyContentHidden()}__updateHorizontalScrollPosition(){if(!this._columnTree)return;const e=this.$.table.scrollWidth,t=this.$.table.clientWidth,i=Math.max(0,this.$.table.scrollLeft),s=Re(this.$.table,this.getAttribute("dir")),o=`translate(${-i}px, 0)`;this.$.header.style.transform=o,this.$.footer.style.transform=o,this.$.items.style.transform=o;const l=this.__isRTL?s+t-e:i,u=`translate(${l}px, 0)`;this._frozenCells.forEach(f=>{f.style.transform=u});const p=this.__isRTL?s:i+t-e,_=`translate(${p}px, 0)`;let g=_;if(this._lazyColumns&&this._areSizerCellsAssigned()){const f=this._getColumnsInOrder(),x=[...f].reverse().find($=>!$.frozenToEnd&&!$._bodyContentHidden),S=this.__getColumnEnd(x),z=f.find($=>$.frozenToEnd),I=this.__getColumnStart(z);g=`translate(${p+(I-S)+this.__lazyColumnsStart}px, 0)`}this._frozenToEndCells.forEach(f=>{this.$.items.contains(f)?f.style.transform=g:f.style.transform=_}),this.hasAttribute("navigating")&&this.__rowFocusMode&&this.$.table.style.setProperty("--_grid-horizontal-scroll-position",`${-l}px`)}_areSizerCellsAssigned(){return this._getColumnsInOrder().every(e=>e._sizerCell)}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const Bt=n=>class extends n{static get properties(){return{selectedItems:{type:Object,notify:!0,value:()=>[],sync:!0},isItemSelectable:{type:Function,notify:!0},__selectedKeys:{type:Object,computed:"__computeSelectedKeys(itemIdPath, selectedItems)"}}}static get observers(){return["__selectedItemsChanged(itemIdPath, selectedItems, isItemSelectable)"]}_isSelected(e){return this.__selectedKeys.has(this.getItemId(e))}__isItemSelectable(e){return!this.isItemSelectable||!e?!0:this.isItemSelectable(e)}selectItem(e){this._isSelected(e)||(this.selectedItems=[...this.selectedItems,e])}deselectItem(e){this._isSelected(e)&&(this.selectedItems=this.selectedItems.filter(t=>!this._itemsEqual(t,e)))}__selectedItemsChanged(){this.requestContentUpdate()}__computeSelectedKeys(e,t){const i=t||[],s=new Set;return i.forEach(o=>{s.add(this.getItemId(o))}),s}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */let $e="prepend";const Ht=n=>class extends n{static get properties(){return{multiSort:{type:Boolean,value:!1},multiSortPriority:{type:String,value:()=>$e},multiSortOnShiftClick:{type:Boolean,value:!1},_sorters:{type:Array,value:()=>[]},_previousSorters:{type:Array,value:()=>[]}}}static setDefaultMultiSortPriority(e){$e=["append","prepend"].includes(e)?e:"prepend"}ready(){super.ready(),this.addEventListener("sorter-changed",this._onSorterChanged)}_onSorterChanged(e){const t=e.target;e.stopPropagation(),t._grid=this,this.__updateSorter(t,e.detail.shiftClick,e.detail.fromSorterClick),this.__applySorters()}__removeSorters(e){e.length!==0&&(this._sorters=this._sorters.filter(t=>!e.includes(t)),this.__applySorters())}__updateSortOrders(){this._sorters.forEach(t=>{t._order=null});const e=this._getActiveSorters();e.length>1&&e.forEach((t,i)=>{t._order=i})}__updateSorter(e,t,i){if(!e.direction&&!this._sorters.includes(e))return;e._order=null;const s=this._sorters.filter(o=>o!==e);this.multiSort&&(!this.multiSortOnShiftClick||!i)||this.multiSortOnShiftClick&&t?this.multiSortPriority==="append"?this._sorters=[...s,e]:this._sorters=[e,...s]:(e.direction||this.multiSortOnShiftClick)&&(this._sorters=e.direction?[e]:[],s.forEach(o=>{o._order=null,o.direction=null}))}__applySorters(){this.__updateSortOrders(),this.dataProvider&&this.isAttached&&JSON.stringify(this._previousSorters)!==JSON.stringify(this._mapSorters())&&this.__debounceClearCache(),this._a11yUpdateSorters(),this._previousSorters=this._mapSorters()}_getActiveSorters(){return this._sorters.filter(e=>e.direction&&e.isConnected)}_mapSorters(){return this._getActiveSorters().map(e=>({path:e.path,direction:e.direction}))}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const Nt=n=>class extends n{static get properties(){return{cellClassNameGenerator:{type:Function,sync:!0},cellPartNameGenerator:{type:Function,sync:!0}}}static get observers(){return["__cellClassNameGeneratorChanged(cellClassNameGenerator)","__cellPartNameGeneratorChanged(cellPartNameGenerator)"]}__cellClassNameGeneratorChanged(){this.generateCellClassNames()}__cellPartNameGeneratorChanged(){this.generateCellPartNames()}generateCellClassNames(){R(this.$.items,e=>{e.hidden||this._generateCellClassNames(e,this.__getRowModel(e))})}generateCellPartNames(){R(this.$.items,e=>{e.hidden||this._generateCellPartNames(e,this.__getRowModel(e))})}_generateCellClassNames(e,t){Z(e,i=>{if(i.__generatedClasses&&i.__generatedClasses.forEach(s=>i.classList.remove(s)),this.cellClassNameGenerator&&!e.hasAttribute("loading")){const s=this.cellClassNameGenerator(i._column,t);i.__generatedClasses=s&&s.split(" ").filter(o=>o.length>0),i.__generatedClasses&&i.__generatedClasses.forEach(o=>i.classList.add(o))}})}_generateCellPartNames(e,t){Z(e,i=>{if(i.__generatedParts&&i.__generatedParts.forEach(s=>{B(i,null,s)}),this.cellPartNameGenerator&&!e.hasAttribute("loading")){const s=this.cellPartNameGenerator(i._column,t);i.__generatedParts=s&&s.split(" ").filter(o=>o.length>0),i.__generatedParts&&i.__generatedParts.forEach(o=>{B(i,!0,o)})}})}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const Gt=n=>class extends Rt(St(Tt(Pt(At(Lt(Bt(Ht(kt(Mt(xt(Dt(zt(Ft($t(Ot(Nt(tt(n)))))))))))))))))){static get observers(){return["_columnTreeChanged(_columnTree)","_flatSizeChanged(_flatSize, __virtualizer, _hasData, _columnTree)"]}static get properties(){return{_safari:{type:Boolean,value:Be},_ios:{type:Boolean,value:he},_firefox:{type:Boolean,value:He},_android:{type:Boolean,value:ge},_touchDevice:{type:Boolean,value:ye},allRowsVisible:{type:Boolean,value:!1,reflectToAttribute:!0},isAttached:{value:!1},__gridElement:{type:Boolean,value:!0},__hasEmptyStateContent:{type:Boolean,value:!1},__emptyState:{type:Boolean,computed:"__computeEmptyState(_flatSize, __hasEmptyStateContent)"}}}constructor(){super(),this.addEventListener("animationend",this._onAnimationEnd)}get _firstVisibleIndex(){const r=this.__getFirstVisibleItem();return r?r.index:void 0}get _lastVisibleIndex(){const r=this.__getLastVisibleItem();return r?r.index:void 0}connectedCallback(){super.connectedCallback(),this.isAttached=!0,this.__virtualizer.hostConnected()}disconnectedCallback(){super.disconnectedCallback(),this.isAttached=!1,this._hideTooltip(!0)}__getFirstVisibleItem(){return this._getRenderedRows().find(r=>this._isInViewport(r))}__getLastVisibleItem(){return this._getRenderedRows().reverse().find(r=>this._isInViewport(r))}_isInViewport(r){const e=this.$.table.getBoundingClientRect(),t=r.getBoundingClientRect(),i=this.$.header.getBoundingClientRect().height,s=this.$.footer.getBoundingClientRect().height;return t.bottom>e.top+i&&t.top<e.bottom-s}_getRenderedRows(){return Array.from(this.$.items.children).filter(r=>!r.hidden).sort((r,e)=>r.index-e.index)}_getRowContainingNode(r){const e=Ne("vaadin-grid-cell-content",r);return e?e.assignedSlot.parentElement.parentElement:void 0}_isItemAssignedToRow(r,e){const t=this.__getRowModel(e);return this.getItemId(r)===this.getItemId(t.item)}ready(){super.ready(),this.__virtualizer=new it({createElements:this._createScrollerRows.bind(this),updateElement:this._updateScrollerItem.bind(this),scrollContainer:this.$.items,scrollTarget:this.$.table,reorderElements:!0}),new ResizeObserver(()=>{setTimeout(()=>{this.__updateColumnsBodyContentHidden()}),this.__updateHorizontalScrollPosition()}).observe(this.$.table);const r=new ResizeObserver(()=>setTimeout(()=>{this.__updateMinHeight()}));r.observe(this.$.header),r.observe(this.$.items),r.observe(this.$.footer),Ce(this),this._tooltipController=new nt(this),this.addController(this._tooltipController),this._tooltipController.setManual(!0),this.__emptyStateContentObserver=new rt(this.$.emptystateslot,({currentNodes:e})=>{this.$.emptystatecell._content=e[0],this.__hasEmptyStateContent=!!this.$.emptystatecell._content})}__getBodyCellCoordinates(r){if(this.$.items.contains(r)&&r.localName==="td")return{item:r.parentElement._item,column:r._column}}__focusBodyCell({item:r,column:e}){const t=this._getRenderedRows().find(s=>s._item===r),i=t&&[...t.children].find(s=>s._column===e);i&&i.focus()}_focusFirstVisibleRow(){const r=this.__getFirstVisibleItem();this.__rowFocusMode=!0,r.focus()}_flatSizeChanged(r,e,t,i){if(e&&t&&i){const s=this.shadowRoot.activeElement,o=this.__getBodyCellCoordinates(s),l=e.size||0;e.size=r,e.update(l-1,l-1),r<l&&e.update(r-1,r-1),o&&s.parentElement.hidden&&this.__focusBodyCell(o),this._resetKeyboardNavigation()}}_createScrollerRows(r){const e=[];for(let t=0;t<r;t++){const i=document.createElement("tr");i.setAttribute("part","row body-row"),i.setAttribute("role","row"),i.setAttribute("tabindex","-1"),this._columnTree&&this._updateRow(i,this._columnTree[this._columnTree.length-1],"body",!1,!0),e.push(i)}return this._columnTree&&this._columnTree[this._columnTree.length-1].forEach(t=>{t.isConnected&&t._cells&&(t._cells=[...t._cells])}),this.__afterCreateScrollerRowsDebouncer=A.debounce(this.__afterCreateScrollerRowsDebouncer,J,()=>{this._afterScroll()}),e}_createCell(r,e){const i=`vaadin-grid-cell-content-${this._contentIndex=this._contentIndex+1||0}`,s=document.createElement("vaadin-grid-cell-content");s.setAttribute("slot",i);const o=document.createElement(r);o.id=i.replace("-content-","-"),o.setAttribute("role",r==="td"?"gridcell":"columnheader"),!ge&&!he&&(o.addEventListener("mouseenter",u=>{this.$.scroller.hasAttribute("scrolling")||this._showTooltip(u)}),o.addEventListener("mouseleave",()=>{this._hideTooltip()}),o.addEventListener("mousedown",()=>{this._hideTooltip(!0)}));const l=document.createElement("slot");if(l.setAttribute("name",i),e&&e._focusButtonMode){const u=document.createElement("div");u.setAttribute("role","button"),u.setAttribute("tabindex","-1"),o.appendChild(u),o._focusButton=u,o.focus=function(p){o._focusButton.focus(p)},u.appendChild(l)}else o.setAttribute("tabindex","-1"),o.appendChild(l);return o._content=s,s.addEventListener("mousedown",()=>{if(Le){const u=p=>{const _=s.contains(this.getRootNode().activeElement),g=p.composedPath().includes(s);!_&&g&&o.focus({preventScroll:!0}),document.removeEventListener("mouseup",u,!0)};document.addEventListener("mouseup",u,!0)}else setTimeout(()=>{s.contains(this.getRootNode().activeElement)||o.focus({preventScroll:!0})})}),o}_updateRow(r,e,t="body",i=!1,s=!1){const o=document.createDocumentFragment();Z(r,l=>{l._vacant=!0}),r.innerHTML="",t==="body"&&(r.__cells=[],r.__detailsCell=null),e.filter(l=>!l.hidden).forEach((l,u,p)=>{let _;if(t==="body"){l._cells||(l._cells=[]),_=l._cells.find(f=>f._vacant),_||(_=this._createCell("td",l),l._onCellKeyDown&&_.addEventListener("keydown",l._onCellKeyDown.bind(l)),l._cells.push(_)),_.setAttribute("part","cell body-cell"),_.__parentRow=r,r.__cells.push(_);const g=r===this.$.sizer;if((!l._bodyContentHidden||g)&&r.appendChild(_),g&&(l._sizerCell=_),u===p.length-1&&this.rowDetailsRenderer){this._detailsCells||(this._detailsCells=[]);const f=this._detailsCells.find(x=>x._vacant)||this._createCell("td");this._detailsCells.indexOf(f)===-1&&this._detailsCells.push(f),f._content.parentElement||o.appendChild(f._content),this._configureDetailsCell(f),r.appendChild(f),r.__detailsCell=f,this._a11ySetRowDetailsCell(r,f),f._vacant=!1}s||(l._cells=[...l._cells])}else{const g=t==="header"?"th":"td";i||l.localName==="vaadin-grid-column-group"?(_=l[`_${t}Cell`],_||(_=this._createCell(g),l._onCellKeyDown&&_.addEventListener("keydown",l._onCellKeyDown.bind(l))),_._column=l,r.appendChild(_),l[`_${t}Cell`]=_):(l._emptyCells||(l._emptyCells=[]),_=l._emptyCells.find(f=>f._vacant)||this._createCell(g),_._column=l,r.appendChild(_),l._emptyCells.indexOf(_)===-1&&l._emptyCells.push(_)),_.part.add("cell",`${t}-cell`)}_._content.parentElement||o.appendChild(_._content),_._vacant=!1,_._column=l}),t!=="body"&&this.__debounceUpdateHeaderFooterRowVisibility(r),this.appendChild(o),this._frozenCellsChanged(),this._updateFirstAndLastColumnForRow(r)}__debounceUpdateHeaderFooterRowVisibility(r){r.__debounceUpdateHeaderFooterRowVisibility=A.debounce(r.__debounceUpdateHeaderFooterRowVisibility,X,()=>this.__updateHeaderFooterRowVisibility(r))}__updateHeaderFooterRowVisibility(r){if(!r)return;const e=Array.from(r.children).filter(t=>{const i=t._column;if(i._emptyCells&&i._emptyCells.indexOf(t)>-1)return!1;if(r.parentElement===this.$.header){if(i.headerRenderer)return!0;if(i.header===null)return!1;if(i.path||i.header!==void 0)return!0}else if(i.footerRenderer)return!0;return!1});r.hidden!==!e.length&&(r.hidden=!e.length),this._resetKeyboardNavigation(),this._a11yUpdateGridSize(this.size,this._columnTree,this.__emptyState)}_updateScrollerItem(r,e){this._preventScrollerRotatingCellFocus(r,e),this._columnTree&&(this._updateRowOrderParts(r,e),this._a11yUpdateRowRowindex(r,e),this._getItem(e,r))}_columnTreeChanged(r){this._renderColumnTree(r),this.__updateColumnsBodyContentHidden()}_updateRowOrderParts(r,e=r.index){j(r,{first:e===0,last:e===this._flatSize-1,odd:e%2!==0,even:e%2===0})}_updateRowStateParts(r,{item:e,expanded:t,selected:i,detailsOpened:s}){j(r,{expanded:t,collapsed:this.__isRowExpandable(r),selected:i,nonselectable:this.__isItemSelectable(e)===!1,"details-opened":s})}__computeEmptyState(r,e){return r===0&&e}_renderColumnTree(r){for(R(this.$.items,e=>{this._updateRow(e,r[r.length-1],"body",!1,!0);const t=this.__getRowModel(e);this._updateRowOrderParts(e),this._updateRowStateParts(e,t),this._filterDragAndDrop(e,t)});this.$.header.children.length<r.length;){const e=document.createElement("tr");e.setAttribute("part","row"),e.setAttribute("role","row"),e.setAttribute("tabindex","-1"),this.$.header.appendChild(e);const t=document.createElement("tr");t.setAttribute("part","row"),t.setAttribute("role","row"),t.setAttribute("tabindex","-1"),this.$.footer.appendChild(t)}for(;this.$.header.children.length>r.length;)this.$.header.removeChild(this.$.header.firstElementChild),this.$.footer.removeChild(this.$.footer.firstElementChild);R(this.$.header,(e,t,i)=>{this._updateRow(e,r[t],"header",t===r.length-1);const s=K(e);k(s,"first-header-row-cell",t===0),k(s,"last-header-row-cell",t===i.length-1)}),R(this.$.footer,(e,t,i)=>{this._updateRow(e,r[r.length-1-t],"footer",t===0);const s=K(e);k(s,"first-footer-row-cell",t===0),k(s,"last-footer-row-cell",t===i.length-1)}),this._updateRow(this.$.sizer,r[r.length-1]),this._resizeHandler(),this._frozenCellsChanged(),this._updateFirstAndLastColumn(),this._resetKeyboardNavigation(),this._a11yUpdateHeaderRows(),this._a11yUpdateFooterRows(),this.generateCellClassNames(),this.generateCellPartNames(),this.__updateHeaderAndFooter()}_updateItem(r,e){r._item=e;const t=this.__getRowModel(r);this._toggleDetailsCell(r,t.detailsOpened),this._a11yUpdateRowLevel(r,t.level),this._a11yUpdateRowSelected(r,t.selected),this._updateRowStateParts(r,t),this._generateCellClassNames(r,t),this._generateCellPartNames(r,t),this._filterDragAndDrop(r,t),this.__updateDragSourceParts(r,t),R(r,i=>{if(!(i._column&&!i._column.isConnected)&&i._renderer){const s=i._column||this;i._renderer.call(s,i._content,s,t)}}),this._updateDetailsCellHeight(r),this._a11yUpdateRowExpanded(r,t.expanded)}_resizeHandler(){this._updateDetailsCellHeights(),this.__updateHorizontalScrollPosition()}_onAnimationEnd(r){r.animationName.indexOf("vaadin-grid-appear")===0&&(r.stopPropagation(),this._resetKeyboardNavigation(),requestAnimationFrame(()=>{this.__scrollToPendingIndexes()}))}__getRowModel(r){return{index:r.index,item:r._item,level:this._getIndexLevel(r.index),expanded:this._isExpanded(r._item),selected:this._isSelected(r._item),detailsOpened:!!this.rowDetailsRenderer&&this._isDetailsOpened(r._item)}}_showTooltip(r){const e=this._tooltipController.node;if(e&&e.isConnected){const t=r.target;if(!this.__isCellFullyVisible(t))return;this._tooltipController.setTarget(t),this._tooltipController.setContext(this.getEventContext(r)),e._stateController.open({focus:r.type==="focusin",hover:r.type==="mouseenter"})}}__isCellFullyVisible(r){if(r.hasAttribute("frozen")||r.hasAttribute("frozen-to-end"))return!0;let{left:e,right:t}=this.getBoundingClientRect();const i=[...r.parentNode.children].find(l=>l.hasAttribute("last-frozen"));if(i){const l=i.getBoundingClientRect();e=this.__isRTL?e:l.right,t=this.__isRTL?l.left:t}const s=[...r.parentNode.children].find(l=>l.hasAttribute("first-frozen-to-end"));if(s){const l=s.getBoundingClientRect();e=this.__isRTL?l.right:e,t=this.__isRTL?t:l.left}const o=r.getBoundingClientRect();return o.left>=e&&o.right<=t}_hideTooltip(r){const e=this._tooltipController&&this._tooltipController.node;e&&e._stateController.close(r)}requestContentUpdate(){this.__updateHeaderAndFooter(),this.__updateVisibleRows()}__updateHeaderAndFooter(){(this._columnTree||[]).forEach(r=>{r.forEach(e=>{e._renderHeaderAndFooter&&e._renderHeaderAndFooter()})})}__updateVisibleRows(r,e){this.__virtualizer&&this.__virtualizer.update(r,e)}__updateMinHeight(){const e=this.$.header.clientHeight,t=this.$.footer.clientHeight,i=this.$.table.offsetHeight-this.$.table.clientHeight,s=e+36+t+i;!this.__minHeightStyleSheet&&st&&(this.__minHeightStyleSheet=new CSSStyleSheet,this.shadowRoot.adoptedStyleSheets=[...this.shadowRoot.adoptedStyleSheets,this.__minHeightStyleSheet]),this.__minHeightStyleSheet?this.__minHeightStyleSheet.replaceSync(`:host { --_grid-min-height: ${s}px; }`):this.style.setProperty("--_grid-min-height",`${s}px`)}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const Wt=W`
  @keyframes vaadin-grid-appear {
    to {
      opacity: 1;
    }
  }

  :host {
    display: flex;
    flex-direction: column;
    animation: 1ms vaadin-grid-appear;
    height: 400px;
    min-height: var(--_grid-min-height, 0);
    flex: 1 1 auto;
    align-self: stretch;
    position: relative;
  }

  :host([hidden]) {
    display: none !important;
  }

  :host([disabled]) {
    pointer-events: none;
  }

  #scroller {
    display: flex;
    flex-direction: column;
    min-height: 100%;
    transform: translateY(0);
    width: auto;
    height: auto;
    position: absolute;
    inset: 0;
  }

  :host([all-rows-visible]) {
    height: auto;
    align-self: flex-start;
    min-height: auto;
    flex-grow: 0;
    width: 100%;
  }

  :host([all-rows-visible]) #scroller {
    width: 100%;
    height: 100%;
    position: relative;
  }

  :host([all-rows-visible]) #items {
    min-height: 1px;
  }

  #table {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    overflow: auto;
    position: relative;
    outline: none;
    /* Workaround for a Desktop Safari bug: new stacking context here prevents the scrollbar from getting hidden */
    z-index: 0;
  }

  #header,
  #footer {
    display: block;
    position: -webkit-sticky;
    position: sticky;
    left: 0;
    overflow: visible;
    width: 100%;
    z-index: 1;
  }

  #header {
    top: 0;
  }

  th {
    text-align: inherit;
  }

  /* Safari doesn't work with "inherit" */
  [safari] th {
    text-align: initial;
  }

  #footer {
    bottom: 0;
  }

  #items {
    flex-grow: 1;
    flex-shrink: 0;
    display: block;
    position: -webkit-sticky;
    position: sticky;
    width: 100%;
    left: 0;
    overflow: visible;
  }

  [part~='row'] {
    display: flex;
    width: 100%;
    box-sizing: border-box;
    margin: 0;
  }

  [part~='row'][loading] [part~='body-cell'] ::slotted(vaadin-grid-cell-content) {
    visibility: hidden;
  }

  [column-rendering='lazy'] [part~='body-cell']:not([frozen]):not([frozen-to-end]) {
    transform: translateX(var(--_grid-lazy-columns-start));
  }

  #items [part~='row'] {
    position: absolute;
  }

  #items [part~='row']:empty {
    height: 100%;
  }

  [part~='cell']:not([part~='details-cell']) {
    flex-shrink: 0;
    flex-grow: 1;
    box-sizing: border-box;
    display: flex;
    width: 100%;
    position: relative;
    align-items: center;
    padding: 0;
    white-space: nowrap;
  }

  [part~='cell'] {
    outline: none;
  }

  [part~='cell'] > [tabindex] {
    display: flex;
    align-items: inherit;
    outline: none;
    position: absolute;
    inset: 0;
  }

  /* Switch the focusButtonMode wrapping element to "position: static" temporarily
     when measuring real width of the cells in the auto-width columns. */
  [measuring-auto-width] [part~='cell'] > [tabindex] {
    position: static;
  }

  [part~='details-cell'] {
    position: absolute;
    bottom: 0;
    width: 100%;
    box-sizing: border-box;
    padding: 0;
  }

  [part~='cell'] ::slotted(vaadin-grid-cell-content) {
    display: block;
    width: 100%;
    box-sizing: border-box;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  [hidden] {
    display: none !important;
  }

  [frozen],
  [frozen-to-end] {
    z-index: 2;
    will-change: transform;
  }

  [no-scrollbars][safari] #table,
  [no-scrollbars][firefox] #table {
    overflow: hidden;
  }

  /* Empty state */

  #scroller:not([empty-state]) #emptystatebody,
  #scroller[empty-state] #items {
    display: none;
  }

  #emptystatebody {
    display: flex;
    position: sticky;
    inset: 0;
    flex: 1;
    overflow: hidden;
  }

  #emptystaterow {
    display: flex;
    flex: 1;
  }

  #emptystatecell {
    display: block;
    flex: 1;
    overflow: auto;
  }

  /* Reordering styles */
  :host([reordering]) [part~='cell'] ::slotted(vaadin-grid-cell-content),
  :host([reordering]) [part~='resize-handle'],
  #scroller[no-content-pointer-events] [part~='cell'] ::slotted(vaadin-grid-cell-content) {
    pointer-events: none;
  }

  [part~='reorder-ghost'] {
    visibility: hidden;
    position: fixed;
    pointer-events: none;
    opacity: 0.5;

    /* Prevent overflowing the grid in Firefox */
    top: 0;
    left: 0;
  }

  :host([reordering]) {
    -webkit-user-select: none;
    user-select: none;
  }

  /* Resizing styles */
  [part~='resize-handle'] {
    position: absolute;
    top: 0;
    right: 0;
    height: 100%;
    cursor: col-resize;
    z-index: 1;
  }

  [part~='resize-handle']::before {
    position: absolute;
    content: '';
    height: 100%;
    width: 35px;
    transform: translateX(-50%);
  }

  [last-column] [part~='resize-handle']::before,
  [last-frozen] [part~='resize-handle']::before {
    width: 18px;
    transform: none;
    right: 0;
  }

  [frozen-to-end] [part~='resize-handle'] {
    left: 0;
    right: auto;
  }

  [frozen-to-end] [part~='resize-handle']::before {
    left: 0;
    right: auto;
  }

  [first-frozen-to-end] [part~='resize-handle']::before {
    width: 18px;
    transform: none;
  }

  [first-frozen-to-end] {
    margin-inline-start: auto;
  }

  /* Hide resize handle if scrolled to end */
  :host(:not([overflow~='end'])) [first-frozen-to-end] [part~='resize-handle'] {
    display: none;
  }

  #scroller[column-resizing],
  #scroller[range-selecting] {
    -webkit-user-select: none;
    user-select: none;
  }

  /* Sizer styles */
  #sizer {
    display: flex;
    position: absolute;
    visibility: hidden;
  }

  #sizer [part~='details-cell'] {
    display: none !important;
  }

  #sizer [part~='cell'][hidden] {
    display: none !important;
  }

  #sizer [part~='cell'] {
    display: block;
    flex-shrink: 0;
    line-height: 0;
    height: 0 !important;
    min-height: 0 !important;
    max-height: 0 !important;
    padding: 0 !important;
    border: none !important;
  }

  #sizer [part~='cell']::before {
    content: '-';
  }

  #sizer [part~='cell'] ::slotted(vaadin-grid-cell-content) {
    display: none !important;
  }

  /* RTL specific styles */

  :host([dir='rtl']) #items,
  :host([dir='rtl']) #header,
  :host([dir='rtl']) #footer {
    left: auto;
  }

  :host([dir='rtl']) [part~='reorder-ghost'] {
    left: auto;
    right: 0;
  }

  :host([dir='rtl']) [part~='resize-handle'] {
    left: 0;
    right: auto;
  }

  :host([dir='rtl']) [part~='resize-handle']::before {
    transform: translateX(50%);
  }

  :host([dir='rtl']) [last-column] [part~='resize-handle']::before,
  :host([dir='rtl']) [last-frozen] [part~='resize-handle']::before {
    left: 0;
    right: auto;
  }

  :host([dir='rtl']) [frozen-to-end] [part~='resize-handle'] {
    right: 0;
    left: auto;
  }

  :host([dir='rtl']) [frozen-to-end] [part~='resize-handle']::before {
    right: 0;
    left: auto;
  }

  @media (forced-colors: active) {
    [part~='selected-row'] [part~='first-column-cell']::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      bottom: 0;
      border: 2px solid;
    }

    [part~='focused-cell']::before {
      outline: 2px solid !important;
      outline-offset: -1px;
    }
  }
`;/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */H("vaadin-grid",Wt,{moduleId:"vaadin-grid-styles"});class ne extends Gt(Ge(oe(Ae(G)))){static get template(){return ee`
      <div
        id="scroller"
        safari$="[[_safari]]"
        ios$="[[_ios]]"
        loading$="[[loading]]"
        column-reordering-allowed$="[[columnReorderingAllowed]]"
        empty-state$="[[__emptyState]]"
      >
        <table id="table" role="treegrid" aria-multiselectable="true" tabindex="0" aria-label$="[[accessibleName]]">
          <caption id="sizer" part="row"></caption>
          <thead id="header" role="rowgroup"></thead>
          <tbody id="items" role="rowgroup"></tbody>
          <tbody id="emptystatebody">
            <tr id="emptystaterow">
              <td part="empty-state" id="emptystatecell" tabindex="0">
                <slot name="empty-state" id="emptystateslot"></slot>
              </td>
            </tr>
          </tbody>
          <tfoot id="footer" role="rowgroup"></tfoot>
        </table>

        <div part="reorder-ghost"></div>
      </div>

      <slot name="tooltip"></slot>

      <div id="focusexit" tabindex="0"></div>
    `}static get is(){return"vaadin-grid"}}N(ne);H("vaadin-grid-sorter",W`
    :host {
      justify-content: flex-start;
      align-items: baseline;
      -webkit-user-select: none;
      user-select: none;
      cursor: var(--lumo-clickable-cursor);
    }

    [part='content'] {
      display: inline-block;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    [part='indicators'] {
      margin-left: var(--lumo-space-s);
    }

    [part='indicators']::before {
      transform: scale(0.8);
    }

    :host(:not([direction]):not(:hover)) [part='indicators'] {
      color: var(--lumo-tertiary-text-color);
    }

    :host([direction]) {
      color: var(--vaadin-selection-color-text, var(--lumo-primary-text-color));
    }

    [part='order'] {
      font-size: var(--lumo-font-size-xxs);
      line-height: 1;
    }

    /* RTL specific styles */

    :host([dir='rtl']) [part='indicators'] {
      margin-right: var(--lumo-space-s);
      margin-left: 0;
    }
  `,{moduleId:"lumo-grid-sorter"});/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const je=document.createElement("template");je.innerHTML=`
  <style>
    @font-face {
      font-family: 'vaadin-grid-sorter-icons';
      src: url(data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAQwAA0AAAAABuwAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAAEFAAAABkAAAAcfep+mUdERUYAAAP4AAAAHAAAAB4AJwAOT1MvMgAAAZgAAAA/AAAAYA8TBPpjbWFwAAAB7AAAAFUAAAFeF1fZ4mdhc3AAAAPwAAAACAAAAAgAAAAQZ2x5ZgAAAlgAAABcAAAAnMvguMloZWFkAAABMAAAAC8AAAA2C5Ap72hoZWEAAAFgAAAAHQAAACQGbQPHaG10eAAAAdgAAAAUAAAAHAoAAABsb2NhAAACRAAAABIAAAASAIwAYG1heHAAAAGAAAAAFgAAACAACwAKbmFtZQAAArQAAAECAAACZxWCgKhwb3N0AAADuAAAADUAAABZCrApUXicY2BkYGAA4rDECVrx/DZfGbhZGEDgyqNPOxH0/wNMq5kPALkcDEwgUQBWRA0dAHicY2BkYGA+8P8AAwMLAwgwrWZgZEAFbABY4QM8AAAAeJxjYGRgYOAAQiYGEICQSAAAAi8AFgAAeJxjYGY6yziBgZWBgWkm0xkGBoZ+CM34msGYkZMBFTAKoAkwODAwvmRiPvD/AIMDMxCD1CDJKjAwAgBktQsXAHicY2GAAMZQCM0EwqshbAALxAEKeJxjYGBgZoBgGQZGBhCIAPIYwXwWBhsgzcXAwcAEhIwMCi+Z/v/9/x+sSuElA4T9/4k4K1gHFwMMMILMY2QDYmaoABOQYGJABUA7WBiGNwAAJd4NIQAAAAAAAAAACAAIABAAGAAmAEAATgAAeJyNjLENgDAMBP9tIURJwQCMQccSZgk2i5fIYBDAidJjycXr7x5EPwE2wY8si7jmyBNXGo/bNBerxJNrpxhbO3/fEFpx8ZICpV+ghxJ74fAMe+h7Ox14AbrsHB14nK2QQWrDMBRER4mTkhQK3ZRQKOgCNk7oGQqhhEIX2WSlWEI1BAlkJ5CDdNsj5Ey9Rncdi38ES+jzNJo/HwTgATcoDEthhY3wBHc4CE+pfwsX5F/hGe7Vo/AcK/UhvMSz+mGXKhZU6pww8ISz3oWn1BvhgnwTnuEJf8Jz1OpFeIlX9YULDLdFi4ASHolkSR0iuYdjLak1vAequBhj21D61Nqyi6l3qWybGPjySbPHGScGJl6dP58MYcQRI0bts7mjebBqrFENH7t3qWtj0OuqHnXcW7b0HOTZFnKryRGW2hFX1m0O2vEM3opNMfTau+CS6Z3Vx6veNnEXY6jwDxhsc2gAAHicY2BiwA84GBgYmRiYGJkZmBlZGFkZ2djScyoLMgzZS/MyDQwMwLSrpYEBlIbxjQDrzgsuAAAAAAEAAf//AA94nGNgZGBg4AFiMSBmYmAEQnYgZgHzGAAD6wA2eJxjYGBgZACCKyoz1cD0o087YTQATOcIewAAAA==) format('woff');
      font-weight: normal;
      font-style: normal;
    }
  </style>
`;document.head.appendChild(je.content);H("vaadin-grid-sorter",W`
    :host {
      display: inline-flex;
      cursor: pointer;
      max-width: 100%;
    }

    [part='content'] {
      flex: 1 1 auto;
    }

    [part='indicators'] {
      position: relative;
      align-self: center;
      flex: none;
    }

    [part='order'] {
      display: inline;
      vertical-align: super;
    }

    [part='indicators']::before {
      font-family: 'vaadin-grid-sorter-icons';
      display: inline-block;
    }

    :host(:not([direction])) [part='indicators']::before {
      content: '\\e901';
    }

    :host([direction='asc']) [part='indicators']::before {
      content: '\\e900';
    }

    :host([direction='desc']) [part='indicators']::before {
      content: '\\e902';
    }
  `,{moduleId:"vaadin-grid-sorter-styles"});const Vt=n=>class extends n{static get properties(){return{path:String,direction:{type:String,reflectToAttribute:!0,notify:!0,value:null,sync:!0},_order:{type:Number,value:null,sync:!0}}}static get observers(){return["_pathOrDirectionChanged(path, direction)"]}ready(){super.ready(),this.addEventListener("click",this._onClick.bind(this))}connectedCallback(){super.connectedCallback(),this._grid?this._grid.__applySorters():this.__dispatchSorterChangedEvenIfPossible()}disconnectedCallback(){super.disconnectedCallback(),!this.parentNode&&this._grid?this._grid.__removeSorters([this]):this._grid&&this._grid.__applySorters()}_pathOrDirectionChanged(){this.__dispatchSorterChangedEvenIfPossible()}__dispatchSorterChangedEvenIfPossible(){this.path===void 0||this.direction===void 0||!this.isConnected||(this.dispatchEvent(new CustomEvent("sorter-changed",{detail:{shiftClick:!!this._shiftClick,fromSorterClick:!!this._fromSorterClick},bubbles:!0,composed:!0})),this._fromSorterClick=!1,this._shiftClick=!1)}_getDisplayOrder(e){return e===null?"":e+1}_onClick(e){if(e.defaultPrevented)return;const t=this.getRootNode().activeElement;this!==t&&this.contains(t)||(e.preventDefault(),this._shiftClick=e.shiftKey,this._fromSorterClick=!0,this.direction==="asc"?this.direction="desc":this.direction==="desc"?this.direction=null:this.direction="asc")}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */class Ut extends Vt(oe(re(G))){static get template(){return ee`
      <div part="content">
        <slot></slot>
      </div>
      <div part="indicators">
        <span part="order">[[_getDisplayOrder(_order)]]</span>
      </div>
    `}static get is(){return"vaadin-grid-sorter"}}N(Ut);/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const qt=n=>class extends n{static get properties(){return{width:{type:String,value:"58px",sync:!0},autoWidth:{type:Boolean,value:!0},flexGrow:{type:Number,value:0,sync:!0},selectAll:{type:Boolean,value:!1,notify:!0,sync:!0},autoSelect:{type:Boolean,value:!1,sync:!0},dragSelect:{type:Boolean,value:!1,sync:!0},_indeterminate:{type:Boolean,sync:!0},_selectAllHidden:Boolean,_shiftKeyDown:{type:Boolean,value:!1}}}static get observers(){return["_onHeaderRendererOrBindingChanged(_headerRenderer, _headerCell, path, header, selectAll, _indeterminate, _selectAllHidden)"]}constructor(){super(),this.__onCellTrack=this.__onCellTrack.bind(this),this.__onCellClick=this.__onCellClick.bind(this),this.__onCellMouseDown=this.__onCellMouseDown.bind(this),this.__onGridInteraction=this.__onGridInteraction.bind(this),this.__onActiveItemChanged=this.__onActiveItemChanged.bind(this),this.__onSelectRowCheckboxChange=this.__onSelectRowCheckboxChange.bind(this),this.__onSelectAllCheckboxChange=this.__onSelectAllCheckboxChange.bind(this)}connectedCallback(){super.connectedCallback(),this._grid&&(this._grid.addEventListener("keyup",this.__onGridInteraction),this._grid.addEventListener("keydown",this.__onGridInteraction,{capture:!0}),this._grid.addEventListener("mousedown",this.__onGridInteraction),this._grid.addEventListener("active-item-changed",this.__onActiveItemChanged))}disconnectedCallback(){super.disconnectedCallback(),this._grid&&(this._grid.removeEventListener("keyup",this.__onGridInteraction),this._grid.removeEventListener("keydown",this.__onGridInteraction,{capture:!0}),this._grid.removeEventListener("mousedown",this.__onGridInteraction),this._grid.removeEventListener("active-item-changed",this.__onActiveItemChanged))}_defaultHeaderRenderer(e,t){let i=e.firstElementChild;i||(i=document.createElement("vaadin-checkbox"),i.accessibleName="Select All",i.classList.add("vaadin-grid-select-all-checkbox"),i.addEventListener("change",this.__onSelectAllCheckboxChange),e.appendChild(i));const s=this.__isChecked(this.selectAll,this._indeterminate);i.checked=s,i.indeterminate=this._indeterminate,i.style.visibility=this._selectAllHidden?"hidden":""}_defaultRenderer(e,t,{item:i,selected:s}){let o=e.firstElementChild;o||(o=document.createElement("vaadin-checkbox"),o.accessibleName="Select Row",o.addEventListener("change",this.__onSelectRowCheckboxChange),e.appendChild(o),se(e,"track",this.__onCellTrack),e.addEventListener("mousedown",this.__onCellMouseDown),e.addEventListener("click",this.__onCellClick)),o.__item=i,o.checked=s;const l=this._grid.__isItemSelectable(i);o.readonly=!l;const u=!l&&!s;o.style.visibility=u?"hidden":""}__onSelectAllCheckboxChange(e){this._indeterminate||e.currentTarget.checked?this._selectAll():this._deselectAll()}__onGridInteraction(e){this._shiftKeyDown=e.shiftKey,this.autoSelect&&this._grid.$.scroller.toggleAttribute("range-selecting",this._shiftKeyDown)}__onSelectRowCheckboxChange(e){this.__toggleItem(e.currentTarget.__item,e.currentTarget.checked)}__onCellTrack(e){if(this.dragSelect)if(this.__dragCurrentY=e.detail.y,this.__dragDy=e.detail.dy,e.detail.state==="start"){const i=this._grid._getRenderedRows().find(s=>s.contains(e.currentTarget.assignedSlot));this.__selectOnDrag=!this._grid._isSelected(i._item),this.__dragStartIndex=i.index,this.__dragStartItem=i._item,this.__dragAutoScroller()}else e.detail.state==="end"&&(this.__dragStartItem&&this.__toggleItem(this.__dragStartItem,this.__selectOnDrag),setTimeout(()=>{this.__dragStartIndex=void 0}))}__onCellMouseDown(e){this.dragSelect&&e.preventDefault()}__onCellClick(e){this.__dragStartIndex!==void 0&&e.preventDefault()}_onCellKeyDown(e){const t=e.composedPath()[0];if(e.keyCode===32){if(t===this._headerCell)this.selectAll?this._deselectAll():this._selectAll();else if(this._cells.includes(t)&&!this.autoSelect){const i=t._content.firstElementChild;this.__toggleItem(i.__item)}}}__onActiveItemChanged(e){const t=e.detail.value;if(this.autoSelect){const i=t||this.__previousActiveItem;i&&this.__toggleItem(i)}this.__previousActiveItem=t}__dragAutoScroller(){if(this.__dragStartIndex===void 0)return;const e=this._grid._getRenderedRows(),t=e.find(u=>{const p=u.getBoundingClientRect();return this.__dragCurrentY>=p.top&&this.__dragCurrentY<=p.bottom});let i=t?t.index:void 0;const s=this.__getScrollableArea();this.__dragCurrentY<s.top?i=this._grid._firstVisibleIndex:this.__dragCurrentY>s.bottom&&(i=this._grid._lastVisibleIndex),i!==void 0&&e.forEach(u=>{(i>this.__dragStartIndex&&u.index>=this.__dragStartIndex&&u.index<=i||i<this.__dragStartIndex&&u.index<=this.__dragStartIndex&&u.index>=i)&&(this.__toggleItem(u._item,this.__selectOnDrag),this.__dragStartItem=void 0)});const o=s.height*.15,l=10;if(this.__dragDy<0&&this.__dragCurrentY<s.top+o){const u=s.top+o-this.__dragCurrentY,p=Math.min(1,u/o);this._grid.$.table.scrollTop-=p*l}if(this.__dragDy>0&&this.__dragCurrentY>s.bottom-o){const u=this.__dragCurrentY-(s.bottom-o),p=Math.min(1,u/o);this._grid.$.table.scrollTop+=p*l}setTimeout(()=>this.__dragAutoScroller(),10)}__getScrollableArea(){const e=this._grid.$.table.getBoundingClientRect(),t=this._grid.$.header.getBoundingClientRect(),i=this._grid.$.footer.getBoundingClientRect();return{top:e.top+t.height,bottom:e.bottom-i.height,left:e.left,right:e.right,height:e.height-t.height-i.height,width:e.width}}_selectAll(){}_deselectAll(){}_selectItem(e){}_deselectItem(e){}__toggleItem(e,t=!this._grid._isSelected(e)){t!==this._grid._isSelected(e)&&(t?this._selectItem(e):this._deselectItem(e))}__isChecked(e,t){return t||e}};class be extends qt(qe){static get is(){return"vaadin-grid-flow-selection-column"}static get properties(){return{autoWidth:{type:Boolean,value:!0},width:{type:String,value:"56px"}}}_defaultHeaderRenderer(r,e){super._defaultHeaderRenderer(r,e);const t=r.firstElementChild;t&&(t.id="selectAllCheckbox")}_selectAll(){this.selectAll=!0,this.$server.selectAll()}_deselectAll(){this.selectAll=!1,this.$server.deselectAll()}_selectItem(r){this.$server.setShiftKeyDown(this._shiftKeyDown),this._grid.$connector.doSelection([r],!0)}_deselectItem(r){this.$server.setShiftKeyDown(this._shiftKeyDown),this._grid.$connector.doDeselection([r],!0),this.selectAll=!1}}customElements.define(be.is,be);window.Vaadin.Flow.gridConnector={};window.Vaadin.Flow.gridConnector.initLazy=n=>{if(n.$connector)return;const r=n._dataProviderController;r.ensureFlatIndexHierarchyOriginal=r.ensureFlatIndexHierarchy,r.ensureFlatIndexHierarchy=function(a){const{item:d}=this.getFlatIndexContext(a);if(!d||!this.isExpanded(d))return;n.$connector.hasCacheForParentKey(n.getItemId(d))?this.ensureFlatIndexHierarchyOriginal(a):n.$connector.beforeEnsureFlatIndexHierarchy(a,d)},r.isLoadingOriginal=r.isLoading,r.isLoading=function(){return n.$connector.hasEnsureSubCacheQueue()||this.isLoadingOriginal()},r.getItemSubCache=function(a){return this.getItemContext(a)?.subCache};let e={};const t=50,i=20;let s=[],o,l=[],u;const p=150;let _,g={};const f="null";g[f]=[0,0];let x=null,S=null;const z=["SINGLE","NONE","MULTI"];let I={},F="SINGLE",$=!1;n.size=0,n.itemIdPath="key";function Y(a){return{[n.itemIdPath]:a}}n.$connector={},n.$connector.hasCacheForParentKey=a=>e[a]?.size!==void 0,n.$connector.hasEnsureSubCacheQueue=()=>l.length>0,n.$connector.hasParentRequestQueue=()=>s.length>0,n.$connector.hasRootRequestQueue=()=>{const{pendingRequests:a}=r.rootCache;return Object.keys(a).length>0||!!_?.isActive()},n.$connector.beforeEnsureFlatIndexHierarchy=function(a,d){l.push({flatIndex:a,itemkey:n.getItemId(d)}),u=A.debounce(u,J,()=>{for(;l.length;)n.$connector.flushEnsureSubCache()})},n.$connector.doSelection=function(a,d){if(F==="NONE"||!a.length||d&&n.hasAttribute("disabled"))return;F==="SINGLE"&&(I={});let c=!1;a.forEach(h=>{const m=!d||n.isItemSelectable(h);c=c||m,h&&m&&(I[h.key]=h,h.selected=!0,d&&n.$server.select(h.key));const b=!n.activeItem||!h||h.key!=n.activeItem.key;!d&&F==="SINGLE"&&b&&(n.activeItem=h)}),c&&(n.selectedItems=Object.values(I))},n.$connector.doDeselection=function(a,d){if(F==="NONE"||!a.length||d&&n.hasAttribute("disabled"))return;const c=n.selectedItems.slice();for(;a.length;){const h=a.shift();if(!d||n.isItemSelectable(h)){for(let b=0;b<c.length;b++){const C=c[b];if(h?.key===C.key){c.splice(b,1);break}}h&&(delete I[h.key],delete h.selected,d&&n.$server.deselect(h.key))}}n.selectedItems=c},n.__activeItemChanged=function(a,d){F=="SINGLE"&&(a?I[a.key]||n.$connector.doSelection([a],!0):d&&I[d.key]&&(n.__deselectDisallowed?n.activeItem=d:(d=r.getItemContext(d).item,n.$connector.doDeselection([d],!0))))},n._createPropertyObserver("activeItem","__activeItemChanged",!0),n.__activeItemChangedDetails=function(a,d){n.__disallowDetailsOnClick||a==null&&d===void 0||(a&&!a.detailsOpened?n.$server.setDetailsVisible(a.key):n.$server.setDetailsVisible(null))},n._createPropertyObserver("activeItem","__activeItemChangedDetails",!0),n.$connector._getSameLevelPage=function(a,d,c){if((d.parentItem?n.getItemId(d.parentItem):f)===a)return Math.floor(c/n.pageSize);const{parentCache:m,parentCacheIndex:b}=d;return m?this._getSameLevelPage(a,m,b):null},n.$connector.flushEnsureSubCache=function(){const a=l.shift();return a?(r.ensureFlatIndexHierarchyOriginal(a.flatIndex),!0):!1},n.$connector.debounceRootRequest=function(a){const d=n._hasData?p:0;_=A.debounce(_,q.after(d),()=>{n.$connector.fetchPage((c,h)=>n.$server.setViewportRange(c,h),a,f)})},n.$connector.flushParentRequests=function(){const a=[];s.splice(0,i).forEach(({parentKey:d,page:c})=>{n.$connector.fetchPage((h,m)=>a.push({parentKey:d,firstIndex:h,size:m}),c,d)}),a.length&&n.$server.setParentRequestedRanges(a)},n.$connector.debounceParentRequest=function(a,d){s=s.filter(c=>c.parentKey!==a),s.push({parentKey:a,page:d}),o=A.debounce(o,q.after(t),()=>{for(;s.length;)n.$connector.flushParentRequests()})},n.$connector.fetchPage=function(a,d,c){c===f&&(d=Math.min(d,Math.floor((n.size-1)/n.pageSize)));const h=n._getRenderedRows();let m=h.length>0?h[0].index:0,b=h.length>0?h[h.length-1].index:0,C=b-m,E=Math.max(0,m-C),v=Math.min(b+C,n._flatSize),y=[null,null];for(let P=E;P<=v;P++){const{cache:Xe,index:Ze}=r.getFlatIndexContext(P),te=n.$connector._getSameLevelPage(c,Xe,Ze);te!==null&&(y[0]=Math.min(y[0]??te,te),y[1]=Math.max(y[1]??te,te))}(y.some(P=>P===null)||d<y[0]||d>y[1])&&(y=[d,d]);let T=g[c]||[-1,-1];if(T[0]!=y[0]||T[1]!=y[1]){g[c]=y;let P=y[1]-y[0]+1;a(y[0]*n.pageSize,P*n.pageSize)}},n.dataProvider=function(a,d){if(a.pageSize!=n.pageSize)throw"Invalid pageSize";let c=a.page;if(a.parentItem){let h=n.getItemId(a.parentItem);const m=r.getItemSubCache(a.parentItem);e[h]?.[c]&&m?(l=[],d(e[h][c],e[h].size)):n.$connector.debounceParentRequest(h,c)}else{if(n.size===0){d([],0);return}e[f]?.[c]?d(e[f][c]):n.$connector.debounceRootRequest(c)}},n.$connector.setSorterDirections=function(a){$=!0,setTimeout(()=>{try{const d=Array.from(n.querySelectorAll("vaadin-grid-sorter"));n._sorters.forEach(c=>{d.includes(c)||d.push(c)}),d.forEach(c=>{c.direction=null}),n.multiSortPriority!=="append"&&(a=a.reverse()),a.forEach(({column:c,direction:h})=>{d.forEach(m=>{m.getAttribute("path")===c&&(m.direction=h)})}),n.__applySorters()}finally{$=!1}})},n._updateItem=function(a,d){ne.prototype._updateItem.call(n,a,d),a.hidden||Array.from(a.children).forEach(c=>{Array.from(c?._content?.__templateInstance?.children||[]).forEach(h=>{h._attachRenderedComponentIfAble&&h._attachRenderedComponentIfAble(),Array.from(h?.children||[]).forEach(m=>{m._attachRenderedComponentIfAble&&m._attachRenderedComponentIfAble()})})}),F===z[1]&&(a.removeAttribute("aria-selected"),Array.from(a.children).forEach(c=>c.removeAttribute("aria-selected")))};const D=function(a,d){if(a==null||n.$server.updateExpandedState==null)return;let c=n.getItemId(a);n.$server.updateExpandedState(c,d)};n.expandItem=function(a){D(a,!0),ne.prototype.expandItem.call(n,a)},n.collapseItem=function(a){D(a,!1),ne.prototype.collapseItem.call(n,a)};const w=function(a){if(!a||!Array.isArray(a))throw"Attempted to call itemsUpdated with an invalid value: "+JSON.stringify(a);let d=Array.from(n.detailsOpenedItems);for(let c=0;c<a.length;++c){const h=a[c];h&&(h.detailsOpened?n._getItemIndexInArray(h,d)<0&&d.push(h):n._getItemIndexInArray(h,d)>=0&&d.splice(n._getItemIndexInArray(h,d),1))}n.detailsOpenedItems=d},O=function(a,d=f){const c=e[d][a],h=Y(d);let m=d===f?r.rootCache:r.getItemSubCache(h);return m&&!m.pendingRequests[a]&&m.setPage(a,c||Array.from({length:n.pageSize})),c},ae=function(){pe(),n.__updateVisibleRows()},pe=function(){r.recalculateFlatSize(),n._flatSize=r.flatSize},le=function(a){if(!a||!n.$||n.$.items.childElementCount===0)return;const d=a.map(h=>h.key),c=n._getRenderedRows().filter(h=>h._item&&d.includes(h._item.key)).map(h=>h.index);c.length>0&&n.__updateVisibleRows(c[0],c[c.length-1])};n.$connector.set=function(a,d,c){if(a%n.pageSize!=0)throw"Got new data to index "+a+" which is not aligned with the page size of "+n.pageSize;let h=c||f;const m=a/n.pageSize,b=Math.ceil(d.length/n.pageSize);h===f&&(S=[m,m+b-1]);for(let C=0;C<b;C++){let E=m+C,v=d.slice(C*n.pageSize,(C+1)*n.pageSize);e[h]||(e[h]={}),e[h][E]=v,n.$connector.doSelection(v.filter(T=>T.selected)),n.$connector.doDeselection(v.filter(T=>!T.selected&&I[T.key]));const y=O(E,h);y&&(w(y),le(y))}};const Ee=function(a){let d=a.parentUniqueKey||f;if(e[d]){for(let c in e[d])for(let h in e[d][c])if(n.getItemId(e[d][c][h])===n.getItemId(a))return{page:c,index:h,parentKey:d}}return null};n.$connector.updateHierarchicalData=function(a){let d=[];for(let h=0;h<a.length;h++){let m=Ee(a[h]);if(m){e[m.parentKey][m.page][m.index]=a[h];let b=m.parentKey+":"+m.page;d[b]||(d[b]={parentKey:m.parentKey,page:m.page})}}let c=Object.keys(d);for(let h=0;h<c.length;h++){let m=d[c[h]];const b=O(m.page,m.parentKey);b&&(w(b),le(b))}},n.$connector.updateFlatData=function(a){for(let d=0;d<a.length;d++){let c=Ee(a[d]);if(c){e[c.parentKey][c.page][c.index]=a[d];const h=parseInt(c.page)*n.pageSize+parseInt(c.index),{rootCache:m}=r;m.items[h]&&(m.items[h]=a[d])}}w(a),le(a)},n.$connector.clearExpanded=function(){n.expandedItems=[],l=[],s=[]};const Qe=function(){const a=g[f];if(!a||!x)return;const d=x[1]-x[0]+1,c=Array.from({length:d},(h,m)=>x[0]+m);if(S){const[h,m]=S;for(let b=h;b<=m;b++){const C=c.indexOf(b);C>=0&&c.splice(C,1)}}c.some(h=>h>=a[0]&&h<=a[1])&&(a[0]=-1,a[1]=-1)};n.$connector.clear=function(a,d,c){let h=c||f;if(!e[h]||Object.keys(e[h]).length===0)return;if(a%n.pageSize!=0)throw"Got cleared data for index "+a+" which is not aligned with the page size of "+n.pageSize;let m=Math.floor(a/n.pageSize),b=Math.ceil(d/n.pageSize);h===f&&(x=[m,m+b-1]);for(let v=0;v<b;v++){let y=m+v,T=e[h][y];n.$connector.doDeselection(T.filter(P=>I[P.key])),T.forEach(P=>n.closeItemDetails(P)),delete e[h][y],O(y,c),le(T)}let C=r.rootCache;if(c){const v=Y(h);C=r.getItemSubCache(v)}const E=a+b*n.pageSize;for(let v=a;v<E;v++)delete C.items[v],C.removeSubCache(v);pe()},n.$connector.reset=function(){e={},r.clearCache(),g={},u?.cancel(),o?.cancel(),_?.cancel(),l=[],s=[],ae()},n.$connector.updateSize=a=>n.size=a,n.$connector.updateUniqueItemIdPath=a=>n.itemIdPath=a,n.$connector.expandItems=function(a){let d=Array.from(n.expandedItems);a.filter(c=>!n._isExpanded(c)).forEach(c=>d.push(c)),n.expandedItems=d},n.$connector.collapseItems=function(a){let d=Array.from(n.expandedItems);a.forEach(c=>{let h=n._getItemIndexInArray(c,d);h>=0&&d.splice(h,1)}),n.expandedItems=d,a.forEach(c=>n.$connector.removeFromQueue(c))},n.$connector.removeFromQueue=function(a){const d=r.getItemSubCache(a);Object.values(d?.pendingRequests||{}).forEach(h=>h([]));const c=n.getItemId(a);l=l.filter(h=>h.itemkey!==c),s=s.filter(h=>h.parentKey!==c)},n.$connector.confirmParent=function(a,d,c){e[d]||(e[d]={});const h=e[d].size!==c;e[d].size=c,c===0&&(e[d][0]=[]);const m=Y(d),b=r.getItemSubCache(m);if(b){const{pendingRequests:C}=b;Object.entries(C).forEach(([E,v])=>{let y=g[d]||[0,0];if(e[d]&&e[d][E]||E<y[0]||E>y[1]){let T=e[d][E]||new Array(c);v(T,c)}else v&&c===0&&v([],c)}),h&&Object.keys(C).length===0&&(b.size=c,pe())}n.$server.confirmParentUpdate(a,d)},n.$connector.confirm=function(a){const{pendingRequests:d}=r.rootCache;Object.entries(d).forEach(([c,h])=>{const m=g[f]||[0,0],b=n.size?Math.ceil(n.size/n.pageSize)-1:0,C=Math.min(m[1],b);e[f]?.[c]?h(e[f][c]):c<m[0]||+c>C?(h(new Array(n.pageSize)),n.requestContentUpdate()):h&&n.size===0&&h([])}),Qe(),S=null,x=null,n.$server.confirmUpdate(a)},n.$connector.ensureHierarchy=function(){for(let a in e)a!==f&&delete e[a];g={},r.rootCache.removeSubCaches(),ae()},n.$connector.setSelectionMode=function(a){if((typeof a=="string"||a instanceof String)&&z.indexOf(a)>=0)F=a,I={},n.selectedItems=[],n.$connector.updateMultiSelectable();else throw"Attempted to set an invalid selection mode"},n.$connector.updateMultiSelectable=function(){n.$&&(F===z[0]?n.$.table.setAttribute("aria-multiselectable",!1):F===z[1]?n.$.table.removeAttribute("aria-multiselectable"):n.$.table.setAttribute("aria-multiselectable",!0))},n._createPropertyObserver("isAttached",()=>n.$connector.updateMultiSelectable());const Ie=a=>d=>{a&&(a(d),a=null)};n.$connector.setHeaderRenderer=function(a,d){const{content:c,showSorter:h,sorterPath:m}=d;if(c===null){a.headerRenderer=null;return}a.headerRenderer=Ie(b=>{b.innerHTML="";let C=b;if(h){const E=document.createElement("vaadin-grid-sorter");E.setAttribute("path",m);const v=c instanceof Node?c.textContent:c;v&&E.setAttribute("aria-label",`Sort by ${v}`),b.appendChild(E),C=E}c instanceof Node?C.appendChild(c):C.textContent=c})},n._getActiveSorters=function(){return this._sorters.filter(a=>a.direction)},n.__applySorters=()=>{const a=n._mapSorters(),d=JSON.stringify(n._previousSorters)!==JSON.stringify(a);n._previousSorters=a,ne.prototype.__applySorters.call(n),d&&!$&&n.$server.sortersChanged(a)},n.$connector.setFooterRenderer=function(a,d){const{content:c}=d;if(c===null){a.footerRenderer=null;return}a.footerRenderer=Ie(h=>{h.innerHTML="",c instanceof Node?h.appendChild(c):h.textContent=c})},n.addEventListener("vaadin-context-menu-before-open",function(a){const{key:d,columnId:c}=a.detail;n.$server.updateContextMenuTargetItem(d,c)}),n.getContextMenuBeforeOpenDetail=function(a){const d=a.detail.sourceEvent||a,c=n.getEventContext(d),h=c.item?.key||"",m=c.column?.id||"";return{key:h,columnId:m}},n.preventContextMenu=function(a){const d=a.type==="click",{column:c}=n.getEventContext(a);return d&&c instanceof be},n.addEventListener("click",a=>Se(a,"item-click")),n.addEventListener("dblclick",a=>Se(a,"item-double-click")),n.addEventListener("column-resize",a=>{n._getColumnsInOrder().filter(c=>!c.hidden).forEach(c=>{c.dispatchEvent(new CustomEvent("column-drag-resize"))}),n.dispatchEvent(new CustomEvent("column-drag-resize",{detail:{resizedColumnKey:a.detail.resizedColumn._flowId}}))}),n.addEventListener("column-reorder",a=>{const d=n._columnTree.slice(0).pop().filter(c=>c._flowId).sort((c,h)=>c._order-h._order).map(c=>c._flowId);n.dispatchEvent(new CustomEvent("column-reorder-all-columns",{detail:{columns:d}}))}),n.addEventListener("cell-focus",a=>{const d=n.getEventContext(a);["header","body","footer"].indexOf(d.section)!==-1&&n.dispatchEvent(new CustomEvent("grid-cell-focus",{detail:{itemKey:d.item?d.item.key:null,internalColumnId:d.column?d.column._flowId:null,section:d.section}}))});function Se(a,d){if(a.defaultPrevented)return;const c=a.composedPath(),h=c.findIndex(v=>v.localName==="td"||v.localName==="th"),m=c[h];if(c.slice(0,h).some(v=>m?._focusButton!==v&&Ke(v)||v instanceof HTMLLabelElement))return;const C=n.getEventContext(a),E=C.section;C.item&&E!=="details"&&(a.itemKey=C.item.key,C.column&&(a.internalColumnId=C.column._flowId),n.dispatchEvent(new CustomEvent(d,{detail:a})))}n.cellClassNameGenerator=function(a,d){const c=d.item.style;if(c)return(c.row||"")+" "+(a&&c[a._flowId]||"")},n.cellPartNameGenerator=function(a,d){const c=d.item.part;if(c)return(c.row||"")+" "+(a&&c[a._flowId]||"")},n.dropFilter=a=>a.item&&!a.item.dropDisabled,n.dragFilter=a=>a.item&&!a.item.dragDisabled,n.addEventListener("grid-dragstart",a=>{n._isSelected(a.detail.draggedItems[0])?(n.__selectionDragData?Object.keys(n.__selectionDragData).forEach(d=>{a.detail.setDragData(d,n.__selectionDragData[d])}):(n.__dragDataTypes||[]).forEach(d=>{a.detail.setDragData(d,a.detail.draggedItems.map(c=>c.dragData[d]).join(`
`))}),n.__selectionDraggedItemsCount>1&&a.detail.setDraggedItemsCount(n.__selectionDraggedItemsCount)):(n.__dragDataTypes||[]).forEach(d=>{a.detail.setDragData(d,a.detail.draggedItems[0].dragData[d])})}),n.isItemSelectable=a=>a?.selectable===void 0||a.selectable};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const Kt=n=>class extends Ue(n){static get properties(){return{_childColumns:{value(){return this._getChildColumns(this)}},flexGrow:{type:Number,readOnly:!0,sync:!0},width:{type:String,readOnly:!0,sync:!0},_visibleChildColumns:Array,_colSpan:Number,_rootColumns:Array}}static get observers(){return["_groupFrozenChanged(frozen, _rootColumns)","_groupFrozenToEndChanged(frozenToEnd, _rootColumns)","_groupHiddenChanged(hidden)","_colSpanChanged(_colSpan, _headerCell, _footerCell)","_groupOrderChanged(_order, _rootColumns)","_groupReorderStatusChanged(_reorderStatus, _rootColumns)","_groupResizableChanged(resizable, _rootColumns)"]}connectedCallback(){super.connectedCallback(),this._addNodeObserver(),this._updateFlexAndWidth()}disconnectedCallback(){super.disconnectedCallback(),this._observer&&this._observer.disconnect()}_columnPropChanged(r,e){r==="hidden"&&(this._preventHiddenSynchronization=!0,this._updateVisibleChildColumns(this._childColumns),this._preventHiddenSynchronization=!1),/flexGrow|width|hidden|_childColumns/u.test(r)&&this._updateFlexAndWidth(),r==="frozen"&&!this.frozen&&(this.frozen=e),r==="lastFrozen"&&!this._lastFrozen&&(this._lastFrozen=e),r==="frozenToEnd"&&!this.frozenToEnd&&(this.frozenToEnd=e),r==="firstFrozenToEnd"&&!this._firstFrozenToEnd&&(this._firstFrozenToEnd=e)}_groupOrderChanged(r,e){if(e){const t=e.slice(0);if(!r){t.forEach(l=>{l._order=0});return}const i=/(0+)$/u.exec(r).pop().length,s=~~(Math.log(e.length)/Math.LN10)+1,o=10**(i-s);t[0]&&t[0]._order&&t.sort((l,u)=>l._order-u._order),Ve(t,o,r)}}_groupReorderStatusChanged(r,e){r===void 0||e===void 0||e.forEach(t=>{t._reorderStatus=r})}_groupResizableChanged(r,e){r===void 0||e===void 0||e.forEach(t=>{t.resizable=r})}_updateVisibleChildColumns(r){this._visibleChildColumns=Array.prototype.filter.call(r,e=>!e.hidden),this._colSpan=this._visibleChildColumns.length,this._updateAutoHidden()}_updateFlexAndWidth(){if(this._visibleChildColumns){if(this._visibleChildColumns.length>0){const r=this._visibleChildColumns.reduce((e,t)=>(e+=` + ${(t.width||"0px").replace("calc","")}`,e),"").substring(3);this._setWidth(`calc(${r})`)}else this._setWidth("0px");this._setFlexGrow(Array.prototype.reduce.call(this._visibleChildColumns,(r,e)=>r+e.flexGrow,0))}}__scheduleAutoFreezeWarning(r,e){if(this._grid){const t=e.replace(/([A-Z])/gu,"-$1").toLowerCase(),i=r[0][e]||r[0].hasAttribute(t);r.every(o=>(o[e]||o.hasAttribute(t))===i)||(this._grid.__autoFreezeWarningDebouncer=A.debounce(this._grid.__autoFreezeWarningDebouncer,J,()=>{console.warn(`WARNING: Joining ${e} and non-${e} Grid columns inside the same column group! This will automatically freeze all the joined columns to avoid rendering issues. If this was intentional, consider marking each joined column explicitly as ${e}. Otherwise, exclude the ${e} columns from the joined group.`)}))}}_groupFrozenChanged(r,e){e===void 0||r===void 0||r!==!1&&(this.__scheduleAutoFreezeWarning(e,"frozen"),Array.from(e).forEach(t=>{t.frozen=r}))}_groupFrozenToEndChanged(r,e){e===void 0||r===void 0||r!==!1&&(this.__scheduleAutoFreezeWarning(e,"frozenToEnd"),Array.from(e).forEach(t=>{t.frozenToEnd=r}))}_groupHiddenChanged(r){(r||this.__groupHiddenInitialized)&&this._synchronizeHidden(),this.__groupHiddenInitialized=!0}_updateAutoHidden(){const r=this._autoHidden;this._autoHidden=(this._visibleChildColumns||[]).length===0,(r||this._autoHidden)&&(this.hidden=this._autoHidden)}_synchronizeHidden(){this._childColumns&&!this._preventHiddenSynchronization&&this._childColumns.forEach(r=>{r.hidden=this.hidden})}_colSpanChanged(r,e,t){e&&(e.setAttribute("colspan",r),this._grid&&this._grid._a11yUpdateCellColspan(e,r)),t&&(t.setAttribute("colspan",r),this._grid&&this._grid._a11yUpdateCellColspan(t,r))}_getChildColumns(r){return L.getColumns(r)}_addNodeObserver(){this._observer=new L(this,()=>{this._preventHiddenSynchronization=!0,this._rootColumns=this._getChildColumns(this),this._childColumns=this._rootColumns,this._updateVisibleChildColumns(this._childColumns),this._preventHiddenSynchronization=!1,this._grid&&this._grid._debounceUpdateColumnTree&&this._grid._debounceUpdateColumnTree()}),this._observer.flush()}_isColumnElement(r){return r.nodeType===Node.ELEMENT_NODE&&/\bcolumn\b/u.test(r.localName)}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */class Yt extends Kt(G){static get is(){return"vaadin-grid-column-group"}}N(Yt);const jt=W`
  /* :hover needed to workaround https://github.com/vaadin/web-components/issues/3133 */
  :host(:hover) {
    user-select: none;
    -webkit-user-select: none;
  }

  :host([role='menuitem'][menu-item-checked]) [part='checkmark']::before {
    opacity: 1;
  }

  :host([aria-haspopup='true'])::after {
    font-family: lumo-icons;
    font-size: var(--lumo-icon-size-xs);
    content: var(--lumo-icons-angle-right);
    color: var(--lumo-tertiary-text-color);
  }

  :host(:not([dir='rtl'])[aria-haspopup='true'])::after {
    margin-right: calc(var(--lumo-space-m) * -1);
    padding-left: var(--lumo-space-m);
  }

  :host([expanded]) {
    background-color: var(--lumo-primary-color-10pct);
  }

  /* RTL styles */
  :host([dir='rtl'][aria-haspopup='true'])::after {
    content: var(--lumo-icons-angle-left);
    margin-left: calc(var(--lumo-space-m) * -1);
    padding-right: var(--lumo-space-m);
  }
`;H("vaadin-context-menu-item",[ot,jt],{moduleId:"lumo-context-menu-item"});const Qt=W`
  :host {
    --_lumo-list-box-item-selected-icon-display: block;
  }

  /* Normal item */
  [part='items'] ::slotted([role='menuitem']) {
    -webkit-tap-highlight-color: var(--lumo-primary-color-10pct);
    cursor: default;
    outline: none;
    border-radius: var(--lumo-border-radius-m);
    padding-left: calc(var(--lumo-border-radius-m) / 4);
    padding-right: calc(var(--lumo-space-l) + var(--lumo-border-radius-m) / 4);
  }

  /* Hovered item */
  /* TODO a workaround until we have "focus-follows-mouse". After that, use the hover style for focus-ring as well */
  [part='items'] ::slotted([role='menuitem']:hover:not([disabled])),
  [part='items'] ::slotted([role='menuitem'][expanded]:not([disabled])) {
    background-color: var(--lumo-primary-color-10pct);
  }

  /* RTL styles */
  :host([dir='rtl']) [part='items'] ::slotted([role='menuitem']) {
    padding-left: calc(var(--lumo-space-l) + var(--lumo-border-radius-m) / 4);
    padding-right: calc(var(--lumo-border-radius-m) / 4);
  }

  /* Focused item */
  @media (pointer: coarse) {
    [part='items'] ::slotted([role='menuitem']:hover:not([expanded]):not([disabled])) {
      background-color: transparent;
    }
  }
`;H("vaadin-context-menu-list-box",[at,Qt],{moduleId:"lumo-context-menu-list-box"});const Xt=W`
  :host([phone]) {
    /* stylelint-disable declaration-block-no-redundant-longhand-properties */
    top: 0 !important;
    right: 0 !important;
    bottom: var(--vaadin-overlay-viewport-bottom) !important;
    left: 0 !important;
    /* stylelint-enable declaration-block-no-redundant-longhand-properties */
    align-items: stretch;
    justify-content: flex-end;
  }

  /* TODO These style overrides should not be needed.
   We should instead offer a way to have non-selectable items inside the context menu. */

  :host {
    --_lumo-list-box-item-selected-icon-display: none;
    --_lumo-list-box-item-padding-left: calc(var(--lumo-space-m) + var(--lumo-border-radius-m) / 4);
  }

  [part='overlay'] {
    outline: none;
  }
`;H("vaadin-context-menu-overlay",[lt,Xt],{moduleId:"lumo-context-menu-overlay"});/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */dt({name:"vaadin-contextmenu",deps:["touchstart","touchmove","touchend","contextmenu"],flow:{start:["touchstart","contextmenu"],end:["contextmenu"]},emits:["vaadin-contextmenu"],info:{sourceEvent:null},reset(){this.info.sourceEvent=null,this._cancelTimer(),this.info.touchJob=null,this.info.touchStartCoords=null},_cancelTimer(){this._timerId&&(clearTimeout(this._timerId),delete this._fired)},_setSourceEvent(n){this.info.sourceEvent=n;const r=n.composedPath();this.info.sourceEvent.__composedPath=r},touchstart(n){this._setSourceEvent(n),this.info.touchStartCoords={x:n.changedTouches[0].clientX,y:n.changedTouches[0].clientY};const r=n.composedPath()[0]||n.target;this._timerId=setTimeout(()=>{const e=n.changedTouches[0];n.shiftKey||(he&&(this._fired=!0,this.fire(r,e.clientX,e.clientY)),ze("tap"))},500)},touchmove(n){const e=this.info.touchStartCoords;(Math.abs(e.x-n.changedTouches[0].clientX)>15||Math.abs(e.y-n.changedTouches[0].clientY)>15)&&this._cancelTimer()},touchend(n){this._fired&&n.preventDefault(),this._cancelTimer()},contextmenu(n){if(!n.shiftKey){if(this._setSourceEvent(n),He&&xe()){const r=n.composedPath()[0],e=r.getBoundingClientRect();this.fire(r,e.left,e.bottom)}else this.fire(n.target,n.clientX,n.clientY);ze("tap")}},fire(n,r,e){const t=this.info.sourceEvent,i=new Event("vaadin-contextmenu",{bubbles:!0,cancelable:!0,composed:!0});i.detail={x:r,y:e,sourceEvent:t},n.dispatchEvent(i),i.defaultPrevented&&t&&t.preventDefault&&t.preventDefault()}});/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */class Zt extends ct(oe(re(G))){static get is(){return"vaadin-context-menu-item"}static get template(){return ee`
      <style>
        :host {
          display: inline-block;
        }

        :host([hidden]) {
          display: none !important;
        }
      </style>
      <span part="checkmark" aria-hidden="true"></span>
      <div part="content">
        <slot></slot>
      </div>
    `}ready(){super.ready(),this.setAttribute("role","menuitem")}}N(Zt);/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */class Jt extends ht(oe(re(Ae(G)))){static get is(){return"vaadin-context-menu-list-box"}static get template(){return ee`
      <style>
        :host {
          display: flex;
        }

        :host([hidden]) {
          display: none !important;
        }

        [part='items'] {
          height: 100%;
          width: 100%;
          overflow-y: auto;
          -webkit-overflow-scrolling: touch;
        }
      </style>
      <div part="items">
        <slot></slot>
      </div>
    `}static get properties(){return{orientation:{readOnly:!0}}}get _scrollerElement(){return this.shadowRoot.querySelector('[part="items"]')}ready(){super.ready(),this.setAttribute("role","menu")}}N(Jt);/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const ei=n=>class extends ut(_t(n)){static get properties(){return{parentOverlay:{type:Object,readOnly:!0},_theme:{type:String,readOnly:!0,sync:!0}}}static get observers(){return["_themeChanged(_theme)"]}ready(){super.ready(),this.restoreFocusOnClose=!0,this.addEventListener("keydown",e=>{if(!e.defaultPrevented&&e.composedPath()[0]===this.$.overlay&&[38,40].indexOf(e.keyCode)>-1){const t=this.getFirstChild();t&&Array.isArray(t.items)&&t.items.length&&(e.preventDefault(),e.keyCode===38?t.items[t.items.length-1].focus():t.focus())}})}getFirstChild(){return this.querySelector(":not(style):not(slot)")}_themeChanged(){this.close()}getBoundaries(){const e=this.getBoundingClientRect(),t=this.$.overlay.getBoundingClientRect();let i=e.bottom-t.height;const s=this.parentOverlay;if(s&&s.hasAttribute("bottom-aligned")){const o=getComputedStyle(s);i=i-parseFloat(o.bottom)-parseFloat(o.height)}return{xMax:e.right-t.width,xMin:e.left+t.width,yMax:i}}_updatePosition(){if(super._updatePosition(),this.positionTarget&&this.parentOverlay){const e=this.$.content,t=getComputedStyle(e);!!this.style.left?this.style.left=`${parseFloat(this.style.left)+parseFloat(t.paddingLeft)}px`:this.style.right=`${parseFloat(this.style.right)+parseFloat(t.paddingRight)}px`,!!this.style.bottom?this.style.bottom=`${parseFloat(this.style.bottom)-parseFloat(t.paddingBottom)}px`:this.style.top=`${parseFloat(this.style.top)-parseFloat(t.paddingTop)}px`}}_shouldRestoreFocus(){return this.parentOverlay?!1:super._shouldRestoreFocus()}_deepContains(e){let t=Ne(this.localName,e);for(;t;){if(t===this)return!0;t=t.parentOverlay}return!1}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const ti=W`
  :host {
    align-items: flex-start;
    justify-content: flex-start;
  }

  :host([right-aligned]),
  :host([end-aligned]) {
    align-items: flex-end;
  }

  :host([bottom-aligned]) {
    justify-content: flex-end;
  }

  [part='overlay'] {
    background-color: #fff;
  }

  @media (forced-colors: active) {
    [part='overlay'] {
      outline: 3px solid !important;
    }
  }
`;/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */H("vaadin-context-menu-overlay",[ft,ti],{moduleId:"vaadin-context-menu-overlay-styles"});class ii extends ei(pt(re(oe(G)))){static get is(){return"vaadin-context-menu-overlay"}static get template(){return ee`
      <div id="backdrop" part="backdrop" hidden$="[[!withBackdrop]]"></div>
      <div part="overlay" id="overlay" tabindex="0">
        <div part="content" id="content">
          <slot></slot>
        </div>
      </div>
    `}}N(ii);/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const ni=n=>class extends n{static get properties(){return{items:{type:Array,sync:!0}}}constructor(){super(),this.__itemsOutsideClickListener=e=>{this._shouldCloseOnOutsideClick(e)&&this.dispatchEvent(new CustomEvent("items-outside-click"))},this.addEventListener("items-outside-click",()=>{this.items&&this.close()})}get _tagNamePrefix(){return"vaadin-context-menu"}connectedCallback(){super.connectedCallback(),document.documentElement.addEventListener("click",this.__itemsOutsideClickListener)}disconnectedCallback(){super.disconnectedCallback(),document.documentElement.removeEventListener("click",this.__itemsOutsideClickListener)}_shouldCloseOnOutsideClick(e){return!e.composedPath().some(t=>t.localName===`${this._tagNamePrefix}-overlay`)}__forwardFocus(){const e=this._overlayElement,t=e.getFirstChild();if(e.parentOverlay){const i=e.parentOverlay.querySelector("[expanded]");i&&i.hasAttribute("focused")&&t?t.focus():e.$.overlay.focus()}else t&&t.focus()}__openSubMenu(e,t,i){this.__updateSubMenuForItem(e,t),e.overlayClass=i;const s=this._overlayElement,o=e._overlayElement;o.noHorizontalOverlap=!0,o._setParentOverlay(s),s.hasAttribute("theme")?e.setAttribute("theme",s.getAttribute("theme")):e.removeAttribute("theme");const l=o.$.content;l.style.minWidth="",t.dispatchEvent(new CustomEvent("opensubmenu",{detail:{children:t._item.children}}))}__updateSubMenuForItem(e,t){e.items=t._item.children,e.listenOn=t,e._overlayElement.positionTarget=t}__createComponent(e){let t;return e.component instanceof HTMLElement?t=e.component:t=document.createElement(e.component||`${this._tagNamePrefix}-item`),t._hasVaadinItemMixin&&(t.setAttribute("role","menuitem"),t.tabIndex=-1),t.localName==="hr"?t.setAttribute("role","separator"):t.setAttribute("aria-haspopup","false"),this._setMenuItemTheme(t,e,this._theme),t._item=e,e.text&&(t.textContent=e.text),e.className&&t.setAttribute("class",e.className),this.__toggleMenuComponentAttribute(t,"menu-item-checked",e.checked),this.__toggleMenuComponentAttribute(t,"disabled",e.disabled),e.children&&e.children.length&&(this.__updateExpanded(t,!1),t.setAttribute("aria-haspopup","true")),t}__initListBox(){const e=document.createElement(`${this._tagNamePrefix}-list-box`);return this._theme&&e.setAttribute("theme",this._theme),e.addEventListener("selected-changed",t=>{const{value:i}=t.detail;if(typeof i=="number"){const s=e.items[i]._item;e.selected=null,s.children||this.dispatchEvent(new CustomEvent("item-selected",{detail:{value:s}}))}}),e}__initOverlay(){const e=this._overlayElement;e.$.backdrop.addEventListener("click",()=>{this.close()}),e.addEventListener(ye?"click":"mouseover",t=>{this.__showSubMenu(t)}),e.addEventListener("keydown",t=>{const{key:i}=t,s=this.__isRTL,o=i==="ArrowRight",l=i==="ArrowLeft";!s&&o||s&&l||i==="Enter"||i===" "?this.__showSubMenu(t):!s&&l||s&&o||i==="Escape"?(i==="Escape"&&t.stopPropagation(),this.close(),this.listenOn.focus()):i==="Tab"&&!t.defaultPrevented&&this.dispatchEvent(new CustomEvent("close-all-menus"))})}__initSubMenu(){const e=document.createElement(this.constructor.is);return e._modeless=!0,e.openOn="opensubmenu",e.setAttribute("hidden",""),this.addEventListener("opened-changed",t=>{t.detail.value||this._subMenu.close()}),e.addEventListener("close-all-menus",()=>{this.dispatchEvent(new CustomEvent("close-all-menus"))}),e.addEventListener("item-selected",t=>{const{detail:i}=t;this.dispatchEvent(new CustomEvent("item-selected",{detail:i}))}),this.addEventListener("close-all-menus",()=>{this._overlayElement.close()}),this.addEventListener("item-selected",t=>{const i=t.target,s=t.detail.value,o=i.items.indexOf(s);s.keepOpen&&o>-1&&i.opened?(i.__selectedIndex=o,i.requestContentUpdate()):s.keepOpen||this.close()}),e.addEventListener("opened-changed",t=>{if(!t.detail.value){const i=this._listBox.querySelector("[expanded]");i&&this.__updateExpanded(i,!1)}}),e}__showSubMenu(e,t=e.composedPath().find(i=>i.localName===`${this._tagNamePrefix}-item`)){if(!this.__openListenerActive)return;if(this._overlayElement.hasAttribute("opening")){requestAnimationFrame(()=>{this.__showSubMenu(e,t)});return}const i=this._subMenu;if(t){const{children:s}=t._item,o=i._overlayElement.getFirstChild(),l=o&&o.focused;if(i.items!==s&&i.close(),!this.opened)return;if(s&&s.length){this.__updateExpanded(t,!0);const{overlayClass:u}=this;this.__openSubMenu(i,t,u)}else l?i.listenOn.focus():this._listBox.focused||this._overlayElement.$.overlay.focus()}}__getListBox(){return this._overlayElement.querySelector(`${this._tagNamePrefix}-list-box`)}__itemsRenderer(e,t){this.__initMenu(e,t);const i=e.querySelector(this.constructor.is);i.closeOn=t.closeOn;const s=this.__getListBox();s.innerHTML="",t.items.forEach(o=>{const l=this.__createComponent(o);s.appendChild(l)})}_setMenuItemTheme(e,t,i){let s=e.getAttribute("theme")||i;t.theme!=null&&(s=Array.isArray(t.theme)?t.theme.join(" "):t.theme),this.__updateTheme(e,s)}__toggleMenuComponentAttribute(e,t,i){i?(e.setAttribute(t,""),e[`__has-${t}`]=!0):e[`__has-${t}`]&&(e.removeAttribute(t),e[`__has-${t}`]=!1)}__initMenu(e,t){if(e.firstElementChild)this.__updateTheme(this._listBox,this._theme);else{this.__initOverlay();const i=this.__initListBox();this._listBox=i,e.appendChild(i);const s=this.__initSubMenu();this._subMenu=s,e.appendChild(s),requestAnimationFrame(()=>{this.__openListenerActive=!0})}}__updateExpanded(e,t){e.setAttribute("aria-expanded",t.toString()),e.toggleAttribute("expanded",t)}__updateTheme(e,t){t?e.setAttribute("theme",t):e.removeAttribute("theme")}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const ri=n=>class extends ni(n){static get properties(){return{selector:{type:String},opened:{type:Boolean,value:!1,notify:!0,readOnly:!0},openOn:{type:String,value:"vaadin-contextmenu",sync:!0},listenOn:{type:Object,sync:!0,value(){return this}},closeOn:{type:String,value:"click",observer:"_closeOnChanged",sync:!0},renderer:{type:Function,sync:!0},_modeless:{type:Boolean,sync:!0},_context:{type:Object,sync:!0},_phone:{type:Boolean},_fullscreen:{type:Boolean},_fullscreenMediaQuery:{type:String,value:"(max-width: 450px), (max-height: 450px)"}}}static get observers(){return["_openedChanged(opened)","_targetOrOpenOnChanged(listenOn, openOn)","_rendererChanged(renderer, items)","_fullscreenChanged(_fullscreen)","_overlayContextChanged(_overlayElement, _context)","_overlayModelessChanged(_overlayElement, _modeless)","_overlayPhoneChanged(_overlayElement, _phone)","_overlayThemeChanged(_overlayElement, _theme)"]}constructor(){super(),this._createOverlay(),this._boundOpen=this.open.bind(this),this._boundClose=this.close.bind(this),this._boundPreventDefault=this._preventDefault.bind(this),this._boundOnGlobalContextMenu=this._onGlobalContextMenu.bind(this)}connectedCallback(){super.connectedCallback(),this.__boundOnScroll=this.__onScroll.bind(this),window.addEventListener("scroll",this.__boundOnScroll,!0),this.__restoreOpened&&this._setOpened(!0)}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("scroll",this.__boundOnScroll,!0),this.__restoreOpened=this.opened,this.close()}ready(){super.ready(),this.addController(new mt(this._fullscreenMediaQuery,e=>{this._fullscreen=e}))}_createOverlay(){const e=document.createElement(`${this._tagNamePrefix}-overlay`);e.owner=this,e.addEventListener("opened-changed",t=>{this._onOverlayOpened(t)}),e.addEventListener("vaadin-overlay-open",t=>{this._onVaadinOverlayOpen(t)}),this._overlayElement=e}_onOverlayOpened(e){const t=e.detail.value;this._setOpened(t),t&&this.__alignOverlayPosition()}_onVaadinOverlayOpen(){this.__alignOverlayPosition(),this._overlayElement.style.visibility="",this.__forwardFocus()}_overlayContextChanged(e,t){e&&(e.model=t)}_overlayModelessChanged(e,t){e&&(e.modeless=t)}_overlayPhoneChanged(e,t){e&&(e.toggleAttribute("phone",t),e.withBackdrop=t)}_overlayThemeChanged(e,t){e&&(t?e.setAttribute("theme",t):e.removeAttribute("theme"))}_targetOrOpenOnChanged(e,t){this._oldListenOn&&this._oldOpenOn&&(this._unlisten(this._oldListenOn,this._oldOpenOn,this._boundOpen),this._oldListenOn.style.webkitTouchCallout="",this._oldListenOn.style.webkitUserSelect="",this._oldListenOn.style.userSelect="",this._oldListenOn=null,this._oldOpenOn=null),e&&t&&(this._listen(e,t,this._boundOpen),this._oldListenOn=e,this._oldOpenOn=t)}_fullscreenChanged(e){this._phone=e}__setListenOnUserSelect(e){const t=e?"none":"";this.listenOn.style.webkitTouchCallout=t,this.listenOn.style.webkitUserSelect=t,this.listenOn.style.userSelect=t,e&&document.getSelection().removeAllRanges()}_closeOnChanged(e,t){const i="vaadin-overlay-outside-click",s=this._overlayElement;t&&this._unlisten(s,t,this._boundClose),e?(this._listen(s,e,this._boundClose),s.removeEventListener(i,this._boundPreventDefault)):s.addEventListener(i,this._boundPreventDefault)}_preventDefault(e){e.preventDefault()}_openedChanged(e){e?document.documentElement.addEventListener("contextmenu",this._boundOnGlobalContextMenu,!0):document.documentElement.removeEventListener("contextmenu",this._boundOnGlobalContextMenu,!0),this.__setListenOnUserSelect(e),this._overlayElement.opened=e}requestContentUpdate(){this._overlayElement&&(this.__preserveMenuState(),this._overlayElement.requestContentUpdate(),this.__restoreMenuState())}_rendererChanged(e,t){if(t){if(e)throw new Error("The items API cannot be used together with a renderer");this.closeOn==="click"&&(this.closeOn=""),e=this.__itemsRenderer}this._overlayElement.renderer=e}close(){this._setOpened(!1)}_contextTarget(e){if(this.selector){const t=this.listenOn.querySelectorAll(this.selector);return Array.prototype.filter.call(t,i=>e.composedPath().indexOf(i)>-1)[0]}return e.target}open(e){e&&!this.opened&&(this._context={detail:e.detail,target:this._contextTarget(e)},this._context.target&&(e.preventDefault(),e.stopPropagation(),this.__x=this._getEventCoordinate(e,"x"),this.__pageXOffset=window.pageXOffset,this.__y=this._getEventCoordinate(e,"y"),this.__pageYOffset=window.pageYOffset,this._overlayElement.style.visibility="hidden",this._setOpened(!0)))}__preserveMenuState(){const e=this.__getListBox();e&&(this.__focusedIndex=e.items.indexOf(e.focused),this._subMenu&&this._subMenu.opened&&(this.__subMenuIndex=e.items.indexOf(this._subMenu.listenOn)))}__restoreMenuState(){const e=this.__focusedIndex,t=this.__subMenuIndex,i=this.__selectedIndex,s=this.__getListBox();if(s){if(s._observer.flush(),t>-1){const o=s.items[t];o?Array.isArray(o._item.children)&&o._item.children.length?(this.__updateSubMenuForItem(this._subMenu,o),this._subMenu.requestContentUpdate()):(this._subMenu.close(),this.__focusItem(o)):s.focus()}this.__focusItem(i>-1?s.children[i]:s.items[e])}this.__focusedIndex=void 0,this.__subMenuIndex=void 0,this.__selectedIndex=void 0}__focusItem(e){e&&e.focus({focusVisible:xe()})}__onScroll(){if(!this.opened)return;const e=window.pageYOffset-this.__pageYOffset,t=window.pageXOffset-this.__pageXOffset;this.__adjustPosition("left",-t),this.__adjustPosition("right",t),this.__adjustPosition("top",-e),this.__adjustPosition("bottom",e),this.__pageYOffset+=e,this.__pageXOffset+=t}__adjustPosition(e,t){const s=this._overlayElement.style;s[e]=`${(parseInt(s[e])||0)+t}px`}__alignOverlayPosition(){const e=this._overlayElement;if(e.positionTarget)return;const t=e.style;["top","right","bottom","left"].forEach(g=>t.removeProperty(g)),["right-aligned","end-aligned","bottom-aligned"].forEach(g=>e.removeAttribute(g));const{xMax:i,xMin:s,yMax:o}=e.getBoundaries(),l=this.__x,u=this.__y,p=document.documentElement.clientWidth,_=document.documentElement.clientHeight;this.__isRTL?l>p/2||l>s?t.right=`${Math.max(0,p-l)}px`:(t.left=`${l}px`,this._setEndAligned(e)):l<p/2||l<i?t.left=`${l}px`:(t.right=`${Math.max(0,p-l)}px`,this._setEndAligned(e)),u<_/2||u<o?t.top=`${u}px`:(t.bottom=`${Math.max(0,_-u)}px`,e.setAttribute("bottom-aligned",""))}_setEndAligned(e){e.setAttribute("end-aligned",""),this.__isRTL||e.setAttribute("right-aligned","")}_getEventCoordinate(e,t){if(e.detail instanceof Object){if(e.detail[t])return e.detail[t];if(e.detail.sourceEvent)return this._getEventCoordinate(e.detail.sourceEvent,t)}else{const i=`client${t.toUpperCase()}`,s=e.changedTouches?e.changedTouches[0][i]:e[i];if(s===0){const o=e.target.getBoundingClientRect();return t==="x"?o.left:o.top+o.height}return s}}_listen(e,t,i){ue[t]?se(e,t,i):e.addEventListener(t,i)}_unlisten(e,t,i){ue[t]?We(e,t,i):e.removeEventListener(t,i)}__createMouseEvent(e,t,i){return new MouseEvent(e,{bubbles:!0,composed:!0,cancelable:!0,clientX:t,clientY:i})}__focusClosestFocusable(e){let t=e;for(;t;){if(t instanceof HTMLElement&&ke(t)){t.focus();return}t=t.parentNode||t.host}}__contextMenuAt(e,t){const i=gt(e,t);i&&queueMicrotask(()=>{i.dispatchEvent(this.__createMouseEvent("mousedown",e,t)),i.dispatchEvent(this.__createMouseEvent("mouseup",e,t)),this.__focusClosestFocusable(i),i.dispatchEvent(this.__createMouseEvent("contextmenu",e,t))})}_onGlobalContextMenu(e){e.shiftKey||(ge||he||(e.stopPropagation(),this._overlayElement.__focusRestorationController.focusNode=null,this._overlayElement.addEventListener("vaadin-overlay-closed",()=>this.__contextMenuAt(e.clientX,e.clientY),{once:!0})),e.preventDefault(),this.close())}};/**
 * @license
 * Copyright (c) 2016 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */class si extends ri(bt(Ae(Ge(Ct(G))))){static get template(){return ee`
      <style>
        :host {
          display: block;
        }

        :host([hidden]) {
          display: none !important;
        }
      </style>

      <slot id="slot"></slot>
    `}static get is(){return"vaadin-context-menu"}ready(){super.ready(),Ce(this)}_attachDom(r){const e=this.attachShadow({mode:"open"});return e.appendChild(r),e.appendChild(this._overlayElement),e}}N(si);function oi(n,r){try{return window.Vaadin.Flow.clients[n].getByNodeId(r)}catch(e){console.error("Could not get node %s from app %s",r,n),console.error(e)}}function ai(n,r){n.$connector||(n.$connector={generateItems(e){const t=we(r,e);n.items=t}})}function we(n,r){const e=oi(n,r);if(e)return Array.from(e.children).map(t=>{const i={component:t,checked:t._checked,keepOpen:t._keepOpen,className:t.className,theme:t.__theme};return t._hasVaadinItemMixin&&t._containerNodeId&&(i.children=we(n,t._containerNodeId)),t._item=i,i})}function li(n,r){n._item&&(n._item.checked=r,n._item.keepOpen&&n.toggleAttribute("menu-item-checked",r))}function di(n,r){n._item&&(n._item.keepOpen=r)}function ci(n,r){n._item&&(n._item.theme=r)}window.Vaadin.Flow.contextMenuConnector={initLazy:ai,generateItemsTree:we,setChecked:li,setKeepOpen:di,setTheme:ci};function hi(n){n.$contextMenuTargetConnector||(n.$contextMenuTargetConnector={openOnHandler(r){if(n.preventContextMenu&&n.preventContextMenu(r))return;r.preventDefault(),r.stopPropagation(),this.$contextMenuTargetConnector.openEvent=r;let e={};n.getContextMenuBeforeOpenDetail&&(e=n.getContextMenuBeforeOpenDetail(r)),n.dispatchEvent(new CustomEvent("vaadin-context-menu-before-open",{detail:e}))},updateOpenOn(r){this.removeListener(),this.openOnEventType=r,customElements.whenDefined("vaadin-context-menu").then(()=>{ue[r]?se(n,r,this.openOnHandler):n.addEventListener(r,this.openOnHandler)})},removeListener(){this.openOnEventType&&(ue[this.openOnEventType]?We(n,this.openOnEventType,this.openOnHandler):n.removeEventListener(this.openOnEventType,this.openOnHandler))},openMenu(r){r.open(this.openEvent)},removeConnector(){this.removeListener(),n.$contextMenuTargetConnector=void 0}})}window.Vaadin.Flow.contextMenuTargetConnector={init:hi};document.addEventListener("click",n=>{const r=n.composedPath().find(e=>e.hasAttribute&&e.hasAttribute("disableonclick"));r&&(r.disabled=!0)});
