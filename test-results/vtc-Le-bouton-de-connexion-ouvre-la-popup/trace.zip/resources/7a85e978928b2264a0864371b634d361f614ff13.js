self.additionalManifestEntries = [
{ url: 'img/favicon-144x144.png', revision: '759793606' },
{ url: 'img/favicon-192x192.png', revision: '476527667' },
{ url: 'img/favicon-512x512.png', revision: '-980136047' },
{ url: 'img/favicon-16x16.png', revision: '-754596120' },
{ url: 'img/favicon-32x32.png', revision: '501110352' },
{ url: 'offline-stub.html', revision: '-740883971' },
{ url: 'manifest.webmanifest', revision: '-1017772294' }
];
