import{r as a,q as E,e as m,s as f,m as h,h as l,d,E as p,b as u,P as c,A as I,t as v,u as b,D as _,v as y,B as M,w as k,x as S,o as D}from"./chunk-87ea9773e3be9e3c64fcd76ebb6648c631487bd39ff55c0d13bf58e8af292d4b-CAX9wiuo.js";import{i}from"./indexhtml-DSrkT9T8.js";import"./infinite-scroll-container-DtkBp7lj.js";/* empty css                     */import"./commonjsHelpers-Cpj98o6Y.js";a("vaadin-message-input",i`
    :host {
      padding: var(--lumo-space-s) var(--lumo-space-m);
    }

    ::slotted([slot='textarea']) {
      margin-inline-end: var(--lumo-space-s);
    }
  `,{moduleId:"lumo-message-input"});/**
 * @license
 * Copyright (c) 2021 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const P={send:"Send",message:"Message"},T=r=>class extends E(P,m(r)){static get properties(){return{value:{type:String,value:"",sync:!0},disabled:{type:Boolean,value:!1,reflectToAttribute:!0,sync:!0},_button:{type:Object,sync:!0},_textArea:{type:Object,sync:!0}}}static get observers(){return["__buttonPropsChanged(_button, disabled, __effectiveI18n)","__textAreaPropsChanged(_textArea, disabled, __effectiveI18n, value)"]}get i18n(){return super.i18n}set i18n(t){super.i18n=t}ready(){super.ready(),this._buttonController=new f(this,"button","vaadin-button",{initializer:t=>{t.setAttribute("theme","primary contained"),t.addEventListener("click",()=>{this.__submit()}),this._button=t}}),this.addController(this._buttonController),this._textAreaController=new f(this,"textarea","vaadin-text-area",{initializer:t=>{t.addEventListener("value-changed",e=>{this.value=e.detail.value}),t.addEventListener("keydown",e=>{e.key==="Enter"&&!e.shiftKey&&(e.preventDefault(),e.stopImmediatePropagation(),this.__submit())}),t.minRows=1,this._textArea=t}}),this.addController(this._textAreaController),this._tooltipController=new h(this),this.addController(this._tooltipController)}focus(t){this._textArea&&this._textArea.focus(t)}__buttonPropsChanged(t,e,o){t&&(t.disabled=e,t.textContent=o.send)}__textAreaPropsChanged(t,e,o,n){if(t){t.disabled=e,t.value=n;const g=o.message;t.placeholder=g,t.accessibleName=g}}__submit(){this.value!==""&&(this.dispatchEvent(new CustomEvent("submit",{detail:{value:this.value}})),this.value=""),this._textArea.focus()}};/**
 * @license
 * Copyright (c) 2021 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */class N extends T(p(u(c))){static get template(){return l`
      <style>
        :host {
          align-items: flex-start;
          box-sizing: border-box;
          display: flex;
          max-height: 50vh;
          overflow: hidden;
          flex-shrink: 0;
        }

        :host([hidden]) {
          display: none !important;
        }

        ::slotted([slot='button']) {
          flex-shrink: 0;
        }

        ::slotted([slot='textarea']) {
          align-self: stretch;
          flex-grow: 1;
        }
      </style>
      <slot name="textarea"></slot>

      <slot name="button"></slot>

      <slot name="tooltip"></slot>
    `}static get is(){return"vaadin-message-input"}}d(N);const x=i`
  :host {
    display: flex;
    align-items: center;
    width: 100%;
    outline: none;
    padding: var(--lumo-space-s) 0;
    box-sizing: border-box;
    font-family: var(--lumo-font-family);
    font-size: var(--lumo-font-size-m);
    font-weight: 500;
    line-height: var(--lumo-line-height-xs);
    color: var(--lumo-secondary-text-color);
    background-color: inherit;
    border-radius: var(--lumo-border-radius-m);
    cursor: var(--lumo-clickable-cursor);
    -webkit-tap-highlight-color: transparent;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  :host([disabled]),
  :host([disabled]) [part='toggle'] {
    color: var(--lumo-disabled-text-color);
    cursor: default;
  }

  @media (hover: hover) {
    :host(:hover:not([disabled])),
    :host(:hover:not([disabled])) [part='toggle'] {
      color: var(--lumo-contrast-80pct);
    }
  }

  [part='toggle'] {
    display: block;
    width: 1em;
    height: 1em;
    margin-left: calc(var(--lumo-space-xs) * -1);
    margin-right: var(--lumo-space-xs);
    font-size: var(--lumo-icon-size-s);
    line-height: 1;
    color: var(--lumo-contrast-60pct);
    font-family: 'lumo-icons';
    cursor: var(--lumo-clickable-cursor);
  }

  [part='toggle']::before {
    content: var(--lumo-icons-angle-right);
  }

  :host([opened]) [part='toggle'] {
    transform: rotate(90deg);
  }

  [part='content'] {
    flex-grow: 1;
  }

  /* RTL styles */
  :host([dir='rtl']) [part='toggle'] {
    margin-left: var(--lumo-space-xs);
    margin-right: calc(var(--lumo-space-xs) * -1);
  }

  :host([dir='rtl']) [part='toggle']::before {
    content: var(--lumo-icons-angle-left);
  }

  :host([opened][dir='rtl']) [part='toggle'] {
    transform: rotate(-90deg);
  }

  /* Small */
  :host([theme~='small']) {
    padding-top: var(--lumo-space-xs);
    padding-bottom: var(--lumo-space-xs);
  }

  :host([theme~='small']) [part='toggle'] {
    margin-right: calc(var(--lumo-space-xs) / 2);
  }

  :host([theme~='small'][dir='rtl']) [part='toggle'] {
    margin-left: calc(var(--lumo-space-xs) / 2);
  }

  /* Filled */
  :host([theme~='filled']) {
    padding: var(--lumo-space-s) calc(var(--lumo-space-s) + var(--lumo-space-xs) / 2);
  }

  /* Reverse */
  :host([theme~='reverse']) {
    justify-content: space-between;
  }

  :host([theme~='reverse']) [part='toggle'] {
    order: 1;
    margin-right: 0;
  }

  :host([theme~='reverse'][dir='rtl']) [part='toggle'] {
    margin-left: 0;
  }

  /* Filled reverse */
  :host([theme~='reverse'][theme~='filled']) {
    padding-left: var(--lumo-space-m);
  }

  :host([theme~='reverse'][theme~='filled'][dir='rtl']) {
    padding-right: var(--lumo-space-m);
  }
`;a("vaadin-details-summary",x,{moduleId:"lumo-details-summary"});const z=i`
  :host {
    padding: 0;
  }

  [part='content'] {
    padding: var(--lumo-space-s) 0;
  }

  :host([theme~='filled']) {
    padding-top: 0;
    padding-bottom: 0;
  }
`;a("vaadin-accordion-heading",[x,z],{moduleId:"lumo-accordion-heading"});/**
 * @license
 * Copyright (c) 2019 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const O=i`
  :host {
    display: block;
    outline: none;
    -webkit-user-select: none;
    user-select: none;
  }

  :host([hidden]) {
    display: none !important;
  }

  button {
    display: flex;
    align-items: center;
    justify-content: inherit;
    width: 100%;
    margin: 0;
    padding: 0;
    background-color: initial;
    color: inherit;
    border: initial;
    outline: none;
    font: inherit;
    text-align: inherit;
  }
`;/**
 * @license
 * Copyright (c) 2019 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */a("vaadin-accordion-heading",O,{moduleId:"vaadin-accordion-heading-styles"});class L extends I(v(u(c))){static get is(){return"vaadin-accordion-heading"}static get template(){return l`
      <button id="button" part="content" disabled$="[[disabled]]" aria-expanded$="[[__updateAriaExpanded(opened)]]">
        <span part="toggle" aria-hidden="true"></span>
        <slot></slot>
      </button>
    `}static get properties(){return{opened:{type:Boolean,reflectToAttribute:!0,value:!1}}}_attachDom(s){const t=this.attachShadow({mode:"open",delegatesFocus:!0});return t.appendChild(s),t}ready(){super.ready(),this.hasAttribute("role")||this.setAttribute("role","heading")}__updateAriaExpanded(s){return s?"true":"false"}}d(L);const C=i`
  :host {
    margin: var(--lumo-space-xs) 0;
    outline: none;
    --_focus-ring-color: var(--vaadin-focus-ring-color, var(--lumo-primary-color-50pct));
    --_focus-ring-width: var(--vaadin-focus-ring-width, 2px);
  }

  :host([focus-ring]) ::slotted([slot='summary']) {
    box-shadow: 0 0 0 var(--_focus-ring-width) var(--_focus-ring-color);
  }

  [part='content'] {
    padding: var(--lumo-space-xs) 0 var(--lumo-space-s);
    font-size: var(--lumo-font-size-m);
    line-height: var(--lumo-line-height-m);
  }

  :host([theme~='filled']) {
    background-color: var(--lumo-contrast-5pct);
    border-radius: var(--lumo-border-radius-m);
  }

  :host([theme~='filled']) [part='content'] {
    padding-left: var(--lumo-space-m);
    padding-right: var(--lumo-space-m);
  }

  :host([theme~='small']) [part$='content'] {
    font-size: var(--lumo-font-size-s);
  }
`;a("vaadin-details",C,{moduleId:"lumo-details"});const B=i`
  :host {
    margin: 0;
    border-bottom: solid 1px var(--lumo-contrast-10pct);
  }

  :host(:last-child) {
    border-bottom: none;
  }

  :host([theme~='filled']) {
    border-bottom: none;
  }

  :host([theme~='filled']:not(:last-child)) {
    margin-bottom: 2px;
  }
`;a("vaadin-accordion-panel",[C,B],{moduleId:"lumo-accordion-panel"});/**
 * @license
 * Copyright (c) 2019 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const F=i`
  :host {
    display: block;
  }

  :host([hidden]) {
    display: none !important;
  }

  [part='content'] {
    display: none;
    overflow: hidden;
  }

  :host([opened]) [part='content'] {
    display: block;
    overflow: visible;
  }
`;/**
 * @license
 * Copyright (c) 2019 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */class $ extends b{static generateId(s){return super.generateId(s,"content")}constructor(s){super(s,"",null,{multiple:!0})}}/**
 * @license
 * Copyright (c) 2019 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const A=r=>class extends r{static get properties(){return{opened:{type:Boolean,value:!1,reflectToAttribute:!0,notify:!0},_contentElements:{type:Array}}}static get observers(){return["_openedOrContentChanged(opened, _contentElements)"]}constructor(){super(),this._contentController=new $(this),this._contentController.addEventListener("slot-content-changed",t=>{const e=t.target.nodes||[];this._contentElements=e.filter(o=>o.parentNode===this)})}ready(){super.ready(),this.addController(this._contentController),this.addEventListener("click",({target:t})=>{if(this.disabled||t.localName==="a")return;const e=this.focusElement;e&&(t===e||e.contains(t))&&(this.opened=!this.opened)})}_openedOrContentChanged(t,e){e&&e.forEach(o=>{o.setAttribute("aria-hidden",t?"false":"true")})}};/**
 * @license
 * Copyright (c) 2019 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */class w extends b{constructor(s,t){super(s,"summary",t)}setSummary(s){this.summary=s,this.getSlotChild()||this.restoreDefaultNode(),this.node===this.defaultNode&&this.updateDefaultNode(this.node)}restoreDefaultNode(){const{summary:s}=this;s&&s.trim()!==""&&this.attachDefaultNode()}updateDefaultNode(s){s&&(s.textContent=this.summary),super.updateDefaultNode(s)}}/**
 * @license
 * Copyright (c) 2019 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const j=r=>class extends A(_(y(r))){static get properties(){return{summary:{type:String,observer:"_summaryChanged"}}}static get observers(){return["__updateAriaAttributes(focusElement, _contentElements)"]}static get delegateProps(){return["disabled","opened","_theme"]}constructor(){super(),this._summaryController=new w(this,"vaadin-accordion-heading"),this._summaryController.addEventListener("slot-content-changed",t=>{const{node:e}=t.target;this._setFocusElement(e),this.stateTarget=e,this._tooltipController.setTarget(e)}),this._tooltipController=new h(this),this._tooltipController.setPosition("bottom-start")}__forwardTabIndex(t){super.__forwardTabIndex(t),t!==void 0&&this.focusElement&&(this.focusElement.$.button.tabIndex=t,this.focusElement.tabIndex=-1)}ready(){super.ready(),this.addController(this._summaryController),this.addController(this._tooltipController)}_delegateProperty(t,e){if(this.stateTarget){if(t==="_theme"){this._delegateAttribute("theme",e);return}super._delegateProperty(t,e)}}_setAriaDisabled(){}_summaryChanged(t){this._summaryController.setSummary(t)}__updateAriaAttributes(t,e){if(t&&e){const o=e[0];o&&(o.setAttribute("role","region"),o.setAttribute("aria-labelledby",t.id)),o&&o.id?t.setAttribute("aria-controls",o.id):t.removeAttribute("aria-controls")}}};/**
 * @license
 * Copyright (c) 2019 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */a("vaadin-accordion-panel",F,{moduleId:"vaadin-accordion-panel-styles"});class K extends j(u(m(c))){static get is(){return"vaadin-accordion-panel"}static get template(){return l`
      <slot name="summary"></slot>

      <div part="content">
        <slot></slot>
      </div>

      <slot name="tooltip"></slot>
    `}}d(K);/**
 * @license
 * Copyright (c) 2025 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const R=()=>i`
  :host {
    display: block;
    outline: none;
    white-space: nowrap;
    -webkit-user-select: none;
    user-select: none;
  }

  :host([hidden]) {
    display: none !important;
  }

  :host([disabled]) {
    pointer-events: none;
  }
`;/**
 * @license
 * Copyright (c) 2019 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */a("vaadin-details-summary",R(),{moduleId:"vaadin-details-summary-styles"});class H extends M(v(u(c))){static get is(){return"vaadin-details-summary"}static get template(){return l`
      <span part="toggle" aria-hidden="true"></span>
      <div part="content"><slot></slot></div>
    `}static get properties(){return{opened:{type:Boolean,reflectToAttribute:!0}}}}d(H);/**
 * @license
 * Copyright (c) 2017 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const U=r=>class extends A(_(y(r))){static get properties(){return{summary:{type:String,observer:"_summaryChanged"}}}static get observers(){return["__updateAriaControls(focusElement, _contentElements)","__updateAriaExpanded(focusElement, opened)"]}static get delegateProps(){return["disabled","opened","_theme"]}constructor(){super(),this._summaryController=new w(this,"vaadin-details-summary"),this._summaryController.addEventListener("slot-content-changed",t=>{const{node:e}=t.target;this._setFocusElement(e),this.stateTarget=e,this._tooltipController.setTarget(e)}),this._tooltipController=new h(this),this._tooltipController.setPosition("bottom-start")}ready(){super.ready(),this.addController(this._summaryController),this.addController(this._tooltipController)}_delegateProperty(t,e){if(this.stateTarget){if(t==="_theme"){this._delegateAttribute("theme",e);return}super._delegateProperty(t,e)}}_setAriaDisabled(){}_summaryChanged(t){this._summaryController.setSummary(t)}__updateAriaControls(t,e){if(t&&e){const o=e[0];o&&o.id?t.setAttribute("aria-controls",o.id):t.removeAttribute("aria-controls")}}__updateAriaExpanded(t,e){t&&t.setAttribute("aria-expanded",e?"true":"false")}};/**
 * @license
 * Copyright (c) 2019 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */class q extends U(p(u(m(c)))){static get template(){return l`
      <style>
        :host {
          display: block;
        }

        :host([hidden]) {
          display: none !important;
        }

        [part='content'] {
          display: none;
        }

        :host([opened]) [part='content'] {
          display: block;
        }
      </style>

      <slot name="summary"></slot>

      <div part="content">
        <slot></slot>
      </div>

      <slot name="tooltip"></slot>
    `}static get is(){return"vaadin-details"}}d(q);/**
 * @license
 * Copyright (c) 2019 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */const G=r=>class extends k(r){static get properties(){return{opened:{type:Number,value:0,notify:!0,reflectToAttribute:!0},items:{type:Array,readOnly:!0,notify:!0}}}static get observers(){return["_updateItems(items, opened)"]}constructor(){super(),this._boundUpdateOpened=this._updateOpened.bind(this)}get focused(){return(this._getItems()||[]).find(t=>S(t.focusElement))}focus(t){this._observer&&this._observer.flush(),super.focus(t)}ready(){super.ready();const t=this.shadowRoot.querySelector("slot");this._observer=new D(t,e=>{this._setItems(this._filterItems(Array.from(this.children))),this._filterItems(e.addedNodes).forEach(o=>{o.addEventListener("opened-changed",this._boundUpdateOpened)})})}_getItems(){return this.items}_filterItems(t){return t.filter(e=>e instanceof customElements.get("vaadin-accordion-panel"))}_updateItems(t,e){if(t){this.__itemsSync=!0;const o=t[e];t.forEach(n=>{n.opened=n===o}),this.__itemsSync=!1}}_onKeyDown(t){this.items.some(e=>e.focusElement===t.target)&&super._onKeyDown(t)}_updateOpened(t){if(this.__itemsSync)return;const e=this._filterItems(t.composedPath())[0],o=this.items.indexOf(e);if(t.detail.value){if(e.disabled||o===-1)return;this.opened=o}else this.items.some(n=>n.opened)||(this.opened=null)}};/**
 * @license
 * Copyright (c) 2019 - 2025 Vaadin Ltd.
 * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
 */class J extends G(u(p(c))){static get template(){return l`
      <style>
        :host {
          display: block;
        }

        :host([hidden]) {
          display: none !important;
        }
      </style>
      <slot></slot>
    `}static get is(){return"vaadin-accordion"}}d(J);
